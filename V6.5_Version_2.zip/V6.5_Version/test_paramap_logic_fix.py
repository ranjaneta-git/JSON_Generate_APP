"""
Test Paramap Logic Fix - Verify P2/P3 structure
Tests the corrected firmware logic for P2 and P3 array structures
"""

import json
import sys
from forward_engine import ForwardTransformationEngine

def test_p2_structure():
    """Test P2 structure matches firmware logic"""
    
    # Create minimal test registers
    test_registers = {
        "registers": [
            # Write parameter (goes in P2.MPI)
            {
                "param_id": 12, "slave_id": 4, "fc": 6, "address": 2, "length": 1,
                "fmt": 3, "multiplier": 1.0, "access": "RW", "cloud": "No",
                "json_group": "Test", "json_unit": "unit", "json_key": "key",
                "b5_id": 12, "packet_num": 5, "parameter_type": "write",
                "feedback_param_id": 1
            },
            # Feedback parameter (NOT in P2.MPI or P3.MPI)
            {
                "param_id": 1, "slave_id": 4, "fc": 3, "address": 1, "length": 1,
                "fmt": 3, "multiplier": 1.0, "access": "R", "cloud": "No",
                "json_group": "", "json_unit": "", "json_key": "",
                "b5_id": 1, "packet_num": 1, "parameter_type": "feedback",
                "write_param_id": 12
            },
            # Monitoring parameter (goes in P2.MPI and P3.MPI)
            {
                "param_id": 3, "slave_id": 4, "fc": 3, "address": 32, "length": 1,
                "fmt": 3, "multiplier": 1.0, "access": "R", "cloud": "Yes",
                "json_group": "Monitor", "json_unit": "unit", "json_key": "key",
                "b5_id": 3, "packet_num": 3, "parameter_type": "read_only"
            },
        ]
    }
    
    # Transform
    engine = ForwardTransformationEngine()
    modbus_json, paramap_json = engine.transform(test_registers)
    
    # Verify P2 structure
    p2 = paramap_json["P2"]
    
    print("\n=== P2 Structure Test ===")
    print(f"P2.MPI: {p2['MPI']}")
    print(f"P2.LBI: {p2['LBI']}")
    print(f"P2.RPCI: {p2['RPCI']}")
    
    # Check P2.MPI contains B5.ID values (NOT feedback params)
    assert 12 in p2["MPI"], "Write param 12 should be in P2.MPI"
    assert 3 in p2["MPI"], "Monitor param 3 should be in P2.MPI"
    assert 1 not in p2["MPI"], "Feedback param 1 should NOT be in P2.MPI"
    
    # Check P2.LBI is sequential
    mpi_count = len(p2["MPI"])
    expected_lbi = list(range(1, mpi_count + 14))  # MPI + 13 RPCI
    assert p2["LBI"] == expected_lbi, f"P2.LBI should be sequential [1-{mpi_count+13}]"
    
    # Check P2.RPCI is sequential [1-13]
    assert p2["RPCI"] == list(range(1, 14)), "P2.RPCI should be [1, 2, ..., 13]"
    
    print("✅ P2 structure correct!")
    
    return True

def test_p3_structure():
    """Test P3 structure matches firmware logic"""
    
    # Create minimal test registers
    test_registers = {
        "registers": [
            # Write parameter (NOT in P3.MPI)
            {
                "param_id": 12, "slave_id": 4, "fc": 6, "address": 2, "length": 1,
                "fmt": 3, "multiplier": 1.0, "access": "RW", "cloud": "No",
                "json_group": "Test", "json_unit": "unit", "json_key": "key",
                "b5_id": 12, "packet_num": 5, "parameter_type": "write",
                "feedback_param_id": 1
            },
            # Feedback parameter (NOT in P3.MPI)
            {
                "param_id": 1, "slave_id": 4, "fc": 3, "address": 1, "length": 1,
                "fmt": 3, "multiplier": 1.0, "access": "R", "cloud": "No",
                "json_group": "", "json_unit": "", "json_key": "",
                "b5_id": 1, "packet_num": 1, "parameter_type": "feedback",
                "write_param_id": 12
            },
            # Monitoring parameters (go in P3.MPI)
            {
                "param_id": 3, "slave_id": 4, "fc": 3, "address": 32, "length": 1,
                "fmt": 3, "multiplier": 1.0, "access": "R", "cloud": "Yes",
                "json_group": "Monitor", "json_unit": "unit", "json_key": "key",
                "b5_id": 3, "packet_num": 3, "parameter_type": "read_only"
            },
            {
                "param_id": 4, "slave_id": 4, "fc": 3, "address": 33, "length": 1,
                "fmt": 3, "multiplier": 1.0, "access": "R", "cloud": "Yes",
                "json_group": "Monitor2", "json_unit": "unit", "json_key": "key",
                "b5_id": 4, "packet_num": 3, "parameter_type": "read_only"
            },
        ]
    }
    
    # Transform
    engine = ForwardTransformationEngine()
    modbus_json, paramap_json = engine.transform(test_registers)
    
    # Verify P3 structure
    p3 = paramap_json["P3"]
    
    print("\n=== P3 Structure Test ===")
    print(f"P3.MPI: {p3['MPI']}")
    print(f"P3.MDI: {p3['MDI']}")
    print(f"P3.LBI: {p3['LBI']}")
    
    # Check P3.MPI contains B5.ID values (monitoring params only)
    assert 3 in p3["MPI"], "Monitor param 3 should be in P3.MPI"
    assert 4 in p3["MPI"], "Monitor param 4 should be in P3.MPI"
    assert 12 not in p3["MPI"], "Write param 12 should NOT be in P3.MPI"
    assert 1 not in p3["MPI"], "Feedback param 1 should NOT be in P3.MPI"
    
    # Check P3.MDI is sequential
    mpi_count = len(p3["MPI"])
    expected_mdi = list(range(1, mpi_count + 1))
    assert p3["MDI"] == expected_mdi, f"P3.MDI should be sequential [1-{mpi_count}]"
    
    # Check P3.LBI is empty (no calculated values in this test)
    assert p3["LBI"] == [], "P3.LBI should be empty in this test"
    
    print("✅ P3 structure correct!")
    
    return True

def test_p1_nmd():
    """Test P1.NMD calculation"""
    
    test_registers = {
        "registers": [
            {
                "param_id": 12, "slave_id": 4, "fc": 6, "address": 2, "length": 1,
                "fmt": 3, "multiplier": 1.0, "access": "RW", "cloud": "No",
                "json_group": "Test", "json_unit": "unit", "json_key": "key",
                "b5_id": 12, "packet_num": 5, "parameter_type": "write"
            },
            {
                "param_id": 3, "slave_id": 4, "fc": 3, "address": 32, "length": 1,
                "fmt": 3, "multiplier": 1.0, "access": "R", "cloud": "Yes",
                "json_group": "Monitor", "json_unit": "unit", "json_key": "key",
                "b5_id": 3, "packet_num": 3, "parameter_type": "read_only"
            },
        ]
    }
    
    engine = ForwardTransformationEngine()
    modbus_json, paramap_json = engine.transform(test_registers)
    
    p1 = paramap_json["P1"]
    p2 = paramap_json["P2"]
    p3 = paramap_json["P3"]
    
    print("\n=== P1.NMD Test ===")
    print(f"P2.MPI count: {len(p2['MPI'])}")
    print(f"P3.MPI count: {len(p3['MPI'])}")
    print(f"P3.LBI count: {len(p3['LBI'])}")
    print(f"P1.NMD: {p1.get('NMD', 'MISSING!')}")
    
    # Check NMD calculation: P1.NMD = len(P3.MPI)
    expected_nmd = len(p3["MPI"])
    assert "NMD" in p1, "P1.NMD is missing!"
    assert p1["NMD"] == expected_nmd, f"P1.NMD should be {expected_nmd}, got {p1['NMD']}"
    
    print(f"✅ P1.NMD correct: {p1['NMD']}")
    
    return True

def test_jka_mapping():
    """Test JKA maps to P2.MPI"""
    
    test_registers = {
        "registers": [
            {
                "param_id": 12, "slave_id": 4, "fc": 6, "address": 2, "length": 1,
                "fmt": 3, "multiplier": 1.0, "access": "RW", "cloud": "No",
                "json_group": "Param12", "json_unit": "unit1", "json_key": "key1",
                "b5_id": 12, "packet_num": 5, "parameter_type": "write"
            },
            {
                "param_id": 3, "slave_id": 4, "fc": 3, "address": 32, "length": 1,
                "fmt": 3, "multiplier": 1.0, "access": "R", "cloud": "Yes",
                "json_group": "Param3", "json_unit": "unit2", "json_key": "key2",
                "b5_id": 3, "packet_num": 3, "parameter_type": "read_only"
            },
        ]
    }
    
    engine = ForwardTransformationEngine()
    modbus_json, paramap_json = engine.transform(test_registers)
    
    p2 = paramap_json["P2"]
    jky = paramap_json["JKY"]
    jka = jky.get("JKA", [])
    
    print("\n=== JKA Mapping Test ===")
    print(f"P2.MPI: {p2['MPI']}")
    print(f"JKA count: {len(jka)}")
    print(f"JKA[0]: {jka[0] if jka else 'empty'}")
    
    # JKA should have same count as P2.MPI
    assert len(jka) == len(p2["MPI"]), f"JKA count should equal P2.MPI count"
    
    # JKA[i] should map to P2.MPI[i]
    for i in range(len(p2["MPI"])):
        param_id = p2["MPI"][i]
        # Find register with this param_id
        reg = next((r for r in test_registers["registers"] if r["param_id"] == param_id), None)
        assert reg is not None, f"Register {param_id} not found"
        
        # Check JKA entry
        assert i < len(jka), f"JKA[{i}] missing"
        assert jka[i][0] == reg["json_group"], f"JKA[{i}] should map to {reg['json_group']}"
    
    print("✅ JKA mapping correct!")
    
    return True

if __name__ == "__main__":
    try:
        print("Testing Paramap Logic Fix...")
        print("="*50)
        
        test_p2_structure()
        test_p3_structure()
        test_p1_nmd()
        test_jka_mapping()
        
        print("\n" + "="*50)
        print("✅ ALL TESTS PASSED!")
        print("="*50)
        
    except AssertionError as e:
        print(f"\n❌ TEST FAILED: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
