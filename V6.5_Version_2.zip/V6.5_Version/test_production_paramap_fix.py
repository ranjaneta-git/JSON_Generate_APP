"""
Test production data with corrected Paramap logic
Validates P2/P3 structure with real 163-parameter configuration
"""

import json
from forward_engine import ForwardTransformationEngine

def test_production_paramap():
    """Test with production register_config_from_original.json"""
    
    print("\nTesting Production Paramap Structure...")
    print("=" * 60)
    
    # Load production config
    with open('../register_config_from_original.json', 'r') as f:
        register_config = json.load(f)
    
    # Generate from production file
    engine = ForwardTransformationEngine()
    modbus_config, paramap_config = engine.transform(register_config)
    
    # Extract P1, P2, P3, JKY
    p1 = paramap_config['P1']
    p2 = paramap_config['P2']
    p3 = paramap_config['P3']
    jky = paramap_config['JKY']
    
    print(f"\n=== P1 Summary ===")
    print(f"P1.NMD: {p1['NMD']}")
    print(f"Expected: len(P3.MPI) = {len(p3['MPI'])}")
    print(f"P1.NMD = Number of Monitoring Data sent to cloud")
    
    if p1['NMD'] == len(p3['MPI']):
        print("✅ P1.NMD correct!")
    else:
        print(f"❌ P1.NMD wrong! Expected {len(p3['MPI'])}, got {p1['NMD']}")
        return False
    
    print(f"\n=== P2 Summary ===")
    print(f"P2.MPI count: {len(p2['MPI'])}")
    print(f"P2.MPI (first 10): {p2['MPI'][:10]}")
    print(f"P2.LBI count: {len(p2['LBI'])}")
    print(f"P2.LBI (first 10): {p2['LBI'][:10]}")
    print(f"P2.LBI (last 5): {p2['LBI'][-5:]}")
    print(f"P2.RPCI count: {len(p2['RPCI'])}")
    print(f"P2.RPCI: {p2['RPCI']}")
    
    # Validate P2.LBI is sequential starting from 1
    expected_lbi = list(range(1, len(p2['MPI']) + len(p2['RPCI']) + 1))
    if p2['LBI'] == expected_lbi:
        print("✅ P2.LBI is correctly sequential!")
    else:
        print(f"❌ P2.LBI incorrect!")
        print(f"Expected: {expected_lbi}")
        print(f"Got: {p2['LBI']}")
        return False
    
    # Validate P2.RPCI is sequential 1-13
    if p2['RPCI'] == list(range(1, 14)):
        print("✅ P2.RPCI is correctly sequential [1-13]!")
    else:
        print(f"❌ P2.RPCI incorrect! Expected [1-13], got {p2['RPCI']}")
        return False
    
    print(f"\n=== P3 Summary ===")
    print(f"P3.MPI count: {len(p3['MPI'])}")
    print(f"P3.MPI (first 10): {p3['MPI'][:10]}")
    print(f"P3.MDI count: {len(p3['MDI'])}")
    print(f"P3.MDI (first 10): {p3['MDI'][:10]}")
    print(f"P3.MDI (last 5): {p3['MDI'][-5:]}")
    print(f"P3.LBI count: {len(p3['LBI'])}")
    print(f"P3.LBI: {p3['LBI']}")
    
    # Validate P3.MDI is sequential starting from 1
    expected_mdi = list(range(1, len(p3['MPI']) + 1))
    if p3['MDI'] == expected_mdi:
        print("✅ P3.MDI is correctly sequential!")
    else:
        print(f"❌ P3.MDI incorrect!")
        print(f"Expected length: {len(expected_mdi)}")
        print(f"Got length: {len(p3['MDI'])}")
        return False
    
    # Validate P3.LBI starts after P2.MPI if not empty
    if len(p3['LBI']) > 0:
        expected_start = len(p2['MPI']) + 1
        if p3['LBI'][0] == expected_start:
            print(f"✅ P3.LBI starts correctly at {expected_start}!")
        else:
            print(f"❌ P3.LBI start wrong! Expected {expected_start}, got {p3['LBI'][0]}")
            return False
    else:
        print("✅ P3.LBI is empty (correct if no local-only params)")
    
    print(f"\n=== JKY Summary ===")
    print(f"JKA count: {len(jky['JKA'])}")
    print(f"P2.MPI count: {len(p2['MPI'])}")
    print(f"Expected JKA count: {len(p2['MPI'])} (matches P2.MPI)")
    
    if len(jky['JKA']) == len(p2['MPI']):
        print("✅ JKA count matches P2.MPI count!")
    else:
        print(f"❌ JKA count wrong! Expected {len(p2['MPI'])}, got {len(jky['JKA'])}")
        return False
    
    # Validate no B6.RP params in P2.MPI or P3.MPI
    print(f"\n=== B6.RP Validation ===")
    
    feedback_params = set()
    for packet_name, packet_data in register_config.items():
        if packet_name.startswith('B6.RP'):
            for param in packet_data.get('parameters', []):
                feedback_params.add(param['B5.ID'])
    
    p2_has_feedback = any(pid in feedback_params for pid in p2['MPI'])
    p3_has_feedback = any(pid in feedback_params for pid in p3['MPI'])
    
    print(f"B6.RP params found: {len(feedback_params)}")
    print(f"B6.RP params: {sorted(feedback_params)}")
    print(f"B6.RP in P2.MPI: {p2_has_feedback}")
    print(f"B6.RP in P3.MPI: {p3_has_feedback}")
    
    if not p2_has_feedback and not p3_has_feedback:
        print("✅ No B6.RP params in P2.MPI or P3.MPI (correct)!")
    else:
        print("❌ B6.RP params found in P2.MPI or P3.MPI (wrong)!")
        return False
    
    # Check for param overlap between P2 and P3
    print(f"\n=== Param Overlap Analysis ===")
    p2_set = set(p2['MPI'])
    p3_set = set(p3['MPI'])
    overlap = p2_set & p3_set
    
    print(f"Params in both P2.MPI and P3.MPI: {len(overlap)}")
    if len(overlap) > 0:
        print(f"Overlapping params (first 10): {sorted(list(overlap))[:10]}")
        print("✅ Overlap allowed per firmware doc!")
    else:
        print("No overlap found")
    
    print("\n" + "=" * 60)
    print("✅ ALL PRODUCTION TESTS PASSED!")
    print("=" * 60)
    
    return True

if __name__ == '__main__':
    try:
        success = test_production_paramap()
        if not success:
            print("\n❌ Production test failed!")
            exit(1)
    except Exception as e:
        print(f"\n❌ Error during production test: {e}")
        import traceback
        traceback.print_exc()
        exit(1)
