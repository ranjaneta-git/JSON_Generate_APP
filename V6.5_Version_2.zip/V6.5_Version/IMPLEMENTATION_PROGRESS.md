# Equipment Hierarchy Implementation Plan
**Date:** February 5, 2026
**Status:** In Progress

## Implementation Checklist

### Phase 1: Data Structures ✅
- [ ] 1.1 Extend RegisterEntry with 4 new fields
- [ ] 1.2 Add columns 23-26 to tree widget
- [ ] 1.3 Update import_modbus_paramap() to populate equipment fields
- [ ] 1.4 Update get_register_data() to read equipment fields
- [ ] 1.5 Update add_register_row() to initialize equipment fields
- [ ] 1.6 Update edit_selected_row() to preserve equipment fields
- [ ] 1.7 Update load_sample_data() to add equipment fields
- [ ] 1.8 Update import_registers() to add equipment fields

### Phase 2: Reverse Engine Fixes 🔴
- [ ] 2.1 Fix JKA mapping: P2.MPI → P3.MDI
- [ ] 2.2 Support multi-key array extraction
- [ ] 2.3 Store equipment_group per parameter
- [ ] 2.4 Store device_name per parameter
- [ ] 2.5 Calculate jka_equipment_index and jka_param_index
- [ ] 2.6 Handle P3.LBI params in JKA

### Phase 3: Forward Engine Updates 🟡
- [ ] 3.1 Group parameters by equipment_group
- [ ] 3.2 Generate JKA with multi-key arrays
- [ ] 3.3 Support both Format A and Format B
- [ ] 3.4 Include P3.LBI params in JKA generation

### Phase 4: Testing ✅
- [ ] 4.1 Test with Chiller example (21 params)
- [ ] 4.2 Test with VFD example (25 params)
- [ ] 4.3 Test with VFD extended (29 params)
- [ ] 4.4 Verify round-trip preservation
- [ ] 4.5 Check equipment grouping accuracy

## Current Status
Starting Phase 1...
