"""
Analyze B6.WP and B6.RP pairing to understand the relationship
"""

import json

with open('c:\\Users\\DELL\\Downloads\\Original Modbus JSON.json', 'r') as f:
    original_modbus = json.load(f)

wp = original_modbus['B6']['WP']
rp = original_modbus['B6']['RP']

print("B6.WP/RP Pairing Analysis")
print("=" * 70)
print(f"\nB6.WP ({len(wp)} params): {wp}")
print(f"\nB6.RP ({len(rp)} params): {rp}")

print(f"\nPaired comparison:")
print("-" * 70)
print(f"{'Index':<6} {'WP':<8} {'RP':<8} {'Diff':<8} {'Pattern'}")
print("-" * 70)

for i in range(min(len(wp), len(rp))):
    diff = rp[i] - wp[i]
    pattern = "RP = WP - 11" if diff == -11 else f"RP = WP + {diff}" if diff > 0 else f"RP = WP - {abs(diff)}"
    print(f"{i:<6} {wp[i]:<8} {rp[i]:<8} {diff:<8} {pattern}")

print(f"\nPattern Analysis:")
print("-" * 70)

# Check if there's a consistent pattern
diffs = [rp[i] - wp[i] for i in range(min(len(wp), len(rp)))]
from collections import Counter
diff_counts = Counter(diffs)
print(f"Difference distribution: {dict(diff_counts)}")

# Most common difference
most_common_diff = diff_counts.most_common(1)[0]
print(f"Most common difference: {most_common_diff[0]} (appears {most_common_diff[1]} times)")

# Check formula: RP = WP - 11
matches_formula = sum(1 for i in range(min(len(wp), len(rp))) if rp[i] == wp[i] - 11)
print(f"\nFormula 'RP = WP - 11' matches: {matches_formula}/{len(wp)} ({matches_formula/len(wp)*100:.1f}%)")
