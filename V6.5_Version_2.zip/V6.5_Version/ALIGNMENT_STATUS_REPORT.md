# Application Alignment Status Report
**Thermelgy BMIoT Gateway Configuration Application**  
**Date:** February 5, 2026  
**Version:** 6.6.1 (After Cloud Validation Fix)

---

## Executive Summary

This document maps the **mental model** used by senior engineers (captured in Excel mapping sheets) against the **current application implementation**, identifying gaps, completed work, and areas requiring clarification.

**Overall Alignment Status:** 🟡 **Partially Aligned** (Core working, JKY needs major rework)

---

## 1. Core Firmware Structures - Alignment Status

### ✅ FULLY ALIGNED - Working Correctly

| Component | Status | Notes |
|-----------|--------|-------|
| **B1 - Project Metadata** | ✅ 100% | NOS, NOP, NPT, NOR generation correct |
| **B2 - Serial Config** | ✅ 100% | Baud rate, data format handled |
| **B3 - Slave Priority** | ✅ 100% | SI, SP arrays generated correctly |
| **B4 - Packet Allocation** | ✅ 100% | SA, NRT, FC, SID arrays match firmware |
| **B5 - Parameter Database** | ✅ 100% | ID, PN, STA, LN, FMT, MLT all correct |
| **B6 - Write-Read Mapping** | ✅ 100% | WP/RP pairing logic verified |
| **P1 - Buffer Counts** | ✅ 100% | NLB, NLBIN, NMD formulas firmware-compliant |
| **P2.MPI - Lua Buffer** | ✅ 100% | Maps write/read params to Lua buffer |
| **P2.LBI - Buffer Indices** | ✅ 100% | Sequential 1-N indexing correct |
| **P2.RPCI - RPC Commands** | ✅ 100% | RPC slot allocation working |
| **P3.MPI - Cloud Output** | ✅ 100% | Maps params to M_data buffer |
| **P3.MDI - Data Indices** | ✅ 100% | Sequential 1-N indexing correct |
| **P3.LBI - Calculated Values** | ✅ 100% | References P2 buffer slots |
| **JKC, NTC, MST** | ✅ 100% | Metadata sections preserved |

**Confidence:** HIGH - All verified against original firmware JSON files

---

### 🟡 PARTIALLY ALIGNED - Needs Improvement

| Component | Current State | Issues Found | Priority |
|-----------|---------------|--------------|----------|
| **JKY - JSON Key Mapping** | 🟡 Basic working | Major structural issues (see Section 2) | 🔴 HIGH |
| **Cloud Output Validation** | 🟡 Fixed but lenient | Allows missing JSON keys (firmware limitation) | 🟢 LOW |
| **Parameter Type Logic** | 🟡 Working | Correct for B6 params, but needs equipment context | 🟡 MEDIUM |

---

## 2. JKY Structure - Critical Alignment Issues

### 🔴 DISCOVERED ISSUES - Requires Implementation

#### Issue 2.1: Wrong JKA Source Mapping
**Current Implementation:**
```python
# reverse_engine.py line ~225
# Maps JKA[i] → P2.MPI[i]
for jka_idx in range(min(len(p2_mpi), len(jka_entries))):
    b5_id = p2_mpi[jka_idx]  # ❌ WRONG SOURCE!
```

**Senior Engineer Mental Model (Excel):**
- JKA maps to **P3.MPI sequentially**, NOT P2.MPI!
- Each JKA entry consumes N params from P3.MPI based on array size

**Example from Actual Firmware:**
```json
P3.MPI: [3, 4, 5, 8, 9, 10, 11, 12, 13, 14, 15, 18, 19, ...]

JKA[0]: ["VALVE", ["FB"], ["CNTRLValve"]]           → 1 param  → P3.MPI[0] = 3
JKA[1]: ["SEN", ["VAL"], ["Thermostat", "RTD"]]    → 2 params → P3.MPI[1-2] = 4, 5
JKA[2]: ["FAN", [8 params...], ["RCL AHU"]]        → 8 params → P3.MPI[3-10] = 8-15
JKA[3]: ["VALVE2", [2 params...], ["A/M Mode"]]    → 2 params → P3.MPI[11-12] = 18, 19
JKA[4]: ["EA", [10 params...], ["ENRGY MTR"]]      → 10 params → P3.MPI[13-22] = 20-29
```

**Impact:**
- ❌ Imported JSON has wrong equipment assignments
- ❌ Generated JSON won't match firmware structure
- ❌ Cloud output will have incorrect grouping

**Fix Required:** Rewrite `_extract_jky_mappings()` to:
1. Map JKA sequentially to P3.MPI (not P2.MPI)
2. Count array sizes to determine param distribution
3. Handle both JKA formats (see 2.2)

**Priority:** 🔴 **CRITICAL** - Breaks equipment grouping

---

#### Issue 2.2: Two JKA Formats Not Recognized
**Discovered:** Senior engineers use TWO different JKA structures

**Format A (Equipment_Group, Unit, Keys):**
```json
["CH1_DIE1", ["St"], ["Cr1"]]
["CH1_DIE2", ["St"], ["PP", "SP"]]                          // 2 keys
["AHU_RD_DIE2", ["St"], ["VFDAM", "VFDRun", ...]]          // 5 keys
```
- Used in: Chiller project, 2nd AHU example
- Pattern: `[Equipment_Name, [Unit_Type], [Parameter_Keys...]]`
- Keys array size = number of params this entry consumes

**Format B (Equipment_Group, ParamNames, Devices):**
```json
["VALVE", ["FB"], ["CNTRLValve"]]
["FAN", ["RNHR", "P_LD", "V_LD", ...], ["RCL AHU"]]        // 8 params
["EA", ["AVGV", "V12", "V23", ...], ["ENRGY MTR"]]         // 10 params
```
- Used in: 1st VFD example
- Pattern: `[Equipment_Group, [Parameter_Names...], [Device_Names...]]`
- ParamNames array size = number of params this entry consumes

**Current Implementation:**
```python
# Only handles Format A, only extracts first key
json_key = entry[2][0]  # ❌ Loses multi-key arrays!
```

**Impact:**
- ❌ Multi-key equipment loses all but first parameter name
- ❌ Format B completely misinterpreted (treats params as keys)
- ❌ Round-trip loses data

**Fix Required:**
1. Auto-detect JKA format
2. Extract ALL elements from arrays
3. Store equipment grouping metadata
4. Preserve format on round-trip

**Priority:** 🔴 **CRITICAL** - Causes data loss

---

#### Issue 2.3: Multi-Key Arrays Truncated
**Current Code:**
```python
json_unit = entry[1][0] if isinstance(entry[1], list) and len(entry[1]) > 0 else ""
json_key = entry[2][0]   # ❌ Only first key!
```

**Actual Firmware:**
```json
["CH1_DIE3", ["St"], ["SAC1", "SAC2", "SAC3"]]  // 3 Split ACs
["EA", ["AVGV", "V12", ...], ["ENRGY MTR"]]     // 10 measurements
```

**Impact:**
- ❌ SAC2, SAC3 lost (only SAC1 stored)
- ❌ V12-E lost (only AVGV stored)
- ❌ Equipment with multiple params broken

**Fix Required:**
- Store arrays as arrays (not single values)
- Update RegisterEntry to support multi-key storage
- Update GUI to display/edit multi-key entries

**Priority:** 🔴 **HIGH** - Major data loss

---

#### Issue 2.4: P3-Only Params Not Fully Covered
**Discovered:** JKA doesn't have entries for ALL P3.MPI params

**Original Firmware Example:**
- P3.MPI: 97 params
- JKA: 79 entries (59 P2.MPI + 20 P3-only)
- **Missing: 56 P3.MPI params without JKY**

**Current Status:**
- ✅ Cloud validation fixed (allows missing JKY)
- ✅ These params marked as cloud=Yes correctly
- ⚠️ But they have empty json_group/unit/key

**Impact:**
- ⚠️ Params published to cloud without proper JSON structure
- ⚠️ May appear as null/missing in cloud dashboards
- ℹ️ This is a **firmware limitation**, not our bug

**Fix Required:** NONE (firmware limitation, already handled gracefully)

**Priority:** 🟢 **LOW** - Working as intended, matches firmware

---

## 3. Equipment Hierarchy - Mental Model Analysis

### Senior Engineer Mental Model (from Excel):

```
Project Level
├─ Equipment Groups (Json Header)
│  ├─ VALVE, SEN, FAN, VALVE2, EA
│  └─ CH1_DIE1, CH1_DIE2, CH1_AIE1, etc.
│
├─ Equipment Devices
│  ├─ CNTRLValve, Thermostat, RTD
│  ├─ RCL AHU, ENRGY MTR
│  └─ COMP 1, IC_PUMP, SAC1/2/3
│
└─ Parameters per Device
   ├─ Single: FB, VAL, STAT
   └─ Multiple: VFD (8 params), EA (10 params)
```

### Application Current Model:

```
Flat Parameter List
├─ param_id: 1, 2, 3, ...
├─ json_group: "Equipment name"
├─ json_unit: "St" / "DegC"
└─ json_key: "Parameter name"

❌ No equipment hierarchy concept
❌ No device grouping
❌ No multi-param equipment support
```

### Alignment Gap:

| Concept | Senior Model | Application | Status |
|---------|--------------|-------------|--------|
| Equipment Groups | ✅ Primary organizing principle | ❌ Not implemented | 🔴 Missing |
| Device Names | ✅ Used for JSON structure | ❌ Not captured | 🔴 Missing |
| Multi-Param Equipment | ✅ Common (VFD=8, EA=10) | ❌ Single param only | 🔴 Missing |
| Equipment Types | ✅ AI, DI, EM classification | ❌ Not stored | 🟡 Optional |
| Hierarchical JSON | ✅ Group→Device→Param | ❌ Flat structure | 🔴 Missing |

---

## 4. Parameter Classification - Alignment Status

### ✅ ALIGNED - Working Correctly

| Classification | Application | Senior Model | Status |
|----------------|-------------|--------------|--------|
| Write Parameters | B6.WP | TRIG Write | ✅ Match |
| Feedback Reads | B6.RP | Status Read | ✅ Match |
| Write-Read Pairing | B6 pairs | Excel pairs | ✅ Match |
| P2.MPI (Lua Input) | Write params | TRIG Write params | ✅ Match |
| P3.MPI (Cloud Output) | Monitoring | Status Read + Sensors | ✅ Match |
| Parameter Types | write/feedback/read_only | Implicit in Excel | ✅ Match |

**Observations:**
- Pattern: Every TRIG Write has corresponding Status Read
- Application correctly identifies write-feedback pairs
- P2/P3 membership logic matches Excel allocation

---

## 5. GUI vs. Excel Mapping - Feature Comparison

### Excel Mapping Features:

| Feature | Excel | Application GUI | Status |
|---------|-------|-----------------|--------|
| **Project Template** | ✅ Template name/type | ❌ No project metadata | 🔴 Missing |
| **Equipment List** | ✅ Controlling/Monitoring devices | ❌ Not captured | 🔴 Missing |
| **Equipment Grouping** | ✅ Visual grouping by equipment | ❌ Flat list | 🔴 Missing |
| **Address Tracking** | ✅ B4-STA, B5-STA columns | ✅ Address field | ✅ Present |
| **Function Codes** | ✅ Explicit (R/W) | ✅ Access dropdown | ✅ Present |
| **Data Types** | ✅ UInt16, Int32, etc. | ✅ FMT codes | ✅ Present |
| **Multipliers** | ✅ Explicit values | ✅ Multiplier field | ✅ Present |
| **JSON Header** | ✅ Equipment group name | 🟡 json_group (but flat) | 🟡 Partial |
| **Device Name** | ✅ Specific device | ❌ Not captured | 🔴 Missing |
| **Parameter Name** | ✅ Multi-key support | ❌ Single key only | 🔴 Missing |
| **Device Type** | ✅ AI/DI/EM classification | ❌ Not captured | 🟡 Optional |
| **Visual Highlighting** | ✅ Yellow for key values | ❌ No highlighting | 🟡 Enhancement |
| **Comments/Notes** | ✅ AIM section | ❌ No comment field | 🟡 Enhancement |

### Application Advantages Over Excel:

| Feature | Excel | Application | Advantage |
|---------|-------|-------------|-----------|
| **Validation** | ❌ Manual | ✅ Automatic | App better |
| **B6 Pairing** | ❌ Manual tracking | ✅ Auto-detected | App better |
| **Packet Generation** | ❌ Manual calculation | ✅ Auto-generated | App better |
| **P1 Formulas** | ❌ Manual calculation | ✅ Auto-calculated | App better |
| **Import/Export** | ✅ Excel only | ✅ JSON + CSV | App better |
| **Round-Trip** | ❌ Not supported | ✅ Bidirectional | App better |
| **Consistency Checks** | ❌ Manual | ✅ Automatic | App better |

---

## 6. Implementation Priority Matrix

### 🔴 CRITICAL - Breaks Core Functionality

| Issue | Impact | Effort | Timeline |
|-------|--------|--------|----------|
| **Fix JKA→P3.MPI Mapping** | Equipment misassignment | 🔨 Medium | 2-3 hours |
| **Support Multi-Key Arrays** | Data loss on import/export | 🔨 Medium | 2-3 hours |
| **Detect JKA Format A/B** | Wrong interpretation | 🔨 Low | 1 hour |

**Total Estimated Effort:** 5-7 hours

---

### 🟡 MEDIUM - Improves Usability

| Feature | Benefit | Effort | Timeline |
|---------|---------|--------|----------|
| **Equipment Grouping UI** | Matches mental model | 🔨🔨 High | 1-2 days |
| **Device Name Field** | Complete metadata | 🔨 Low | 1 hour |
| **Multi-Param Equipment Editor** | Full feature parity | 🔨🔨 Medium | 4-6 hours |
| **Project Template Metadata** | Project organization | 🔨 Low | 1 hour |

**Total Estimated Effort:** 2-3 days

---

### 🟢 LOW - Nice to Have

| Enhancement | Value | Effort | Timeline |
|-------------|-------|--------|----------|
| **Equipment Type (AI/DI/EM)** | Better classification | 🔨 Low | 1 hour |
| **Visual Highlighting** | Easier to spot issues | 🔨 Low | 2 hours |
| **Comments/Notes Field** | Documentation support | 🔨 Low | 1 hour |
| **Excel Import** | Direct from mapping sheets | 🔨🔨 High | 2 days |
| **Equipment Templates** | Faster setup | 🔨🔨 Medium | 1 day |

**Total Estimated Effort:** 4-5 days

---

## 7. Outstanding Questions - Need Clarification

### 7.1 JKA Mapping Rules

**Question:** How do you determine which P3.MPI params belong to which JKA equipment group?

**Options:**
1. **Sequential mapping** (current assumption): JKA[i] consumes N params from P3.MPI sequentially
2. **Address-based**: Params grouped by address ranges
3. **Slave-based**: Params grouped by slave ID
4. **Manual assignment**: Engineers explicitly assign in Excel

**Your Input Needed:** Which method do you use?

---

### 7.2 JKA Format Selection

**Question:** When should Format A vs Format B be used?

**Observations:**
- Format A: Simpler, equipment+keys
- Format B: More detailed, separate param names and devices

**Your Input Needed:** 
- Is one format preferred/newer?
- Should app support both for import?
- Which should we generate for export?

---

### 7.3 Multi-Key Distribution

**Question:** For equipment with multiple keys, how are they distributed to parameters?

**Example:**
```json
["CH1_DIE3", ["St"], ["SAC1", "SAC2", "SAC3"]]  // 3 keys
P3.MPI: [... 10, 17, 12, 18, 19 ...]            // Which params get which key?
```

**Your Input Needed:**
- Are they sequential (10→SAC1, 17→SAC2, 12→SAC3)?
- Is there pairing logic (write+read pairs)?
- Is it documented in Excel somewhere?

---

### 7.4 Equipment Grouping Storage

**Question:** Where should equipment metadata be stored in the application?

**Options:**
1. **Add new RegisterEntry fields**: equipment_group, device_name, device_type
2. **Separate equipment table**: Keep registers flat, store grouping separately
3. **Use json_group field**: Extend current field to store hierarchy
4. **Custom metadata file**: Store alongside register_config.json

**Your Input Needed:** Which approach fits your workflow best?

---

### 7.5 P3.LBI vs P2.RPCI Relationship

**Question:** How do you decide which RPCI values go to P3.LBI (cloud output)?

**Observations:**
- Example 1: P2.RPCI=[1,2,3,4], P3.LBI=[16,17,18,19] (all 4)
- Example 2: P2.RPCI=[1,2], P3.LBI=[11,12] (all 2)

**Your Input Needed:**
- Do ALL RPCI values go to cloud?
- Or only selected ones?
- How is this determined?

---

## 8. Testing Status

### ✅ Verified Working

- ✅ Import original firmware JSON (163 params)
- ✅ Generate B1-B6 matching firmware
- ✅ Generate P1-P3 matching firmware (counts)
- ✅ B6 write-read pairing correct
- ✅ P2.MPI contains write params
- ✅ P3.MPI contains cloud params
- ✅ Round-trip preserves B1-B6, P1-P3.MPI/MDI
- ✅ Validation allows cloud without full JSON keys

### ⚠️ Known Issues

- ⚠️ JKA equipment assignment wrong
- ⚠️ Multi-key arrays truncated
- ⚠️ P3-only params have empty json_group
- ⚠️ Format B JKA misinterpreted

### ❌ Not Tested Yet

- ❌ Import/export with multi-key JKA
- ❌ Equipment grouping preservation
- ❌ Device name round-trip
- ❌ Format A vs B handling

---

## 9. Recommendations

### Immediate Actions (This Week):

1. **Fix JKA→P3.MPI Mapping** 🔴
   - Rewrite `_extract_jky_mappings()` in reverse_engine.py
   - Map JKA sequentially to P3.MPI (not P2.MPI)
   - Test with both provided examples

2. **Support Multi-Key Arrays** 🔴
   - Store arrays as lists, not single strings
   - Update RegisterEntry schema
   - Preserve all keys on round-trip

3. **Clarify Outstanding Questions** 🟡
   - Get answers to Section 7 questions
   - Document JKA mapping rules
   - Agree on storage approach

### Short-Term Goals (Next 2 Weeks):

4. **Add Equipment Grouping** 🟡
   - Add equipment_group, device_name fields
   - Update GUI to show hierarchy
   - Support equipment-based organization

5. **Comprehensive Testing** 🟡
   - Test with all provided examples
   - Verify round-trip with multi-key JKA
   - Document test cases

### Long-Term Vision (Next Month):

6. **Excel Import** 🟢
   - Import directly from mapping sheets
   - Auto-detect structure
   - Validate against templates

7. **Equipment Templates** 🟢
   - Pre-defined equipment types (VFD, Chiller, etc.)
   - Quick add with default params
   - Customizable library

---

## 10. Alignment Summary

### What's Working Well ✅

**Core Transformation Engine:**
- Firmware structure generation 100% correct
- B6 pairing logic matches mental model
- P2/P3 membership accurate
- Parameter type classification correct
- Validation catches actual errors

**Application Features:**
- Auto-generation eliminates manual calculation
- Bidirectional transformation works
- CSV/JSON import/export supported
- Error checking better than Excel

### What Needs Work 🔴

**JKY Structure:**
- Wrong source mapping (P2 instead of P3)
- Multi-key truncation
- Format detection missing
- Equipment hierarchy not captured

**GUI Gaps:**
- No equipment grouping concept
- No device name field
- Single-param limitation
- No project metadata

### What We Need to Understand 🤔

**Mapping Rules:**
- JKA→P3.MPI distribution logic
- Multi-key assignment rules
- Format selection criteria
- Equipment grouping methodology

**Design Decisions:**
- Storage approach for equipment data
- GUI organization preferences
- Which features are must-have vs nice-to-have
- Backward compatibility requirements

---

## Next Steps

**For Development Team:**
1. Review this document
2. Prioritize fixes (Section 6)
3. Implement critical issues (JKA mapping)
4. Test with provided examples
5. Update documentation

**For Stakeholders:**
1. Answer outstanding questions (Section 7)
2. Provide feedback on recommendations (Section 9)
3. Confirm priority matrix (Section 6)
4. Share additional examples if available
5. Review alignment assessment

**For Users:**
1. Current version usable for basic workflows
2. Avoid equipment with >1 param until fix deployed
3. Verify generated JKA against firmware
4. Report any additional discrepancies

---

## Document Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | Feb 5, 2026 | Initial alignment report |

**Maintained By:** Development Team  
**Review Schedule:** After each major feature update  
**Feedback:** Report issues via project tracker
