"""
Round-Trip Transformation Test - Corrected Logic
Tests: Register → Forward → Reverse → Forward
Validates bidirectional transformation with corrected P2/P3 structure
"""

import json
from forward_engine import ForwardTransformationEngine
from reverse_engine import ReverseTransformationEngine


def test_round_trip():
    """Test full round-trip transformation"""
    
    print("\n" + "=" * 70)
    print("ROUND-TRIP TRANSFORMATION TEST")
    print("=" * 70)
    
    # Load original register config
    print("\n[1/5] Loading original register config...")
    with open('../register_config_from_original.json', 'r') as f:
        original_register = json.load(f)
    
    original_param_count = len(original_register.get('registers', []))
    print(f"✅ Loaded {original_param_count} parameters")
    
    # Forward transformation 1
    print("\n[2/5] Forward transformation 1 (Register → Modbus + Paramap)...")
    forward_engine = ForwardTransformationEngine()
    modbus1, paramap1 = forward_engine.transform(original_register)
    
    print(f"✅ Generated Modbus + Paramap")
    print(f"   - P1.NMD: {paramap1['P1']['NMD']}")
    print(f"   - P2.MPI: {len(paramap1['P2']['MPI'])} params")
    print(f"   - P2.LBI: {len(paramap1['P2']['LBI'])} indices")
    print(f"   - P2.RPCI: {len(paramap1['P2']['RPCI'])} indices")
    print(f"   - P3.MPI: {len(paramap1['P3']['MPI'])} params")
    print(f"   - P3.MDI: {len(paramap1['P3']['MDI'])} indices")
    print(f"   - JKA: {len(paramap1['JKY']['JKA'])} entries")
    
    # Reverse transformation
    print("\n[3/5] Reverse transformation (Modbus + Paramap → Register)...")
    reverse_engine = ReverseTransformationEngine()
    reconstructed_register = reverse_engine.transform(modbus1, paramap1)
    
    reconstructed_param_count = len(reconstructed_register.get('registers', []))
    print(f"✅ Reconstructed {reconstructed_param_count} parameters")
    
    # Forward transformation 2
    print("\n[4/5] Forward transformation 2 (Reconstructed Register → Modbus + Paramap)...")
    forward_engine2 = ForwardTransformationEngine()
    modbus2, paramap2 = forward_engine2.transform(reconstructed_register)
    
    print(f"✅ Generated Modbus + Paramap from reconstructed data")
    print(f"   - P1.NMD: {paramap2['P1']['NMD']}")
    print(f"   - P2.MPI: {len(paramap2['P2']['MPI'])} params")
    print(f"   - P2.LBI: {len(paramap2['P2']['LBI'])} indices")
    print(f"   - P2.RPCI: {len(paramap2['P2']['RPCI'])} indices")
    print(f"   - P3.MPI: {len(paramap2['P3']['MPI'])} params")
    print(f"   - P3.MDI: {len(paramap2['P3']['MDI'])} indices")
    print(f"   - JKA: {len(paramap2['JKY']['JKA'])} entries")
    
    # Compare outputs
    print("\n[5/5] Comparing first and second forward transformations...")
    print("=" * 70)
    
    errors = []
    
    # Compare P1
    if paramap1['P1'] != paramap2['P1']:
        errors.append("P1 mismatch")
        print(f"❌ P1.NMD: {paramap1['P1']['NMD']} != {paramap2['P1']['NMD']}")
    else:
        print(f"✅ P1.NMD identical: {paramap1['P1']['NMD']}")
    
    # Compare P2.MPI
    if paramap1['P2']['MPI'] != paramap2['P2']['MPI']:
        errors.append("P2.MPI mismatch")
        print(f"❌ P2.MPI mismatch")
        print(f"   Original count: {len(paramap1['P2']['MPI'])}")
        print(f"   Reconstructed count: {len(paramap2['P2']['MPI'])}")
        
        # Show differences
        set1 = set(paramap1['P2']['MPI'])
        set2 = set(paramap2['P2']['MPI'])
        only_in_1 = set1 - set2
        only_in_2 = set2 - set1
        if only_in_1:
            print(f"   Only in original: {sorted(only_in_1)[:10]}")
        if only_in_2:
            print(f"   Only in reconstructed: {sorted(only_in_2)[:10]}")
    else:
        print(f"✅ P2.MPI identical ({len(paramap1['P2']['MPI'])} params)")
    
    # Compare P2.LBI
    if paramap1['P2']['LBI'] != paramap2['P2']['LBI']:
        errors.append("P2.LBI mismatch")
        print(f"❌ P2.LBI: {len(paramap1['P2']['LBI'])} != {len(paramap2['P2']['LBI'])}")
    else:
        print(f"✅ P2.LBI identical ({len(paramap1['P2']['LBI'])} indices)")
    
    # Compare P2.RPCI
    if paramap1['P2']['RPCI'] != paramap2['P2']['RPCI']:
        errors.append("P2.RPCI mismatch")
        print(f"❌ P2.RPCI mismatch")
    else:
        print(f"✅ P2.RPCI identical ({len(paramap1['P2']['RPCI'])} indices)")
    
    # Compare P3.MPI
    if paramap1['P3']['MPI'] != paramap2['P3']['MPI']:
        errors.append("P3.MPI mismatch")
        print(f"❌ P3.MPI mismatch")
        print(f"   Original count: {len(paramap1['P3']['MPI'])}")
        print(f"   Reconstructed count: {len(paramap2['P3']['MPI'])}")
        
        # Show differences
        set1 = set(paramap1['P3']['MPI'])
        set2 = set(paramap2['P3']['MPI'])
        only_in_1 = set1 - set2
        only_in_2 = set2 - set1
        if only_in_1:
            print(f"   Only in original: {sorted(only_in_1)[:10]}")
        if only_in_2:
            print(f"   Only in reconstructed: {sorted(only_in_2)[:10]}")
    else:
        print(f"✅ P3.MPI identical ({len(paramap1['P3']['MPI'])} params)")
    
    # Compare P3.MDI
    if paramap1['P3']['MDI'] != paramap2['P3']['MDI']:
        errors.append("P3.MDI mismatch")
        print(f"❌ P3.MDI: {len(paramap1['P3']['MDI'])} != {len(paramap2['P3']['MDI'])}")
    else:
        print(f"✅ P3.MDI identical ({len(paramap1['P3']['MDI'])} indices)")
    
    # Compare P3.LBI
    if paramap1['P3']['LBI'] != paramap2['P3']['LBI']:
        errors.append("P3.LBI mismatch")
        print(f"❌ P3.LBI mismatch")
    else:
        print(f"✅ P3.LBI identical ({len(paramap1['P3']['LBI'])} indices)")
    
    # Compare JKA
    if paramap1['JKY']['JKA'] != paramap2['JKY']['JKA']:
        errors.append("JKA mismatch")
        print(f"❌ JKA mismatch")
        print(f"   Original count: {len(paramap1['JKY']['JKA'])}")
        print(f"   Reconstructed count: {len(paramap2['JKY']['JKA'])}")
    else:
        print(f"✅ JKA identical ({len(paramap1['JKY']['JKA'])} entries)")
    
    # Compare Modbus B4 (packets)
    b4_match = True
    if len(modbus1['B4']) != len(modbus2['B4']):
        errors.append("B4 packet count mismatch")
        print(f"❌ B4 packet count: {len(modbus1['B4'])} != {len(modbus2['B4'])}")
        b4_match = False
    else:
        for i, (p1, p2) in enumerate(zip(modbus1['B4'], modbus2['B4'])):
            if p1 != p2:
                errors.append(f"B4[{i}] mismatch")
                print(f"❌ B4[{i}] mismatch")
                print(f"   Original: SA={p1[0]}, NRT={p1[1]}, NS={p1[2]}")
                print(f"   Reconstructed: SA={p2[0]}, NRT={p2[1]}, NS={p2[2]}")
                b4_match = False
                break
        
        if b4_match:
            print(f"✅ B4 (packets) identical ({len(modbus1['B4'])} packets)")
    
    # Compare Modbus B5 (parameters)
    b5_match = True
    if len(modbus1['B5']) != len(modbus2['B5']):
        errors.append("B5 parameter count mismatch")
        print(f"❌ B5 parameter count: {len(modbus1['B5'])} != {len(modbus2['B5'])}")
        b5_match = False
    else:
        for i, (p1, p2) in enumerate(zip(modbus1['B5'], modbus2['B5'])):
            if p1 != p2:
                errors.append(f"B5[{i}] mismatch")
                print(f"❌ B5[{i}] mismatch")
                print(f"   Original: {p1}")
                print(f"   Reconstructed: {p2}")
                b5_match = False
                if i >= 5:  # Show first 5 mismatches only
                    break
        
        if b5_match:
            print(f"✅ B5 (parameters) identical ({len(modbus1['B5'])} parameters)")
    
    # Final result
    print("\n" + "=" * 70)
    if errors:
        print(f"❌ ROUND-TRIP TEST FAILED")
        print(f"Errors found: {len(errors)}")
        for error in errors:
            print(f"  - {error}")
        return False
    else:
        print(f"✅ ROUND-TRIP TEST PASSED")
        print(f"Forward → Reverse → Forward produces IDENTICAL output!")
        print(f"Transformation is fully bidirectional and lossless.")
        return True


if __name__ == '__main__':
    try:
        success = test_round_trip()
        exit(0 if success else 1)
    except Exception as e:
        print(f"\n❌ Error during round-trip test: {e}")
        import traceback
        traceback.print_exc()
        exit(1)
