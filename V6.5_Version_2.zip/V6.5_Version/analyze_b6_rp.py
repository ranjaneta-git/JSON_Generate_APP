"""
Detailed B6.RP analysis
"""

import json

# Load original
with open('c:\\Users\\DELL\\Downloads\\Original Modbus JSON.json', 'r') as f:
    original_modbus = json.load(f)

# Load register config
with open('../register_config_from_original.json', 'r') as f:
    register_config = json.load(f)

print("B6.RP Analysis")
print("=" * 70)

# Original B6.RP
orig_rp = original_modbus['B6']['RP']
print(f"\nOriginal B6.RP ({len(orig_rp)} params):")
print(orig_rp)

# Check array_membership for each param
print(f"\nAnalyzing array_membership field:")
print("-" * 70)

feedback_candidates = []
for reg in register_config['registers']:
    param_id = reg['param_id']
    array_mem = reg.get('array_membership', '')
    
    # Feedback params should NOT be in P2.MPI or P3.MPI
    if 'P2.MPI' not in array_mem and 'P3.MPI' not in array_mem and array_mem:
        feedback_candidates.append(param_id)
        if param_id <= 20:  # Show first few
            print(f"Param {param_id}: {array_mem}")

print(f"\nTotal feedback candidates: {len(feedback_candidates)}")
print(f"Feedback candidates: {sorted(feedback_candidates)[:20]}...")

# Compare
orig_set = set(orig_rp)
found_set = set(feedback_candidates)
missing = orig_set - found_set
extra = found_set - orig_set

print(f"\nMissing from detection ({len(missing)}): {sorted(list(missing))}")
print(f"Extra in detection ({len(extra)}): {sorted(list(extra))}")

# Check what's common
common = orig_set & found_set
print(f"\nCorrectly detected ({len(common)}): {sorted(list(common))[:20]}...")

# Analyze missing params
print(f"\nAnalyzing MISSING params:")
for param_id in sorted(list(missing))[:10]:
    reg = next((r for r in register_config['registers'] if r['param_id'] == param_id), None)
    if reg:
        print(f"  Param {param_id}: array_membership = '{reg.get('array_membership', '')}'")
