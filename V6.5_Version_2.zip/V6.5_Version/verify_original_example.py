"""
Verify P1.NMD matches the original firmware example
Original example has:
- P3.MPI: 97 params
- P3.MDI: 97 indices
- P1.NMD: 97 ✅
"""

import json

# Load original example
with open('c:\\Users\\DELL\\Downloads\\Original Paramap JSON.json', 'r') as f:
    original = json.load(f)

print("Original Firmware Example Validation")
print("=" * 60)
print(f"\nP1.NMD: {original['P1']['NMD']}")
print(f"P3.MPI count: {len(original['P3']['MPI'])}")
print(f"P3.MDI count: {len(original['P3']['MDI'])}")
print(f"P2.MPI count: {len(original['P2']['MPI'])}")
print(f"P2.LBI count: {len(original['P2']['LBI'])}")

print(f"\n✅ Confirmed: P1.NMD ({original['P1']['NMD']}) = P3.MPI count ({len(original['P3']['MPI'])})")
print(f"✅ Confirmed: P3.MDI count ({len(original['P3']['MDI'])}) = P3.MPI count ({len(original['P3']['MPI'])})")

if original['P1']['NMD'] == len(original['P3']['MPI']):
    print(f"\n✅✅✅ VALIDATION PASSED!")
    print(f"P1.NMD formula is CORRECT: P1.NMD = len(P3.MPI)")
else:
    print(f"\n❌ VALIDATION FAILED!")
