# Paramap Complete Logic Guide
**Thermelgy BMIoT Gateway - Data Flow & Parameter Mapping**  
**Version:** 2.0 (Firmware-Validated)  
**Date:** February 5, 2026

---

## Table of Contents
1. [System Architecture Overview](#1-system-architecture-overview)
2. [B5 - Master Parameter Database](#2-b5---master-parameter-database)
3. [B6 - Write-Feedback Verification Mapping](#3-b6---write-feedback-verification-mapping)
4. [P2 - Lua Buffer Input Configuration](#4-p2---lua-buffer-input-configuration)
5. [P3 - Cloud Output Configuration](#5-p3---cloud-output-configuration)
6. [Complete Data Flow Diagrams](#6-complete-data-flow-diagrams)
7. [Key Relationships & Rules](#7-key-relationships--rules)
8. [Parameter Examples](#8-parameter-examples)
9. [Quick Reference Tables](#9-quick-reference-tables)

---

## 1. System Architecture Overview

### 1.1 Four Main Blocks

The Paramap system consists of **4 interconnected blocks**:

| Block | Full Name | Purpose | Parameter Count |
|-------|-----------|---------|----------------|
| **B5** | Modbus Parameter Database | Master definition of all parameters | 163 parameters |
| **B6** | Write-Feedback Mapping | Write verification pairs | 33 pairs |
| **P2** | Lua Buffer Configuration | Modbus → Lua synchronization | 59 MPI + 13 RPCI |
| **P3** | Cloud Output Configuration | Modbus → Cloud telemetry | 97 MPI |

### 1.2 Three Data Flow Paths

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. CONTROL PATH (Cloud/User → Modbus Write)                     │
│    Cloud → P2.RPCI → Lua Buffer → Lua Script → B6 Lookup        │
│         → Modbus Write → B6.RP Verify                            │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ 2. MONITORING PATH (Modbus → Lua Processing)                    │
│    Modbus Read → P2.MPI → Lua Buffer → Lua Script Logic         │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ 3. TELEMETRY PATH (Modbus → Cloud)                              │
│    Modbus Read → P3.MPI → M_data Buffer → JKY JSON              │
│         → MQTT → Cloud                                           │
└─────────────────────────────────────────────────────────────────┘
```

### 1.3 Block Relationships

```
                    ┌─────────────────────┐
                    │   B5 (Master DB)    │
                    │  163 Parameters     │
                    │  All Definitions    │
                    └──────────┬──────────┘
                               │
                ┌──────────────┼──────────────┐
                │              │              │
                ↓              ↓              ↓
        ┌──────────┐   ┌──────────┐   ┌──────────┐
        │    B6    │   │    P2    │   │    P3    │
        │ 33 Write │   │ 59 MPI   │   │ 97 MPI   │
        │ 33 Read  │   │ 13 RPCI  │   │  0 LBI   │
        │  Pairs   │   │ 72 LBI   │   │ 97 MDI   │
        └──────────┘   └────┬─────┘   └────┬─────┘
                            │              │
                            ↓              ↓
                    ┌──────────┐   ┌──────────┐
                    │Lua Buffer│   │ M_data   │
                    │ 72 slots │   │ 97 slots │
                    └──────────┘   └──────────┘
```

---

## 2. B5 - Master Parameter Database

### 2.1 B5 Structure

**B5 contains ALL 163 Modbus parameters** with complete definitions:

| Array | Name | Data Type | Description | Example |
|-------|------|-----------|-------------|---------|
| `B5.ID` | Parameter ID | uint16[163] | Unique identifier (1-163) | ID=12 |
| `B5.PN` | Packet Number | uint16[163] | Modbus transaction group | PN=5 |
| `B5.STA` | Start Address | uint16[163] | Modbus register address | STA=32 |
| `B5.LN` | Length | uint8[163] | Register count | LN=1 |
| `B5.FMT` | Format | uint8[163] | Data type (uint16/int16/float) | FMT=3 |
| `B5.MLT` | Multiplier | float[163] | Scaling factor | MLT=0.1 |

### 2.2 B5 as Single Source of Truth

**All other blocks reference B5.ID values:**
- P2.MPI contains B5.ID values (e.g., [3, 12, 13, 14, 15...])
- P3.MPI contains B5.ID values (e.g., [3, 4, 5, 6, 7...])
- B6.WP contains B5.ID values for write params
- B6.RP contains B5.ID values for feedback params

**B5 lookup flow:**
```
Application requests: "Read Parameter ID=74"
    ↓
Lookup in B5: Find index where B5.ID[i] = 74
    ↓
Found at index 73: B5.ID[73] = 74
    ↓
Extract properties:
    B5.PN[73] = 74 (Packet number)
    B5.STA[73] = 1561 (Register address)
    B5.LN[73] = 1 (One register)
    B5.FMT[73] = 3 (uint16)
    B5.MLT[73] = 0.1 (Scale by 0.1)
    ↓
Execute Modbus Read:
    Read from Slave, Function Code 3, Address 1561, Length 1
    ↓
Apply scaling:
    Raw value = 455
    Final value = 455 × 0.1 = 45.5°C
```

### 2.3 B5 Example Entries

**Parameter 12 (Write Setpoint):**
```
B5.ID[11] = 12
B5.PN[11] = 5       // Packet 5 (Slave 4)
B5.STA[11] = 2      // Register address 2
B5.LN[11] = 1       // Single register
B5.FMT[11] = 3      // uint16 format
B5.MLT[11] = 1.0    // No scaling
```

**Parameter 74 (Temperature Sensor):**
```
B5.ID[73] = 74
B5.PN[73] = 74      // Packet 74 (Slave 13)
B5.STA[73] = 1561   // Register address 1561
B5.LN[73] = 1       // Single register
B5.FMT[73] = 3      // uint16 format
B5.MLT[73] = 0.1    // Scale by 0.1 for decimal point
```

---

## 3. B6 - Write-Feedback Verification Mapping

### 3.1 B6 Structure

**B6 contains 33 write-feedback pairs:**

```json
"B6": {
  "WP": [12, 13, 14, 15, 27, 28, 29, 30, 42, 43, 44, 45, ...],  // 33 write params
  "RP": [1, 2, 9, 10, 16, 17, 24, 25, 31, 32, 39, 40, ...]      // 33 feedback params
}
```

| Array | Full Name | Purpose | Count |
|-------|-----------|---------|-------|
| `B6.WP` | Write Parameters | Parameters that support write operations | 33 |
| `B6.RP` | Read Parameters (Feedback) | Parameters used to verify writes | 33 |

### 3.2 Index-Matched Pairing

**B6.WP[i] ↔ B6.RP[i]** (same index = paired):

| Index | B6.WP (Write) | B6.RP (Feedback) | Meaning |
|-------|---------------|------------------|---------|
| 0 | 12 | 1 | Write to param 12, verify with param 1 |
| 1 | 13 | 2 | Write to param 13, verify with param 2 |
| 2 | 14 | 9 | Write to param 14, verify with param 9 |
| 3 | 15 | 10 | Write to param 15, verify with param 10 |
| 4 | 27 | 16 | Write to param 27, verify with param 16 |

### 3.3 Write Verification Flow

**Step-by-step firmware process (MBConfig_Lib.cpp lines 511-590):**

```
1. Lua script issues write command:
   Buff_Write(lbi=2, value=50)
   
2. Firmware looks up parameter ID from P2:
   P2.LBI[1] = 2 → P2.MPI[1] = 12
   Parameter ID = 12
   
3. Search B6.WP for parameter 12:
   for (i = 0; i < 33; i++) {
     if (B6.WP[i] == 12) break;  // Found at index 0
   }
   
4. Get feedback parameter from B6.RP:
   feedback_param = B6.RP[0] = 1
   
5. Execute Modbus write to parameter 12:
   Lookup B5.ID[11] = 12
   Write to Register 2, Value = 50
   
6. Execute Modbus read from parameter 1 (feedback):
   Lookup B5.ID[0] = 1
   Read from Register 1
   
7. Compare values:
   if (read_value == 50) {
     return WRITE_SUCCESS;
   } else {
     return VERIFY_FAIL;
   }
```

### 3.4 Critical Design Rule

**🔴 B6.RP parameters (1, 2, 9, 10, 16, 17...) are NEVER in P2.MPI or P3.MPI**

**Why?**
- Feedback parameters are **only** for write verification
- They are accessed via **direct Modbus read** during verification
- They don't need to be in Lua buffer (not used by Lua logic)
- They don't need to be in M_data (not sent to cloud)

**Evidence:**
```
B6.RP = [1, 2, 9, 10, 16, 17, 24, 25, 31, 32, 39, 40, ...]
P2.MPI = [3, 12, 13, 14, 15, 18, 27, 28, 29, 30, 33, ...]
         ↑ Notice: 1, 2, 9, 10, 16, 17... are NOT present

P3.MPI = [3, 4, 5, 6, 7, 8, 9, 11, 18, 19, 20, 21, 22, ...]
         ↑ Notice: 1, 2, (9 is monitoring), 10, 16, 17... are NOT present
```

---

## 4. P2 - Lua Buffer Input Configuration

### 4.1 P2 Purpose

**P2 defines which Modbus parameters are synchronized with the Lua buffer.**

The Lua buffer enables:
- ✅ Lua scripts to read Modbus values
- ✅ Lua scripts to write control commands
- ✅ Cloud to send RPC commands
- ✅ Complex logic execution (calculations, decisions, control)

### 4.2 P2.MPI - Modbus Parameter Index

**Contains 59 parameter IDs** that Lua needs access to:

```json
"P2": {
  "MPI": [3, 12, 13, 14, 15, 18, 27, 28, 29, 30, 33, 42, 43, 44, 45, 
          48, 57, 58, 59, 60, 63, 72, 73, 74, 75, 78, 87, 88, 89, 90, 
          93, 102, 103, 104, 105, 108, 117, 118, 119, 120, 4, 19, 34, 
          49, 64, 79, 94, 109, 128, 121, 122, 129, 123, 124, 133, 131, 
          130, 152, 163]
}
```

**Composition:**
- **33 write parameters** from B6.WP (12, 13, 14, 15, 27, 28, 29, 30...)
- **26 read parameters** for Lua monitoring/calculations (3, 4, 18, 19...)
- **0 feedback parameters** from B6.RP (deliberately excluded)

**Why write parameters in P2.MPI?**
- Lua scripts need to issue write commands (e.g., setpoint changes)
- Write params must be in Lua buffer for Buff_Write() function

**Why monitoring reads in P2.MPI?**
- Lua scripts need sensor values for calculations
- Example: Temperature, pressure, flow rate for control logic

**Why feedback reads NOT in P2.MPI?**
- Feedback is only for verification (firmware handles it)
- Lua doesn't need to verify writes (firmware does it automatically)
- Reduces Lua buffer size (optimization)

### 4.3 P2.LBI - Lua Buffer Index

**Sequential indices [1-59]** for P2.MPI parameters:

```json
"P2": {
  "LBI": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18,
          19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34,
          35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50,
          51, 52, 53, 54, 55, 56, 57, 58, 59]
}
```

**Mapping P2.LBI → P2.MPI:**

| LBI Index | P2.LBI Value | P2.MPI Value | Meaning |
|-----------|--------------|--------------|---------|
| 0 | 1 | 3 | Lua buffer slot 1 → Parameter 3 |
| 1 | 2 | 12 | Lua buffer slot 2 → Parameter 12 |
| 2 | 3 | 13 | Lua buffer slot 3 → Parameter 13 |
| 3 | 4 | 14 | Lua buffer slot 4 → Parameter 14 |
| ... | ... | ... | ... |
| 58 | 59 | 163 | Lua buffer slot 59 → Parameter 163 |

**Firmware synchronization (ParamMapConfig_Lib.cpp line 575):**
```cpp
// Every scan cycle (typically 1s):
for (uint16_t i = 0; i < p_LBMPNum; i++) {
  // Read from Modbus parameter PC2_MP[i].p_MPI
  float value = Modbus_ParmRead(EMB, PC2_MP[i].p_MPI);
  
  // Store in Lua buffer at position PC2_MP[i].p_LBI - 1
  LuaBuffVar[PC2_MP[i].p_LBI - 1] = value;
}
```

**Lua script access:**
```lua
-- Read parameter 3 (stored in LBI slot 1)
local param3_value = LuaBuffVar[1]

-- Read parameter 12 (stored in LBI slot 2)
local param12_value = LuaBuffVar[2]

-- Write to parameter 12 (LBI slot 2)
Buff_Write(2, 50.0)  -- Writes value 50.0 to parameter 12
```

### 4.4 P2.RPCI - RPC Command Index

**Contains 13 RPC command slots** for cloud remote control:

```json
"P2": {
  "RPCI": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
}
```

**Purpose:**
- Cloud platform sends control commands
- Example: `{"CmdID": 5, "CmdVal": 60}`
- Firmware updates Lua buffer with command value
- Lua script reads and executes command

**RPC handling (RPC_Lib.cpp lines 24-36):**
```cpp
void RPC_Handler::CmdID_Handler(mg_rpc_req *r) {
  // Parse cloud command
  uint16_t CmdID = (*doc)["CmdID"];    // e.g., 5
  float CmdVal = (*doc)["CmdVal"];     // e.g., 60.0
  
  // Validate CmdID range
  if (CmdID > 0 && CmdID <= p_LBRPCNum) {
    // Find LBI slot for this RPC command
    uint16_t lbi = PC2_RPC[CmdID-1].p_LBI;
    
    // Update Lua buffer
    LuaBuffVar[lbi - 1] = CmdVal;
  }
}
```

**Example RPC flow:**
```
1. Cloud sends: {"CmdID": 5, "CmdVal": 60}

2. Firmware looks up P2.RPCI[4] = 5 (index 4 for CmdID 5)
   Gets LBI for RPCI[4], assume it's 64

3. Updates: LuaBuffVar[63] = 60.0

4. Lua script reads:
   local cmd5_value = LuaBuffVar[64]
   if cmd5_value > 0 then
     -- Execute command
   end
```

### 4.5 P2.LBI Total Calculation

**Formula:**
```
Total P2.LBI Count = P2.MPI Count + P2.RPCI Count
                   = 59 + 13
                   = 72
```

**Complete P2.LBI array:**
```json
"P2": {
  "LBI": [1, 2, 3, ..., 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72]
         └─── MPI (59) ───┘ └───────────── RPCI (13) ─────────────┘
}
```

**Lua buffer memory layout:**
```
Index 0-58:   LuaBuffVar[0-58]   → P2.MPI parameters (59 slots)
Index 59-71:  LuaBuffVar[59-71]  → P2.RPCI commands (13 slots)
Total: 72 slots
```

**Why continuous numbering?**
- Lua buffer is a single continuous array
- No gaps or holes
- Efficient memory access
- Simple index arithmetic

---

## 5. P3 - Cloud Output Configuration

### 5.1 P3 Purpose

**P3 defines which parameters are sent to the cloud platform (mDash/MQTT).**

The M_data buffer enables:
- ✅ Cloud telemetry (real-time monitoring)
- ✅ Historical data logging
- ✅ Dashboard visualization
- ✅ Alarms and notifications

### 5.2 P3.MPI - Modbus Parameter Index

**Contains 97 parameter IDs** for cloud transmission:

```json
"P3": {
  "MPI": [3, 4, 5, 6, 7, 8, 9, 11, 18, 19, 20, 21, 22, 23, 24, 26,
          33, 34, 35, 36, 37, 38, 39, 41, 48, 49, 50, 51, 52, 53, 54, 56,
          63, 64, 65, 66, 67, 68, 69, 71, 78, 79, 80, 81, 82, 83, 84, 86,
          93, 94, 95, 96, 97, 98, 99, 101, 108, 109, 110, 111, 112, 113, 114, 116,
          121, 122, 123, 124, 125, 135, 136, 137, 138, 139, 140, 141, 142, 143,
          144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157,
          158, 159, 160, 161, 162]
}
```

**Exclusion rules:**

| Category | Example IDs | Rule | Reason |
|----------|-------------|------|---------|
| **Write params** | 12, 13, 14, 15, 27, 28... | ❌ Excluded | Control commands, not telemetry |
| **Feedback params** | 1, 2, 10, 16, 17... | ❌ Excluded | Internal verification only |
| **Monitoring params** | 3, 4, 5, 6, 7, 8, 9... | ✅ Included | Sensor/status data for cloud |

**Overlap with P2.MPI allowed:**

Many parameters appear in **both** P2.MPI and P3.MPI:

| Param ID | In P2.MPI | In P3.MPI | Purpose in P2 | Purpose in P3 |
|----------|-----------|-----------|---------------|---------------|
| 3 | ✅ Yes | ✅ Yes | Lua calculations | Cloud telemetry |
| 4 | ✅ Yes | ✅ Yes | Lua monitoring | Cloud telemetry |
| 18 | ✅ Yes | ✅ Yes | Lua calculations | Cloud telemetry |
| 12 | ✅ Yes | ❌ No | Lua write control | (Write param excluded) |
| 1 | ❌ No | ❌ No | (Feedback excluded) | (Feedback excluded) |

**Why overlap is allowed:**
- P2 and P3 serve different purposes
- P2: Lua needs value for logic
- P3: Cloud needs value for monitoring
- Same data, different destinations

### 5.3 P3.MDI - M_data Index

**Sequential indices [1-97]** for cloud output buffer:

```json
"P3": {
  "MDI": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18,
          19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34,
          ... (continues to 97)]
}
```

**MDI is local to P3:**
- Always starts from 1 (not continuing from P2)
- Independent numbering system
- Represents M_data array indices

**Mapping P3.MDI → P3.MPI:**

| MDI Index | P3.MDI Value | P3.MPI Value | Meaning |
|-----------|--------------|--------------|---------|
| 0 | 1 | 3 | M_data slot 1 → Parameter 3 |
| 1 | 2 | 4 | M_data slot 2 → Parameter 4 |
| 2 | 3 | 5 | M_data slot 3 → Parameter 5 |
| ... | ... | ... | ... |
| 96 | 97 | 162 | M_data slot 97 → Parameter 162 |

**Firmware synchronization (ParamMapConfig_Lib.cpp line 650):**
```cpp
// Every cloud transmission cycle (typically 5s):
for (uint16_t i = 0; i < p_MDMPNum; i++) {
  // Read from Modbus parameter PC3_MP[i].p_MPI
  float value = Modbus_ParmRead(PC3_MP[i].p_MPI);
  
  // Store in M_data at position PC3_MP[i].p_MDI - 1
  M_data[PC3_MP[i].p_MDI - 1] = value;
}
```

### 5.4 P3.LBI - Lua Calculated Values

**Currently empty in production:**
```json
"P3": {
  "LBI": []
}
```

**Purpose (if used):**
- Lua scripts can calculate derived values
- Example: Average temperature, efficiency ratio, energy consumption
- These calculated values added to M_data for cloud transmission

**Critical rule: P3.LBI continues from P2.MPI, NOT from P2.LBI total**

**Formula:**
```
P3.LBI Starting Value = (P2.MPI Count) + 1
                      = 59 + 1
                      = 60
```

**Why not starting from 73?**

**❌ WRONG assumption:**
```
P2.LBI total = 72
P3.LBI should start from 73?
NO! This would conflict with P2.RPCI.
```

**✅ CORRECT logic:**
```
P2.MPI occupies: LuaBuffVar[0-58] (59 slots)
P2.RPCI occupies: LuaBuffVar[59-71] (13 slots)
P3.LBI should occupy: LuaBuffVar[59-...] (continues from P2.MPI end)

Wait, that conflicts with RPCI!

Actually, the correct interpretation:
P3.LBI starts at position 59 (after P2.MPI), but these are
independent calculated values stored AFTER all P2 operations.
The LBI value itself is 60 (representing slot 60 in Lua buffer).
```

**Example scenario (if P3.LBI were used):**
```
P2.MPI Count = 59
Lua calculates 2 values from P3 monitoring:
  - Average temperature from sensors
  - Total power consumption

P3.LBI = [60, 61]

These get stored:
  LuaBuffVar[59] = calculated_avg_temp
  LuaBuffVar[60] = calculated_power

Then M_data includes:
  M_data[0-96]: P3.MPI parameters
  M_data[97]: LuaBuffVar[59] (calculated value 1)
  M_data[98]: LuaBuffVar[60] (calculated value 2)
```

### 5.5 P3.MDI Total Calculation

**Formula:**
```
Total P3.MDI Count = P3.MPI Count + P3.LBI Count
                   = 97 + 0
                   = 97
```

**M_data buffer memory layout:**
```
Index 0-96:   M_data[0-96]    → P3.MPI parameters (97 slots)
Index 97+:    M_data[97+]     → P3.LBI calculated values (0 currently)
Total: 97 slots
```

---

## 6. Complete Data Flow Diagrams

### 6.1 Modbus Read → Lua Buffer (Monitoring Path)

```
Step 1: Modbus Device
┌─────────────────────────────────────────┐
│ VFD/Sensor/Controller                    │
│ Physical Register 1561 = 455 (raw)      │
└──────────────────┬──────────────────────┘
                   │ Modbus RTU Read (FC03)
                   ↓
Step 2: Firmware Modbus Transaction
┌─────────────────────────────────────────┐
│ EMB.modbus_Read(slave=13, fc=3,         │
│                 address=1561, len=1)     │
│ Returns: raw_value = 455                 │
└──────────────────┬──────────────────────┘
                   │
                   ↓
Step 3: B5 Parameter Lookup
┌─────────────────────────────────────────┐
│ Application requests: Parameter ID=74    │
│ Lookup B5.ID[73] = 74                   │
│ Extract: B5.STA[73]=1561, B5.MLT[73]=0.1│
└──────────────────┬──────────────────────┘
                   │ Apply scaling
                   ↓
Step 4: Apply Multiplier
┌─────────────────────────────────────────┐
│ scaled_value = 455 × 0.1 = 45.5         │
└──────────────────┬──────────────────────┘
                   │
                   ↓
Step 5: Check P2.MPI
┌─────────────────────────────────────────┐
│ Is Parameter 74 in P2.MPI?              │
│ Search P2.MPI array for value 74        │
│ Found at: P2.MPI[25] = 74               │
└──────────────────┬──────────────────────┘
                   │ Found in P2
                   ↓
Step 6: Get LBI Mapping
┌─────────────────────────────────────────┐
│ P2.LBI[25] = 26                         │
│ (Lua buffer slot 26)                    │
└──────────────────┬──────────────────────┘
                   │ Store in Lua buffer
                   ↓
Step 7: Sync to Lua Buffer
┌─────────────────────────────────────────┐
│ LuaBuffVar[25] = 45.5                   │
│ (Array index 25, LBI value 26)          │
└──────────────────┬──────────────────────┘
                   │ Available to Lua
                   ↓
Step 8: Lua Script Access
┌─────────────────────────────────────────┐
│ FuncScript.lua:                          │
│   local temp = LuaBuffVar[26]           │
│   -- temp = 45.5                         │
│   if temp > 50 then                      │
│     -- Trigger cooling                   │
│   end                                    │
└─────────────────────────────────────────┘
```

### 6.2 Cloud → Lua Buffer → Modbus Write (Control Path)

```
Step 1: Cloud Platform
┌─────────────────────────────────────────┐
│ mDash Cloud Platform                     │
│ User clicks: "Set Chiller Setpoint=15°C"│
│ Sends MQTT: {"CmdID": 5, "CmdVal": 15}  │
└──────────────────┬──────────────────────┘
                   │ MQTT over internet
                   ↓
Step 2: Firmware RPC Handler
┌─────────────────────────────────────────┐
│ RPC_Lib.cpp: CmdID_Handler()            │
│ Parses: CmdID=5, CmdVal=15              │
└──────────────────┬──────────────────────┘
                   │ Lookup P2.RPCI
                   ↓
Step 3: RPCI Lookup
┌─────────────────────────────────────────┐
│ Find P2.RPCI[4] = 5 (index 4 for CmdID 5)│
│ Get LBI: Assume P2.RPCI[4] maps to LBI=64│
└──────────────────┬──────────────────────┘
                   │ Update Lua buffer
                   ↓
Step 4: Lua Buffer Update
┌─────────────────────────────────────────┐
│ LuaBuffVar[63] = 15.0                   │
│ (LBI=64 → array index 63)               │
└──────────────────┬──────────────────────┘
                   │ Lua script reads
                   ↓
Step 5: Lua Script Processing
┌─────────────────────────────────────────┐
│ FuncScript.lua:                          │
│   local setpoint = LuaBuffVar[64]       │
│   -- setpoint = 15.0                     │
│   Buff_Write(2, setpoint)                │
└──────────────────┬──────────────────────┘
                   │ Buff_Write call
                   ↓
Step 6: Paramap Write Lookup
┌─────────────────────────────────────────┐
│ Buff_Write(lbi=2, value=15)             │
│ Lookup: P2.LBI[1]=2 → P2.MPI[1]=12      │
│ Parameter ID = 12                        │
└──────────────────┬──────────────────────┘
                   │ B6 verification lookup
                   ↓
Step 7: B6 Write-Feedback Lookup
┌─────────────────────────────────────────┐
│ Search B6.WP for parameter 12           │
│ Found: B6.WP[0] = 12                    │
│ Get feedback: B6.RP[0] = 1              │
└──────────────────┬──────────────────────┘
                   │ Execute write
                   ↓
Step 8: B5 Write Parameter Lookup
┌─────────────────────────────────────────┐
│ Lookup B5.ID[11] = 12                   │
│ Get: B5.STA[11]=2, B5.FMT[11]=3         │
└──────────────────┬──────────────────────┘
                   │ Modbus write transaction
                   ↓
Step 9: Modbus Write
┌─────────────────────────────────────────┐
│ EMB.modbus_Write(slave=4, fc=6,         │
│                  address=2, value=15)    │
│ Device register 2 = 15                   │
└──────────────────┬──────────────────────┘
                   │ Verify write
                   ↓
Step 10: B5 Read Parameter Lookup (Verify)
┌─────────────────────────────────────────┐
│ Lookup B5.ID[0] = 1 (feedback param)    │
│ Get: B5.STA[0]=1, B5.FMT[0]=3           │
└──────────────────┬──────────────────────┘
                   │ Modbus read transaction
                   ↓
Step 11: Modbus Read (Verification)
┌─────────────────────────────────────────┐
│ EMB.modbus_Read(slave=4, fc=3,          │
│                 address=1, len=1)        │
│ Returns: verify_value = 15               │
└──────────────────┬──────────────────────┘
                   │ Compare values
                   ↓
Step 12: Verification Check
┌─────────────────────────────────────────┐
│ if (verify_value == 15) {               │
│   return WRITE_SUCCESS;                  │
│ } else {                                 │
│   return VERIFY_FAIL;                    │
│ }                                        │
└─────────────────────────────────────────┘
```

### 6.3 Modbus Read → M_data → Cloud (Telemetry Path)

```
Step 1: Modbus Devices (Multiple)
┌─────────────────────────────────────────┐
│ Sensor 1: Param 3 = 25.5°C              │
│ Sensor 2: Param 4 = 45.2%               │
│ VFD 1: Param 5 = 50Hz                   │
│ ... (97 parameters total)                │
└──────────────────┬──────────────────────┘
                   │ Modbus reads (batch)
                   ↓
Step 2: Firmware Modbus Scan
┌─────────────────────────────────────────┐
│ Loop through all P3.MPI parameters:      │
│ for (i=0; i<97; i++) {                  │
│   param_id = P3.MPI[i];                 │
│   value = Modbus_ParmRead(param_id);    │
│ }                                        │
└──────────────────┬──────────────────────┘
                   │ Store in M_data
                   ↓
Step 3: M_data Buffer Sync
┌─────────────────────────────────────────┐
│ ParamMapConfig_Lib.cpp line 650:        │
│ M_data[0] = Modbus_ParmRead(3)  = 25.5  │
│ M_data[1] = Modbus_ParmRead(4)  = 45.2  │
│ M_data[2] = Modbus_ParmRead(5)  = 50.0  │
│ ... (continues for all 97 values)        │
└──────────────────┬──────────────────────┘
                   │ Build JSON
                   ↓
Step 4: JKY Structure Lookup
┌─────────────────────────────────────────┐
│ JKA[0] = ["Cd_Pu1_DIE1", ["St"],        │
│           ["VFDRun"]]                    │
│ Maps to M_data[0] = 25.5                 │
└──────────────────┬──────────────────────┘
                   │ JSON generation
                   ↓
Step 5: JSON Construction
┌─────────────────────────────────────────┐
│ Com_Lib.cpp: MQTT_JSON_Payload_WJ()     │
│ {                                        │
│   "Cd_Pu1_DIE1": {                      │
│     "St": {                              │
│       "VFDRun": 25.5                     │
│     }                                    │
│   },                                     │
│   "Cd_Pu1_Mb1": { ... },                │
│   ... (all 97 values mapped)             │
│ }                                        │
└──────────────────┬──────────────────────┘
                   │ MQTT publish
                   ↓
Step 6: MQTT Transmission
┌─────────────────────────────────────────┐
│ Topic: /v2/<device_id>/shadow/state     │
│ Payload: Complete JSON (all 97 values)  │
│ Frequency: Every 5 seconds              │
└──────────────────┬──────────────────────┘
                   │ Internet
                   ↓
Step 7: Cloud Platform
┌─────────────────────────────────────────┐
│ mDash Cloud Platform                     │
│ - Stores in time-series database         │
│ - Updates real-time dashboard            │
│ - Triggers alarms if thresholds exceeded │
│ - Available for historical analysis      │
└─────────────────────────────────────────┘
```

---

## 7. Key Relationships & Rules

### 7.1 Fundamental Rules

**Rule 1: B5 is the Master Database**
- All parameter IDs (1-163) are defined in B5
- P2.MPI values are B5.ID references
- P3.MPI values are B5.ID references
- B6.WP values are B5.ID references
- B6.RP values are B5.ID references

**Rule 2: B6.RP is Isolated**
- B6.RP parameters NEVER appear in P2.MPI
- B6.RP parameters NEVER appear in P3.MPI
- B6.RP is only for write verification
- Accessed via direct Modbus read, not Lua buffer

**Rule 3: P2.MPI and P3.MPI Can Overlap**
- Same parameter can be in both P2 and P3
- Example: Parameter 3 in both
  - P2: Used by Lua for calculations
  - P3: Sent to cloud for telemetry
- Different purposes, same data source

**Rule 4: P2.LBI is Globally Continuous**
- Starts at 1, no gaps
- Covers P2.MPI (59 slots) + P2.RPCI (13 slots)
- Total: 72 sequential slots
- Represents complete Lua buffer

**Rule 5: P3.LBI Continues from P2.MPI**
- Does NOT start from 1
- Does NOT continue from P2.LBI total (72)
- Starts from (P2.MPI Count + 1) = 60
- Avoids conflict with P2.RPCI slots

**Rule 6: P3.MDI is Local to P3**
- Always starts from 1
- Independent of P2 numbering
- Represents M_data array indices
- Total = P3.MPI Count + P3.LBI Count

**Rule 7: Write Parameters in P2, Not P3**
- B6.WP parameters (12, 13, 14, 15...) can be in P2.MPI
- B6.WP parameters are NEVER in P3.MPI
- P3 is monitoring-only, no control parameters

### 7.2 Buffer Memory Layouts

**Lua Buffer (LuaBuffVar array):**
```
Index  | LBI  | Source         | Example Content
-------|------|----------------|------------------
0      | 1    | P2.MPI[0]=3   | Temperature value
1      | 2    | P2.MPI[1]=12  | Setpoint write param
2      | 3    | P2.MPI[2]=13  | Another write param
...    | ...  | ...            | ...
58     | 59   | P2.MPI[58]=163| Last MPI parameter
59     | 60   | P2.RPCI[0]=1  | RPC command 1
60     | 61   | P2.RPCI[1]=2  | RPC command 2
...    | ...  | ...            | ...
71     | 72   | P2.RPCI[12]=13| RPC command 13
(72+)  | (60+)| P3.LBI (if any)| Calculated values
```

**M_data Buffer (M_data array):**
```
Index  | MDI  | Source         | Example Content
-------|------|----------------|------------------
0      | 1    | P3.MPI[0]=3   | Temperature value
1      | 2    | P3.MPI[1]=4   | Humidity value
2      | 3    | P3.MPI[2]=5   | Frequency value
...    | ...  | ...            | ...
96     | 97   | P3.MPI[96]=162| Last MPI parameter
(97+)  | (98+)| P3.LBI (if any)| Calculated values
```

### 7.3 Index Arithmetic

**P2.MPI to LBI conversion:**
```c
// Given: Parameter ID (e.g., 74)
// Find in P2.MPI array
for (int i = 0; i < p_LBMPNum; i++) {
  if (PC2_MP[i].p_MPI == 74) {
    lbi = PC2_MP[i].p_LBI;        // Get LBI value
    array_index = lbi - 1;         // Convert to 0-based index
    value = LuaBuffVar[array_index];
  }
}
```

**P3.MPI to MDI conversion:**
```c
// Given: Parameter ID (e.g., 74)
// Find in P3.MPI array
for (int i = 0; i < p_MDMPNum; i++) {
  if (PC3_MP[i].p_MPI == 74) {
    mdi = PC3_MP[i].p_MDI;         // Get MDI value
    array_index = mdi - 1;          // Convert to 0-based index
    value = M_data[array_index];
  }
}
```

**LBI to Parameter ID conversion:**
```c
// Given: LBI value from Lua script (e.g., 26)
// Convert to array index
array_index = 26 - 1;  // = 25

// Lookup parameter ID
if (array_index < p_LBMPNum) {
  param_id = PC2_MP[array_index].p_MPI;
} else {
  // It's an RPCI slot
  rpci_index = array_index - p_LBMPNum;
  // RPCI[rpci_index]
}
```

---

## 8. Parameter Examples

### 8.1 Example 1: Parameter 12 (Write Setpoint)

**Definition in B5:**
```
B5.ID[11] = 12
B5.PN[11] = 5       // Modbus packet 5
B5.STA[11] = 2      // Register address 2
B5.LN[11] = 1       // Single register
B5.FMT[11] = 3      // uint16 format
B5.MLT[11] = 1.0    // No scaling
Slave: 4, Function Code: 6 (Write Single Register)
```

**Presence in B6:**
```
B6.WP[0] = 12       // This is a write parameter
B6.RP[0] = 1        // Verify with parameter 1
```

**Presence in P2:**
```
P2.MPI[1] = 12      // Available to Lua for write operations
P2.LBI[1] = 2       // Lua buffer slot 2
```

**Presence in P3:**
```
NOT PRESENT         // Write parameters excluded from cloud
```

**Complete flow for writing parameter 12:**
```
1. Cloud sends: {"CmdID": 3, "CmdVal": 50}
2. RPC handler: LuaBuffVar[RPC_slot] = 50
3. Lua script: local cmd = LuaBuffVar[RPC_slot]
               Buff_Write(2, cmd)  -- LBI=2 → Param 12
4. Firmware: Lookup P2.LBI[1]=2 → P2.MPI[1]=12
5. Firmware: Lookup B6.WP[0]=12 → B6.RP[0]=1
6. Firmware: Write to param 12 (register 2, value 50)
7. Firmware: Read from param 1 (register 1, verify)
8. Firmware: Compare and return WRITE_SUCCESS
```

### 8.2 Example 2: Parameter 1 (Feedback Read)

**Definition in B5:**
```
B5.ID[0] = 1
B5.PN[0] = 1        // Modbus packet 1
B5.STA[0] = 1       // Register address 1
B5.LN[0] = 1        // Single register
B5.FMT[0] = 3       // uint16 format
B5.MLT[0] = 1.0     // No scaling
Slave: 4, Function Code: 3 (Read Holding Registers)
```

**Presence in B6:**
```
B6.RP[0] = 1        // Feedback parameter for write param 12
NOT in B6.WP        // Not a write parameter
```

**Presence in P2:**
```
NOT PRESENT         // Feedback params excluded from Lua buffer
```

**Presence in P3:**
```
NOT PRESENT         // Feedback params excluded from cloud
```

**Usage:**
```
Only accessed during write verification:
1. User writes to parameter 12
2. Firmware automatically reads parameter 1 (feedback)
3. Compares written value with feedback value
4. Returns verification result
```

### 8.3 Example 3: Parameter 74 (Temperature Sensor)

**Definition in B5:**
```
B5.ID[73] = 74
B5.PN[73] = 74      // Modbus packet 74
B5.STA[73] = 1561   // Register address 1561
B5.LN[73] = 1       // Single register
B5.FMT[73] = 3      // uint16 format
B5.MLT[73] = 0.1    // Scale by 0.1 (e.g., 455 → 45.5°C)
Slave: 13, Function Code: 3 (Read Holding Registers)
```

**Presence in B6:**
```
NOT PRESENT         // Not a write parameter
NOT PRESENT         // Not a feedback parameter
```

**Presence in P2:**
```
P2.MPI[?] = 74      // Assume present for Lua calculations
P2.LBI[?] = ?       // Some LBI slot
```

**Presence in P3:**
```
P3.MPI[?] = 74      // Present for cloud telemetry
P3.MDI[?] = ?       // Some MDI slot
```

**Complete flow for reading parameter 74:**
```
1. Firmware: Every 1s scan cycle
2. Modbus Read: slave=13, fc=3, address=1561, length=1
3. Returns: raw_value = 455
4. Apply scaling: 455 × 0.1 = 45.5
5. P2 sync: LuaBuffVar[LBI_slot] = 45.5
6. P3 sync: M_data[MDI_slot] = 45.5
7. Lua access: temp = LuaBuffVar[LBI_slot]
8. Cloud JSON: {"Sensor": {"Temp": 45.5}}
```

### 8.4 Example 4: Parameter 3 (Monitoring, in both P2 and P3)

**Definition in B5:**
```
B5.ID[2] = 3
B5.PN[2] = 3        // Modbus packet 3
B5.STA[2] = 32      // Register address 32
B5.LN[2] = 1        // Single register
B5.FMT[2] = 3       // uint16 format
B5.MLT[2] = 1.0     // No scaling
Slave: 4, Function Code: 3 (Read Holding Registers)
```

**Presence in B6:**
```
NOT PRESENT         // Not a write or feedback parameter
```

**Presence in P2:**
```
P2.MPI[0] = 3       // First entry in P2
P2.LBI[0] = 1       // Lua buffer slot 1
```

**Presence in P3:**
```
P3.MPI[0] = 3       // First entry in P3
P3.MDI[0] = 1       // M_data slot 1
```

**Complete flow for parameter 3:**
```
1. Firmware: Every 1s scan cycle
2. Modbus Read: slave=4, fc=3, address=32, length=1
3. Returns: value = 25
4. P2 sync: LuaBuffVar[0] = 25  (LBI=1)
5. P3 sync: M_data[0] = 25       (MDI=1)
6. Lua access: val = LuaBuffVar[1]
7. Cloud JSON: {"Equipment": {"Status": 25}}

Same data, two destinations:
- Lua buffer: For control logic
- M_data: For cloud telemetry
```

---

## 9. Quick Reference Tables

### 9.1 Block Summary

| Block | Contains | Count | Purpose | Indexing |
|-------|----------|-------|---------|----------|
| **B5** | All Modbus params | 163 | Master database | 1-based parameter ID |
| **B6.WP** | Write params | 33 | Write operations | Index-matched with RP |
| **B6.RP** | Feedback params | 33 | Write verification | Index-matched with WP |
| **P2.MPI** | Lua input params | 59 | Modbus→Lua sync | B5.ID references |
| **P2.LBI** | Lua buffer slots (MPI) | 59 | Lua access index | 1-59 sequential |
| **P2.RPCI** | RPC command slots | 13 | Cloud→Lua control | 1-13 sequential |
| **P2.LBI (total)** | All Lua slots | 72 | Full Lua buffer | 1-72 sequential |
| **P3.MPI** | Cloud output params | 97 | Modbus→Cloud sync | B5.ID references |
| **P3.MDI** | M_data buffer slots | 97 | Cloud transmission | 1-97 sequential |
| **P3.LBI** | Lua calculated values | 0 | Derived values (unused) | Continues from P2.MPI+1 |

### 9.2 Parameter Inclusion Matrix

| Parameter Type | Example IDs | In B5 | In B6.WP | In B6.RP | In P2.MPI | In P3.MPI |
|----------------|-------------|-------|----------|----------|-----------|-----------|
| **Write** | 12, 13, 14, 15 | ✅ | ✅ | ❌ | ✅ | ❌ |
| **Feedback** | 1, 2, 9, 10 | ✅ | ❌ | ✅ | ❌ | ❌ |
| **Monitoring (P2+P3)** | 3, 4, 18, 19 | ✅ | ❌ | ❌ | ✅ | ✅ |
| **Monitoring (P3 only)** | 5, 6, 7, 8 | ✅ | ❌ | ❌ | ❌ | ✅ |

### 9.3 Data Flow Summary

| Path | Source | Destination | Frequency | Purpose |
|------|--------|-------------|-----------|---------|
| **Monitoring** | Modbus → P2.MPI | Lua Buffer | ~1s | Lua calculations |
| **Control** | Cloud → P2.RPCI | Lua Buffer | On-demand | Remote control |
| **Write** | Lua → P2.MPI | Modbus | On-command | Device control |
| **Verify** | Modbus → B6.RP | Firmware | After write | Write verification |
| **Telemetry** | Modbus → P3.MPI | M_data → Cloud | ~5s | Cloud monitoring |

### 9.4 Buffer Size Calculations

| Buffer | Formula | Current Values | Total Size |
|--------|---------|----------------|------------|
| **Lua Buffer** | P2.MPI + P2.RPCI + P3.LBI | 59 + 13 + 0 | **72 floats** |
| **M_data Buffer** | P3.MPI + P3.LBI | 97 + 0 | **97 floats** |

### 9.5 Firmware Functions Reference

| Function | File | Line | Purpose |
|----------|------|------|---------|
| `Modbus_ParmRead()` | MBConfig_Lib.cpp | 463 | Read parameter from Modbus |
| `Modbus_ParmWrite()` | MBConfig_Lib.cpp | 511 | Write parameter with verification |
| `Map_LuaBuffVarSync()` | ParamMapConfig_Lib.cpp | 575 | Sync P2.MPI to Lua buffer |
| `Map_MdataBuffSync()` | ParamMapConfig_Lib.cpp | 647 | Sync P3.MPI to M_data |
| `CmdID_Handler()` | RPC_Lib.cpp | 24 | Handle cloud RPC commands |
| `MQTT_JSON_Payload_WJ()` | Com_Lib.cpp | 547 | Build JSON from M_data |

### 9.6 Configuration Files

| File | Purpose | Location |
|------|---------|----------|
| `Modbus_Config.json` | B5 and B6 definitions | `/data/` |
| `ParamMap_Config.json` | P2 and P3 definitions | `/data/` |
| `FuncScript.lua` | Lua control logic | `/data/` |

---

## 10. Conclusion

This document provides the complete logical structure of the Paramap system. Key takeaways:

1. **B5 is the master database** - All parameters defined here
2. **B6 handles write verification** - B6.RP never in P2/P3
3. **P2 bridges Modbus and Lua** - 59 params + 13 RPC commands
4. **P3 bridges Modbus and Cloud** - 97 monitoring parameters
5. **Overlap is allowed** - Same param in P2 and P3 for different purposes
6. **Indexing is critical** - LBI/MDI determine buffer positions
7. **Three data flows** - Control, Monitoring, Telemetry

Understanding these relationships is essential for:
- Firmware development
- Application configuration
- Lua script programming
- Cloud integration
- System debugging

---

**Document Version:** 2.0  
**Last Updated:** February 5, 2026  
**Validated Against:** Firmware V5.7.0
