"""
Compare generated output with original firmware JSON to verify implementation
"""

import json
from forward_engine import ForwardTransformationEngine

print("=" * 70)
print("FIRMWARE COMPLIANCE VERIFICATION")
print("=" * 70)

# Load original firmware JSONs
with open('c:\\Users\\DELL\\Downloads\\Original Modbus JSON.json', 'r') as f:
    original_modbus = json.load(f)

with open('c:\\Users\\DELL\\Downloads\\Original Paramap JSON.json', 'r') as f:
    original_paramap = json.load(f)

# Load our register config
with open('../register_config_from_original.json', 'r') as f:
    register_config = json.load(f)

# Generate using our engine
engine = ForwardTransformationEngine()
gen_modbus, gen_paramap = engine.transform(register_config)

print("\n" + "=" * 70)
print("STRUCTURAL COMPARISON")
print("=" * 70)

# Compare key structures
comparisons = []

# P1.NMD
comparisons.append({
    "Component": "P1.NMD",
    "Original": original_paramap['P1']['NMD'],
    "Generated": gen_paramap['P1']['NMD'],
    "Match": original_paramap['P1']['NMD'] == gen_paramap['P1']['NMD']
})

# P2.MPI count
comparisons.append({
    "Component": "P2.MPI count",
    "Original": len(original_paramap['P2']['MPI']),
    "Generated": len(gen_paramap['P2']['MPI']),
    "Match": len(original_paramap['P2']['MPI']) == len(gen_paramap['P2']['MPI'])
})

# P2.LBI count
comparisons.append({
    "Component": "P2.LBI count",
    "Original": len(original_paramap['P2']['LBI']),
    "Generated": len(gen_paramap['P2']['LBI']),
    "Match": len(original_paramap['P2']['LBI']) == len(gen_paramap['P2']['LBI'])
})

# P2.RPCI count
comparisons.append({
    "Component": "P2.RPCI count",
    "Original": len(original_paramap['P2']['RPCI']),
    "Generated": len(gen_paramap['P2']['RPCI']),
    "Match": len(original_paramap['P2']['RPCI']) == len(gen_paramap['P2']['RPCI'])
})

# P3.MPI count
comparisons.append({
    "Component": "P3.MPI count",
    "Original": len(original_paramap['P3']['MPI']),
    "Generated": len(gen_paramap['P3']['MPI']),
    "Match": len(original_paramap['P3']['MPI']) == len(gen_paramap['P3']['MPI'])
})

# P3.MDI count
comparisons.append({
    "Component": "P3.MDI count",
    "Original": len(original_paramap['P3']['MDI']),
    "Generated": len(gen_paramap['P3']['MDI']),
    "Match": len(original_paramap['P3']['MDI']) == len(gen_paramap['P3']['MDI'])
})

# B6.WP count
comparisons.append({
    "Component": "B6.WP count",
    "Original": len(original_modbus['B6']['WP']),
    "Generated": len(gen_modbus['B6']['WP']),
    "Match": len(original_modbus['B6']['WP']) == len(gen_modbus['B6']['WP'])
})

# B6.RP count
comparisons.append({
    "Component": "B6.RP count",
    "Original": len(original_modbus['B6']['RP']),
    "Generated": len(gen_modbus['B6']['RP']),
    "Match": len(original_modbus['B6']['RP']) == len(gen_modbus['B6']['RP'])
})

# Print table
print(f"\n{'Component':<20} {'Original':<12} {'Generated':<12} {'Status'}")
print("-" * 70)
for comp in comparisons:
    status = "✅ MATCH" if comp['Match'] else "❌ DIFFER"
    print(f"{comp['Component']:<20} {str(comp['Original']):<12} {str(comp['Generated']):<12} {status}")

print("\n" + "=" * 70)
print("DETAILED ARRAY COMPARISON")
print("=" * 70)

# Check if P2.MPI content matches
print("\n### P2.MPI Content Check ###")
orig_p2_mpi = set(original_paramap['P2']['MPI'])
gen_p2_mpi = set(gen_paramap['P2']['MPI'])
only_in_orig = orig_p2_mpi - gen_p2_mpi
only_in_gen = gen_p2_mpi - orig_p2_mpi
common = orig_p2_mpi & gen_p2_mpi

print(f"Common params: {len(common)} / {len(orig_p2_mpi)} ({len(common)/len(orig_p2_mpi)*100:.1f}%)")
if only_in_orig:
    print(f"Only in original (first 10): {sorted(list(only_in_orig))[:10]}")
if only_in_gen:
    print(f"Only in generated (first 10): {sorted(list(only_in_gen))[:10]}")

# Check if P3.MPI content matches
print("\n### P3.MPI Content Check ###")
orig_p3_mpi = set(original_paramap['P3']['MPI'])
gen_p3_mpi = set(gen_paramap['P3']['MPI'])
only_in_orig = orig_p3_mpi - gen_p3_mpi
only_in_gen = gen_p3_mpi - orig_p3_mpi
common = orig_p3_mpi & gen_p3_mpi

print(f"Common params: {len(common)} / {len(orig_p3_mpi)} ({len(common)/len(orig_p3_mpi)*100:.1f}%)")
if only_in_orig:
    print(f"Only in original (first 10): {sorted(list(only_in_orig))[:10]}")
if only_in_gen:
    print(f"Only in generated (first 10): {sorted(list(only_in_gen))[:10]}")

# Check sequential arrays
print("\n### Sequential Arrays Check ###")
p2_lbi_correct = gen_paramap['P2']['LBI'] == list(range(1, len(gen_paramap['P2']['LBI']) + 1))
p2_rpci_correct = gen_paramap['P2']['RPCI'] == list(range(1, 14))
p3_mdi_correct = gen_paramap['P3']['MDI'] == list(range(1, len(gen_paramap['P3']['MDI']) + 1))

print(f"P2.LBI sequential [1-{len(gen_paramap['P2']['LBI'])}]: {'✅' if p2_lbi_correct else '❌'}")
print(f"P2.RPCI sequential [1-13]: {'✅' if p2_rpci_correct else '❌'}")
print(f"P3.MDI sequential [1-{len(gen_paramap['P3']['MDI'])}]: {'✅' if p3_mdi_correct else '❌'}")

# Check B6.RP exclusion
print("\n### B6.RP Exclusion Rule Check ###")
rp_params = set(gen_modbus['B6']['RP'])
rp_in_p2 = rp_params & gen_p2_mpi
rp_in_p3 = rp_params & gen_p3_mpi

print(f"B6.RP params in P2.MPI: {len(rp_in_p2)} (should be 0)")
if rp_in_p2:
    print(f"  Found: {sorted(list(rp_in_p2))}")
print(f"B6.RP params in P3.MPI: {len(rp_in_p3)} (should be 0)")
if rp_in_p3:
    print(f"  Found: {sorted(list(rp_in_p3))}")

if len(rp_in_p2) == 0 and len(rp_in_p3) == 0:
    print("✅ B6.RP exclusion rule: CORRECT")
else:
    print("❌ B6.RP exclusion rule: VIOLATED")

print("\n" + "=" * 70)
print("FIRMWARE COMPLIANCE SUMMARY")
print("=" * 70)

# Calculate overall compliance
all_match = all(c['Match'] for c in comparisons)
structure_correct = p2_lbi_correct and p2_rpci_correct and p3_mdi_correct
rp_exclusion_correct = len(rp_in_p2) == 0 and len(rp_in_p3) == 0

print(f"\nStructural Counts: {'✅ MATCH' if all_match else '❌ DIFFER'}")
print(f"Sequential Arrays: {'✅ CORRECT' if structure_correct else '❌ INCORRECT'}")
print(f"B6.RP Exclusion: {'✅ CORRECT' if rp_exclusion_correct else '❌ VIOLATED'}")

if all_match and structure_correct and rp_exclusion_correct:
    print(f"\n{'='*70}")
    print("✅✅✅ FULL FIRMWARE COMPLIANCE ACHIEVED ✅✅✅")
    print(f"{'='*70}")
else:
    print(f"\n{'='*70}")
    print("⚠️  PARTIAL COMPLIANCE - Some differences found")
    print(f"{'='*70}")
