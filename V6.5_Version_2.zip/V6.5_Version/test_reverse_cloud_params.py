import json
import sys
sys.path.append('c:/Users/DELL/Documents/GitHub/Thermelgy-Gway-BMIoT/V6.5_Version')

from reverse_engine import ReverseTransformationEngine

# Load original JSON files
with open('c:/Users/DELL/Downloads/Original Modbus JSON.json') as f:
    modbus_json = json.load(f)

with open('c:/Users/DELL/Downloads/Original Paramap JSON.json') as f:
    paramap_json = json.load(f)

# Run reverse transform
engine = ReverseTransformationEngine()
result = engine.transform(modbus_json, paramap_json)

print(f"Total registers extracted: {len(result['registers'])}")

# Check cloud params
cloud_regs = [r for r in result['registers'] if r.get('cloud') == 'Yes']
print(f"Registers with cloud='Yes': {len(cloud_regs)}")

# Check missing JSON keys
no_keys = [r for r in cloud_regs if not r.get('json_group') or not r.get('json_unit') or not r.get('json_key')]
print(f"Cloud='Yes' but missing JSON keys: {len(no_keys)}")

if no_keys:
    print(f"\nFirst 10 examples:")
    for r in no_keys[:10]:
        print(f"  B5.ID {r['param_id']}: cloud={r.get('cloud')}, "
              f"group='{r.get('json_group')}', "
              f"unit='{r.get('json_unit')}', "
              f"key='{r.get('json_key')}', "
              f"access={r.get('access')}")

# Also check which params are in P3.MPI
p3_mpi = paramap_json['P3']['MPI']
print(f"\nP3.MPI has {len(p3_mpi)} params")

# Check if all cloud='Yes' params are in P3.MPI
cloud_ids = [r['param_id'] for r in cloud_regs]
in_p3 = [pid for pid in cloud_ids if pid in p3_mpi]
print(f"Cloud='Yes' params that ARE in P3.MPI: {len(in_p3)}")
not_in_p3 = [pid for pid in cloud_ids if pid not in p3_mpi]
if not_in_p3:
    print(f"Cloud='Yes' params that are NOT in P3.MPI: {not_in_p3[:5]}")
