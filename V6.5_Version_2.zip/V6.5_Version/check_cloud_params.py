import json

# Load register config
with open('c:/Users/DELL/Documents/GitHub/Thermelgy-Gway-BMIoT/register_config_from_original.json') as f:
    data = json.load(f)

regs = data['registers']
cloud_regs = [r for r in regs if r.get('cloud')]

print(f'Total registers: {len(regs)}')
print(f'Cloud=True registers: {len(cloud_regs)}')

no_keys = [r for r in cloud_regs if not r.get('json_group') or not r.get('json_unit') or not r.get('json_key')]
print(f'Cloud=True but missing JSON keys: {len(no_keys)}')

if no_keys:
    print(f'\nFirst 5 examples of cloud=True with missing JSON keys:')
    for r in no_keys[:5]:
        print(f"  Param {r['param_id']}: cloud={r.get('cloud')}, "
              f"group='{r.get('json_group')}', "
              f"unit='{r.get('json_unit')}', "
              f"key='{r.get('json_key')}'")
