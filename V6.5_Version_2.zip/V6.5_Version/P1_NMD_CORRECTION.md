# P1.NMD Correction - Critical Fix

## Issue Summary

**Problem:** P1.NMD was calculated incorrectly as `len(P2.MPI) + len(P3.MPI) + len(P3.LBI)`  
**Correct Formula:** P1.NMD = `len(P3.MPI)`  
**Severity:** CRITICAL - Affects firmware memory allocation

## Evidence from Original Firmware

### Original Paramap JSON Example:
```json
{
  "P1": { "NMD": 97 },
  "P2": {
    "MPI": [59 parameters],
    "LBI": [72 indices]
  },
  "P3": {
    "MPI": [97 parameters],
    "MDI": [97 indices]
  }
}
```

### Analysis:
- **P3.MPI count:** 97 parameters
- **P3.MDI count:** 97 indices (always equals P3.MPI count)
- **P1.NMD:** 97 ✅

**If using wrong formula:**
- P2.MPI (59) + P3.MPI (97) + P3.LBI (0) = **156** ❌

**Correct formula:**
- P3.MPI count = **97** ✅

## What is NMD?

**NMD = Number of Monitoring Data**

This represents the count of monitoring parameters that are sent to the cloud (P3.MPI). The firmware uses this value to allocate memory for the M_data buffer that stores cloud monitoring data.

## Code Fix

### Before (WRONG):
```python
def _build_p1(self) -> Dict:
    """P1.NMD = len(P2.MPI) + len(P3.MPI) + len(P3.LBI)"""
    p2 = self._build_p2()
    p3 = self._build_p3()
    
    return {
        "NMD": len(p2["MPI"]) + len(p3["MPI"]) + len(p3["LBI"])  # ❌ WRONG
    }
```

### After (CORRECT):
```python
def _build_p1(self) -> Dict:
    """P1.NMD = Number of Monitoring Data = len(P3.MPI)"""
    p3 = self._build_p3()
    
    return {
        "NMD": len(p3["MPI"])  # ✅ CORRECT
    }
```

## Test Results

### Unit Tests: ✅ PASSED
```
P3.MPI count: 1
P1.NMD: 1
✅ P1.NMD correct!
```

### Production Tests: ✅ PASSED
```
P3.MPI count: 130
P1.NMD: 130
✅ P1.NMD correct!
```

### Original Example Validation: ✅ PASSED
```
P3.MPI count: 97
P3.MDI count: 97
P1.NMD: 97
✅ VALIDATION PASSED!
```

### Round-Trip Test: ✅ PASSED
```
[Forward] P1.NMD: 130
[Reverse] Reconstructed 163 parameters
[Forward] P1.NMD: 130
✅ P1.NMD identical: 130
```

## Impact Analysis

### Before Fix (Production Data):
- **Generated NMD:** 293 (163 + 130 + 0)
- **Correct NMD:** 130
- **Error:** 163 extra entries (125% oversized)
- **Firmware Impact:** Would allocate 2.25x more memory than needed

### After Fix (Production Data):
- **Generated NMD:** 130 ✅
- **Correct NMD:** 130 ✅
- **Error:** 0
- **Firmware Impact:** Correct memory allocation

## Why This Matters

1. **Memory Allocation:** Firmware allocates M_data buffer based on NMD
2. **Cloud Data:** NMD represents monitoring params sent to cloud (P3.MPI)
3. **Buffer Indexing:** P3.MDI uses sequential indices [1-NMD] for M_data
4. **Firmware Stability:** Wrong NMD could cause memory issues

## Correct Understanding

| Component | Meaning | Count |
|-----------|---------|-------|
| P3.MPI | Parameter IDs sent to cloud | Variable (97 in example) |
| P3.MDI | Sequential indices for M_data | Always = len(P3.MPI) |
| P1.NMD | Number of Monitoring Data | Always = len(P3.MPI) |

**Key Insight:** NMD is specifically about **cloud monitoring data** (P3), not all monitoring data (P2 + P3).

## Files Modified

1. **forward_engine.py**
   - Line ~299-321: Updated `_build_p1()` function
   - Changed: `NMD = len(p2["MPI"]) + len(p3["MPI"]) + len(p3["LBI"])`
   - To: `NMD = len(p3["MPI"])`

2. **test_paramap_logic_fix.py**
   - Line ~168-178: Updated P1.NMD test expectations

3. **test_production_paramap_fix.py**
   - Line ~27-35: Updated P1.NMD validation logic

## Validation Summary

| Test | Expected | Generated | Status |
|------|----------|-----------|--------|
| Unit Test | 1 | 1 | ✅ |
| Production Test | 130 | 130 | ✅ |
| Original Example | 97 | 97 | ✅ |
| Round-Trip | 130 | 130 | ✅ |

## Conclusion

✅ **P1.NMD is now correctly calculated as `len(P3.MPI)`**

This matches the original firmware example and ensures proper memory allocation for cloud monitoring data. All tests are passing with the corrected formula.

**Status:** Production Ready ✅
