"""Test GUI application initialization"""
import tkinter as tk
import sys

try:
    print('Testing GUI initialization...')
    # Import with correct module name (dots in filename)
    import importlib.util
    spec = importlib.util.spec_from_file_location("app", "modbus_tkinter_app_v6.6_complete.py")
    app_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(app_module)
    
    ModbusConfigApp = app_module.ModbusConfigGenerator
    RegisterEntry = app_module.RegisterEntry
    
    root = tk.Tk()
    app = ModbusConfigApp(root)
    
    print('[SUCCESS] GUI initialized successfully')
    print(f'  - Tree widget has {len(app.tree["columns"])} columns')
    print(f'  - Tree display columns: {len(app.tree["displaycolumns"])}')
    print('  - All components loaded without errors')
    
    # Verify RegisterEntry can be created
    test_reg = RegisterEntry(
        param_id=1, slave_id=1, fc=3, address=100, length=1, fmt=3,
        multiplier=1.0, access='R', cloud='Yes', json_group='Test',
        json_unit='Unit', json_key='Key'
    )
    print(f'  - RegisterEntry has {len(vars(test_reg))} fields')
    print(f'  - Equipment fields present: {hasattr(test_reg, "equipment_group")}')
    
    root.destroy()
    print('[PASS] GUI test complete - application is ready to run')
    print('\nTo run the application, execute:')
    print('  python modbus_tkinter_app_v6_6_complete.py')
    
except Exception as e:
    print(f'[FAIL] GUI initialization error: {str(e)}')
    import traceback
    traceback.print_exc()
    sys.exit(1)
