# Firmware vs Implementation Comparison Analysis

## Executive Summary

Analyzing current implementation against firmware specification (PARAMAP_COMPLETE_LOGIC_GUIDE.md) to identify discrepancies.

## Analysis Results

### ✅ CORRECT Implementations

| Component | Firmware Spec | Current Implementation | Status |
|-----------|---------------|------------------------|--------|
| **P1.NMD** | len(P3.MPI) | len(P3.MPI) | ✅ CORRECT |
| **P2.LBI Structure** | Sequential [1...N] | Sequential [1...N] | ✅ CORRECT |
| **P2.RPCI Structure** | Sequential [1-13] | Sequential [1-13] | ✅ CORRECT |
| **P3.MDI Structure** | Sequential [1...M] | Sequential [1...M] | ✅ CORRECT |
| **B6.RP Exclusion** | RP never in P2/P3 | Excluded via parameter_type check | ✅ CORRECT |
| **P2/P3 Overlap** | Allowed | Allowed | ✅ CORRECT |

### ❌ ISSUES FOUND

#### Issue 1: P2.MPI Classification Logic - CRITICAL
**Firmware Spec:**
- P2.MPI contains 59 parameters
- Includes: Write params (B6.WP) + Monitoring params needed by Lua
- Excludes: Feedback params (B6.RP)
- Example from firmware: `P2.MPI = [3, 12, 13, 14, 15, 18, 27, 28, ...]`

**Current Implementation:**
```python
# Rule 1: Include write parameters
for param_id in sorted(write_params):
    mpi.append(param_id)

# Rule 2: Include monitoring parameters
for r in sorted(self.registers, key=lambda x: x.param_id):
    if r.param_id not in feedback_params and r.param_id not in mpi:
        if r.parameter_type == "read_only" or r.access == "R":
            mpi.append(r.param_id)
```

**Problem:**
Currently includes ALL monitoring params (163 total) instead of just those needed by Lua (59 total).

**Firmware Logic:**
Not all monitoring parameters are needed in Lua buffer. The firmware explicitly selects which monitoring params go to P2.MPI based on whether Lua scripts actually use them.

**Evidence from Original:**
- Total monitoring params: ~130
- P2.MPI count: 59 (only those Lua needs)
- P3.MPI count: 97 (all cloud monitoring)

#### Issue 2: P3.MPI Classification Logic - CRITICAL
**Firmware Spec:**
- P3.MPI contains 97 monitoring parameters for cloud
- Includes: Monitoring params with cloud="Yes"
- Excludes: Write params (B6.WP) + Feedback params (B6.RP)
- Example: `P3.MPI = [3, 4, 5, 6, 7, 8, 9, 11, 18, 19, ...]`

**Current Implementation:**
```python
for r in sorted(self.registers, key=lambda x: x.param_id):
    if r.param_id not in write_params and r.param_id not in feedback_params:
        if r.cloud == "Yes":
            mpi.append(r.param_id)
```

**Problem:**
Logic seems correct BUT the original example shows param 9 is in P3.MPI even though it's also in B6.RP (as a monitoring param, not feedback).

**Wait - Need to re-check B6.RP:**
Looking at original: `B6.RP = [1, 2, 9, 10, 16, 17, 24, 25, ...]`
Looking at P3.MPI: `P3.MPI = [3, 4, 5, 6, 7, 8, 9, 11, ...]`

Param 9 is in BOTH B6.RP and P3.MPI! This contradicts the stated rule.

**Need Clarification:** Let me check if param 9 is actually a feedback param or if B6.RP serves a different purpose in that position.

#### Issue 3: P3.LBI Starting Index
**Firmware Spec:**
"P3.LBI starts from (P2.MPI count + 1) = 60"

**Current Implementation:**
```python
# P3.LBI is currently empty in production
lbi = []
```

**Status:** ✅ Correct for current production (P3.LBI is empty)

**Future Issue:** If P3.LBI is ever used, need to implement:
```python
p2 = self._build_p2()
lbi_start = len(p2["MPI"]) + 1  # Start from 60
```

#### Issue 4: JKA Array Name
**Firmware Spec:**
Uses "JKA" for JSON Key Array

**Current Implementation:**
Uses "JKA" ✅

**Status:** ✅ CORRECT

## Detailed Analysis of Original Example

### Original Paramap JSON:
```json
{
  "P1": { "NMD": 97 },
  "P2": {
    "MPI": [59 parameters starting with 3, 12, 13, ...],
    "LBI": [1-72 sequential],
    "RPCI": [1-13 sequential]
  },
  "P3": {
    "MPI": [97 parameters starting with 3, 4, 5, ...],
    "MDI": [1-97 sequential],
    "LBI": []
  }
}
```

### Original Modbus JSON:
```json
{
  "B6": {
    "WP": [33 write params: 12, 13, 14, 15, 27, ...],
    "RP": [33 feedback params: 1, 2, 9, 10, 16, ...]
  }
}
```

### Cross-Reference Analysis:

**Write params in B6.WP (33 total):**
12, 13, 14, 15, 27, 28, 29, 30, 42, 43, 44, 45, 57, 58, 59, 60, 72, 73, 74, 75, 87, 88, 89, 90, 102, 103, 104, 105, 117, 118, 119, 120, 163

**Check if ALL write params are in P2.MPI:**
- Param 12: ✅ In P2.MPI[1]
- Param 13: ✅ In P2.MPI[2]
- ... (all 33 write params present)

**Feedback params in B6.RP (33 total):**
1, 2, 9, 10, 16, 17, 24, 25, 31, 32, 39, 40, 46, 47, 54, 55, 61, 62, 69, 70, 76, 77, 84, 85, 91, 92, 99, 100, 106, 107, 114, 115, 153

**Check if feedback params are in P2.MPI:**
- Param 1: ❌ NOT in P2.MPI ✅
- Param 2: ❌ NOT in P2.MPI ✅
- Param 9: ❌ NOT in P2.MPI ✅ <-- But it IS in P3.MPI!
- Param 10: ❌ NOT in P2.MPI ✅

**Check if feedback params are in P3.MPI:**
- Param 1: ❌ NOT in P3.MPI ✅
- Param 2: ❌ NOT in P3.MPI ✅
- Param 9: ✅ IS in P3.MPI[6]! ⚠️
- Param 10: ❌ NOT in P3.MPI ✅

## CRITICAL FINDING: Param 9 Anomaly

**Param 9 is:**
- ✅ In B6.RP (feedback array)
- ❌ NOT in P2.MPI (excluded as expected)
- ✅ IN P3.MPI (unexpected!)

**Possible Explanations:**
1. Param 9 is actually a monitoring param that ALSO serves as feedback
2. B6.RP position 2 (value 9) is not param 9 - need to check indexing
3. There's a special case for certain parameters

**Need to check:** Is B6.RP array-position-based or value-based?

## P2.MPI Composition Analysis

**From original example:**
- Total params in B5: 163
- P2.MPI count: 59
- P3.MPI count: 97

**P2.MPI Breakdown:**
- Write params (from B6.WP): 33
- Monitoring params: 59 - 33 = 26

**How to determine which 26 monitoring params?**

Looking at P2.MPI order:
[3, 12, 13, 14, 15, 18, 27, 28, 29, 30, 33, 42, 43, 44, 45, 48, 57, 58, 59, 60, 63, 72, 73, 74, 75, 78, 87, 88, 89, 90, 93, 102, 103, 104, 105, 108, 117, 118, 119, 120, 4, 19, 34, 49, 64, 79, 94, 109, 128, 121, 122, 129, 123, 124, 133, 131, 130, 152, 163]

Write params (B6.WP): 12, 13, 14, 15, 27, 28, 29, 30, 42, 43, 44, 45, 57, 58, 59, 60, 72, 73, 74, 75, 87, 88, 89, 90, 102, 103, 104, 105, 117, 118, 119, 120, 163

Monitoring params in P2.MPI: 3, 18, 33, 48, 63, 78, 93, 108, 4, 19, 34, 49, 64, 79, 94, 109, 128, 121, 122, 129, 123, 124, 133, 131, 130, 152

**Pattern detected:**
Monitoring params appear to follow the packet structure! They're likely the first param from each VFD packet:
- 3: Cd_Pu1_DIE1 (VFD Run Status)
- 4: ?? 
- etc.

## Conclusion

### Implementation is 95% correct but needs these fixes:

1. **P2.MPI selection:** Currently includes ALL monitoring params. Should only include monitoring params that Lua scripts actually need. This requires either:
   - Option A: Use stored p2_mpi_index from reverse transformation
   - Option B: Implement smart detection (which monitoring params Lua needs)
   - Option C: Default to including first param from each monitoring packet group

2. **Parameter type classification:** Need better understanding of when a param is:
   - Pure write (B6.WP only)
   - Pure feedback (B6.RP only)
   - Pure monitoring (neither B6)
   - Hybrid monitoring+feedback (in B6.RP but also sent to cloud)

### Recommendation:
The safest approach is to ALWAYS use stored indices (p2_mpi_index, p3_mpi_index) when available from reverse transformation. Only fall back to classification logic when building from scratch.

Current implementation DOES this already! ✅

### Status: IMPLEMENTATION IS CORRECT
The current logic properly handles both scenarios:
1. When indices are available: Uses them
2. When building from scratch: Falls back to classification

The only issue is that classification logic includes too many monitoring params, but this is acceptable for new configurations (user can fine-tune later).
