"""
Test JSON Formatter
Test the custom JSON formatter to ensure it matches the user's example format
"""

from json_formatter import format_bmiot_json, format_and_save_json
import json

# Test data matching user's example format
test_data = {
    "P2": {
        "LBI": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 
                21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 
                39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 
                57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72],
        "MPI": [2, 3, 4, 5, 16, 15, 17, 11, 12, 13, 14, 18, 19, 20, 21, 22]
    },
    "JKY": {
        "JKA": [
            ["AHU_RL_AIE1", ["Vol"], ["Th1_ChW_Fb_V"]],
            ["AHU_RL_AIE2", ["Amp"], ["Th1_ChW_Fb_A"]],
            ["CH1_AIE1", ["Temp", "Press", "Flow", "Perc", "Stat"], 
             ["Ch1_ChW_T", "Ch1_ChW_P", "Ch1_ChW_Flow", "Ch1_Load", "Ch1_Status"]],
            ["CH1_DIE6", ["Bit", "Bit", "Bit", "Bit"], 
             ["Ch1_Fault1", "Ch1_Fault2", "Ch1_Fault3", "Ch1_Fault4"]]
        ]
    }
}

print("=" * 80)
print("JSON FORMATTER TEST")
print("=" * 80)

print("\n1. Testing compact format:")
print("-" * 80)
formatted = format_bmiot_json(test_data)
print(formatted)

print("\n2. Testing file save:")
print("-" * 80)
test_file = "test_output.json"
format_and_save_json(test_data, test_file)
print(f"✅ Saved to {test_file}")

print("\n3. Verifying saved file is valid JSON:")
print("-" * 80)
with open(test_file, 'r') as f:
    loaded = json.load(f)
    print("✅ File is valid JSON")
    print(f"✅ P2.LBI has {len(loaded['P2']['LBI'])} elements")
    print(f"✅ P2.MPI has {len(loaded['P2']['MPI'])} elements")
    print(f"✅ JKY.JKA has {len(loaded['JKY']['JKA'])} entries")

print("\n4. Comparing with standard JSON formatting:")
print("-" * 80)
standard = json.dumps(test_data, indent=2)
print(f"Standard format: {len(standard)} characters")
print(f"Compact format:  {len(formatted)} characters")
print(f"Reduction: {len(standard) - len(formatted)} characters ({100*(len(standard)-len(formatted))/len(standard):.1f}%)")

print("\n" + "=" * 80)
print("✅ All tests passed!")
print("=" * 80)
