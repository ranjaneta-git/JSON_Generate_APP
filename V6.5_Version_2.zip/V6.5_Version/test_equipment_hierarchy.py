"""Test equipment hierarchy extraction from firmware example"""
import json
from reverse_engine import ReverseTransformationEngine

# Load firmware JSONs
with open('../Thermelgy-Gateway-BMIoT/data/Modbus_Config.json', 'r') as f:
    modbus = json.load(f)
with open('../Thermelgy-Gateway-BMIoT/data/ParamMap_Config.json', 'r') as f:
    paramap = json.load(f)

engine = ReverseTransformationEngine()
result = engine.transform(modbus, paramap)

print(f'Total registers: {len(result["registers"])}')
print(f'\nFirst 10 registers with equipment hierarchy:\n')
print(f'{"ID":<4} {"Equipment":<15} {"Device":<15} {"Key":<12} {"Type":<5} {"Cloud":<6}')
print('-' * 70)
for i, reg in enumerate(result['registers'][:10]):
    eq = reg.get('equipment_group', '')
    dev = reg.get('device_name', '')
    key = reg['json_key']
    etype = reg.get('equipment_type', '?')
    cloud = reg['cloud']
    print(f'{i+1:<4} {eq:<15} {dev:<15} {key:<12} {etype:<5} {cloud:<6}')

print(f'\nEquipment summary:')
equipments = {}
for reg in result['registers']:
    eq = reg.get('equipment_group', '')
    if eq:
        equipments[eq] = equipments.get(eq, 0) + 1

for eq, count in equipments.items():
    print(f'  {eq}: {count} parameters')

# Check P3.MDI mapping
print(f'\n\nP3.MDI Verification:')
print(f'P3.MPI: {paramap["P3"]["MPI"]}')
print(f'P3.LBI: {paramap["P3"]["LBI"]}')
p2_lbi_start = paramap["P2"].get("LBI", 1000000)
print(f'P2.LBI start: {p2_lbi_start}')
p3_mdi = paramap["P3"]["MPI"].copy()
for lbi_idx in paramap["P3"]["LBI"]:
    p3_mdi.append(p2_lbi_start + lbi_idx)
print(f'P3.MDI (calculated): {p3_mdi}')
print(f'P3.MDI length: {len(p3_mdi)}')

# Check JKA mapping
jka = paramap["JKY"]["JKA"]
print(f'\nJKA entries:')
for idx, entry in enumerate(jka):
    if isinstance(entry, list) and len(entry) >= 3:
        eq_name = entry[0]
        keys = entry[2]
        num_keys = len(keys) if isinstance(keys, list) else 1
        print(f'  JKA[{idx}]: {eq_name} - {num_keys} parameters - Keys: {keys}')
