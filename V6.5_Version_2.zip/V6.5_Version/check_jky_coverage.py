import json
import sys
sys.path.append('c:/Users/DELL/Documents/GitHub/Thermelgy-Gway-BMIoT/V6.5_Version')

from reverse_engine import ReverseTransformationEngine

# Load original JSON files
with open('c:/Users/DELL/Downloads/Original Modbus JSON.json') as f:
    modbus_json = json.load(f)

with open('c:/Users/DELL/Downloads/Original Paramap JSON.json') as f:
    paramap_json = json.load(f)

# Run reverse transform
engine = ReverseTransformationEngine()
result = engine.transform(modbus_json, paramap_json)

cloud_regs = [r for r in result['registers'] if r.get('cloud') == 'Yes']
with_keys = [r for r in cloud_regs if r.get('json_group') and r.get('json_unit') and r.get('json_key')]
without_keys = [r for r in cloud_regs if not r.get('json_group') or not r.get('json_unit') or not r.get('json_key')]

print(f"Cloud params with ALL JSON keys: {len(with_keys)}")
print(f"Cloud params with MISSING JSON keys: {len(without_keys)}")

print(f"\nFirst 5 cloud params WITH keys:")
for r in with_keys[:5]:
    print(f"  B5.ID {r['param_id']}: group='{r.get('json_group')}', unit='{r.get('json_unit')}', key='{r.get('json_key')}'")

print(f"\nChecking P2/P3 membership for params WITH keys:")
p2_mpi = set(paramap_json['P2']['MPI'])
p3_mpi = set(paramap_json['P3']['MPI'])
in_p2 = [r for r in with_keys if r['param_id'] in p2_mpi]
in_p3_only = [r for r in with_keys if r['param_id'] in p3_mpi and r['param_id'] not in p2_mpi]
print(f"  In P2.MPI (write params): {len(in_p2)}")
print(f"  In P3.MPI only (monitoring): {len(in_p3_only)}")
