# Paramap Logic Issues & Required Fixes

**Date:** February 5, 2026  
**Critical Issues Found in Current Implementation**

---

## Summary of Issues

The current transformation engines have **fundamental misunderstandings** of the Paramap structure. The firmware uses a completely different logic than what's implemented.

---

## Issue 1: P2 Array Structure COMPLETELY WRONG

### Current (WRONG) Implementation:
```python
# Current code treats all P2 arrays as containing B5.ID values
P2.LBI = [param_ids...]  # WRONG!
P2.RPCI = [param_ids...]  # WRONG!
P2.MPI = [param_ids...]   # This one is correct
```

### Correct Firmware Logic:

**P2.MPI** (Modbus Parameter Index):
- Contains 59 B5.ID values
- References which Modbus parameters go to Lua buffer
- Example: `P2.MPI = [3, 12, 13, 14, 15...]` ✅ CORRECT

**P2.LBI** (Lua Buffer Index):
- Contains sequential indices [1-72]
- First 59 indices (1-59) map to P2.MPI parameters
- Next 13 indices (60-72) map to P2.RPCI commands
- Example: `P2.LBI = [1, 2, 3, 4, ... 72]` ✅ MUST BE SEQUENTIAL

**P2.RPCI** (RPC Command Index):
- Contains sequential indices [1-13]
- Cloud RPC command slots
- Example: `P2.RPCI = [1, 2, 3, ... 13]` ✅ MUST BE SEQUENTIAL

### Formula:
```
Total P2.LBI Count = P2.MPI Count + P2.RPCI Count
                   = 59 + 13  
                   = 72
```

### Mapping Logic:
```python
# For Modbus parameters:
for i in range(len(P2.MPI)):
    param_id = P2.MPI[i]
    lbi_value = P2.LBI[i]  # Should be i+1 (sequential)
    # LuaBuffVar[lbi_value - 1] = Modbus_ParmRead(param_id)

# For RPC commands:
for i in range(len(P2.RPCI)):
    rpci_id = P2.RPCI[i]
    lbi_value = P2.LBI[len(P2.MPI) + i]  # Continues from MPI
    # LuaBuffVar[lbi_value - 1] = RPC command value
```

---

## Issue 2: P3 Array Structure COMPLETELY WRONG

### Current (WRONG) Implementation:
```python
# Current code treats MDI as containing B5.ID values
P3.MDI = [param_ids...]  # WRONG!
P3.MPI = [param_ids...]   # This one is correct
P3.LBI = []               # Wrong position if used
```

### Correct Firmware Logic:

**P3.MPI** (Modbus Parameter Index):
- Contains 97 B5.ID values
- References which Modbus parameters go to M_data buffer for cloud
- Example: `P3.MPI = [3, 4, 5, 6, 7...]` ✅ CORRECT

**P3.MDI** (M_data Index):
- Contains sequential indices [1-97]
- Maps P3.MPI parameters to M_data buffer positions
- Example: `P3.MDI = [1, 2, 3, 4, ... 97]` ✅ MUST BE SEQUENTIAL

**P3.LBI** (Lua Buffer Index for calculated values):
- Currently empty in production: `[]`
- If used, would contain LBI indices starting from (P2.MPI Count + 1) = 60
- These are Lua-calculated values added to M_data
- Example (if 2 calc values): `P3.LBI = [60, 61]`

### Formula:
```
Total P3.MDI Count = P3.MPI Count + P3.LBI Count
                   = 97 + 0
                   = 97
```

### Mapping Logic:
```python
# For Modbus parameters:
for i in range(len(P3.MPI)):
    param_id = P3.MPI[i]
    mdi_value = P3.MDI[i]  # Should be i+1 (sequential)
    # M_data[mdi_value - 1] = Modbus_ParmRead(param_id)

# For calculated values (if P3.LBI used):
for i in range(len(P3.LBI)):
    lbi_value = P3.LBI[i]  # e.g., 60, 61
    mdi_value = P3.MDI[len(P3.MPI) + i]  # Continues from MPI
    # M_data[mdi_value - 1] = LuaBuffVar[lbi_value - 1]
```

---

## Issue 3: P1.NMD Missing

### Current Implementation:
```python
# P1 only has DT and DN
P1 = {"DT": 0, "DN": ""}
```

### Correct Firmware Logic:
```python
P1 = {
    "DT": device_type,
    "DN": device_name,
    "NMD": len(P2.MPI) + len(P3.MPI) + len(P3.LBI)  # CRITICAL!
}

# Example:
P1.NMD = 59 + 97 + 0 = 156
```

**Purpose of NMD:**
- Total number of parameters in M_data buffer
- Firmware uses this to allocate memory
- Missing this causes firmware crashes or incorrect data transmission

---

## Issue 4: Parameter Classification Logic WRONG

### Current Implementation:
```python
# Code uses "cloud" field and "access" field incorrectly
cloud_params = [r for r in registers if r.cloud == "Yes"]
non_cloud_params = [r for r in registers if r.cloud == "No"]
```

### Correct Firmware Logic:

**For P2.MPI** (59 parameters):
- ✅ INCLUDE: Write parameters from B6.WP (33 params)
- ✅ INCLUDE: Read-only monitoring parameters needed by Lua (26 params)
- ❌ EXCLUDE: Feedback parameters from B6.RP (NEVER in P2.MPI)

**For P3.MPI** (97 parameters):
- ✅ INCLUDE: Monitoring parameters for cloud telemetry
- ✅ INCLUDE: Some read-only parameters from P2.MPI (overlap allowed)
- ❌ EXCLUDE: Write parameters from B6.WP (NO control params in cloud)
- ❌ EXCLUDE: Feedback parameters from B6.RP (NEVER in P3.MPI)

**Critical Rule:**
```python
# B6.RP parameters NEVER appear in P2.MPI or P3.MPI
# Example:
B6.RP = [1, 2, 9, 10, 16, 17, 24, 25, 31, 32, 39, 40, ...]
P2.MPI = [3, 12, 13, 14, 15, 18, 27, 28, 29, 30, 33, ...]  # Notice: 1, 2, 10, 16, 17... NOT present
P3.MPI = [3, 4, 5, 6, 7, 8, 9, 11, 18, 19, 20, 21, 22, ...]  # Notice: 1, 2, 10, 16, 17... NOT present
```

---

## Issue 5: JKA Mapping Logic WRONG

### Current Implementation:
```python
# Code builds JKA from cloud_params only
jka_entries = []
for reg in cloud_params:
    jka_entries.append([param_name, [unit], [key]])
```

### Correct Firmware Logic:

**JKA Structure:**
```python
JKA = [
    # First len(P2.MPI) entries: Map to Modbus params via P2.MPI
    ["Cd_Pu1_DIE1", ["St"], ["VFDRun"]],      # JKA[0] → P2.MPI[0] = 3
    ["Cd_Pu1_DIE1", ["Sp"], ["VFDSpd"]],      # JKA[1] → P2.MPI[1] = 12
    # ... 59 total Modbus params
    
    # Remaining entries: Map to local/calculated params via P2.LBI
    ["Local_Param1", ["unit"], ["key"]],       # JKA[59] → P2.LBI[60] (if exists)
    # ... remaining local params
]
```

**Mapping Rules:**
1. First `len(P2.MPI)` JKA entries map to P2.MPI parameters
2. Remaining JKA entries map to P2.LBI local parameters (if any)
3. Total JKA count = len(P2.MPI) + len(P2.LBI) - len(P2.MPI) 
   - Wait, this is wrong. Let me recalculate...
   - P2.LBI total = 72 (includes MPI + RPCI)
   - But JKA should only include MPI params + local params
   - RPCI doesn't have JSON keys (they're commands)
   
**Actually:**
- JKA count = len(P2.MPI) + count(local_params_with_JSON_keys)
- In production: JKA has 79 entries (59 for P2.MPI + 20 local params)

---

## Issue 6: B5.ID vs B5 Index Confusion

### Current Implementation:
```python
# Code sometimes uses B5.ID as array index
b5_id = registers[i].param_id
# This is CORRECT - B5.ID is the parameter ID
```

### Correct Firmware Logic:

**B5.ID** is the parameter identifier (can be any value like 3, 12, 74, 163)
**B5 Index** is the position in the array (0-162)

```python
# Lookup example:
param_id = 74  # This is B5.ID value
# Find B5 index:
b5_index = B5["ID"].index(74)  # Returns 73 (0-based)

# Access other properties:
address = B5["STA"][b5_index]  # B5.STA[73] = 1561
multiplier = B5["MLT"][b5_index]  # B5.MLT[73] = 0.1
```

**In P2.MPI and P3.MPI:**
```python
# These arrays contain B5.ID VALUES, not indices
P2.MPI = [3, 12, 13, 14, 15, ...]  # These are B5.ID values
P3.MPI = [3, 4, 5, 6, 7, ...]      # These are B5.ID values

# To get parameter properties:
for mpi_value in P2.MPI:
    b5_index = B5["ID"].index(mpi_value)
    address = B5["STA"][b5_index]
    # ... access other B5 properties
```

---

## Required Fixes

### Fix 1: Rewrite P2 Building Logic

```python
def _build_p2(self) -> Dict:
    """Build P2 according to firmware logic"""
    
    # Step 1: Identify P2.MPI parameters (B5.ID values)
    # - Write params from B6.WP
    # - Monitoring params needed by Lua
    # - EXCLUDE feedback params from B6.RP
    mpi = []
    
    # Get write parameters
    b6 = self._build_b6()
    write_params = set(b6["WP"])
    feedback_params = set(b6["RP"])
    
    # Add write parameters to P2.MPI
    for param_id in write_params:
        mpi.append(param_id)
    
    # Add monitoring parameters (not feedback, not write)
    for reg in self.registers:
        if reg.param_id not in feedback_params and reg.param_id not in write_params:
            if reg.parameter_type == "read_only":
                # Check if Lua needs this parameter
                if self._lua_needs_parameter(reg):
                    mpi.append(reg.param_id)
    
    # Step 2: Build P2.LBI as sequential indices
    lbi = list(range(1, len(mpi) + 1))  # [1, 2, 3, ..., 59]
    
    # Step 3: Build P2.RPCI as sequential indices  
    rpci_count = self._count_rpc_commands()  # Should be 13
    rpci = list(range(1, rpci_count + 1))  # [1, 2, 3, ..., 13]
    
    # Step 4: Extend LBI for RPCI
    lbi.extend(range(len(mpi) + 1, len(mpi) + rpci_count + 1))  # [60, 61, ..., 72]
    
    return {"MPI": mpi, "LBI": lbi, "RPCI": rpci}
```

### Fix 2: Rewrite P3 Building Logic

```python
def _build_p3(self) -> Dict:
    """Build P3 according to firmware logic"""
    
    # Step 1: Identify P3.MPI parameters (B5.ID values)
    # - Monitoring params for cloud
    # - EXCLUDE write params
    # - EXCLUDE feedback params
    mpi = []
    
    b6 = self._build_b6()
    write_params = set(b6["WP"])
    feedback_params = set(b6["RP"])
    
    for reg in self.registers:
        if reg.param_id not in write_params and reg.param_id not in feedback_params:
            # This is a monitoring parameter
            if reg.cloud == "Yes" or self._should_send_to_cloud(reg):
                mpi.append(reg.param_id)
    
    # Step 2: Build P3.MDI as sequential indices
    mdi = list(range(1, len(mpi) + 1))  # [1, 2, 3, ..., 97]
    
    # Step 3: P3.LBI for calculated values (currently empty)
    lbi = []
    
    # If calculated values exist, extend MDI
    if lbi:
        mdi.extend(range(len(mpi) + 1, len(mpi) + len(lbi) + 1))
    
    return {"MPI": mpi, "MDI": mdi, "LBI": lbi}
```

### Fix 3: Add P1.NMD

```python
def _build_p1(self) -> Dict:
    """Build P1 with NMD calculation"""
    p2 = self._build_p2()
    p3 = self._build_p3()
    
    nmd = len(p2["MPI"]) + len(p3["MPI"]) + len(p3["LBI"])
    
    return {
        "DT": 0,  # Device type
        "DN": "",  # Device name
        "NMD": nmd  # Total M_data count
    }
```

### Fix 4: Fix JKA Building

```python
def _build_jky(self) -> Dict:
    """Build JKY according to firmware logic"""
    p2 = self._build_p2()
    jka_entries = []
    
    # First len(P2.MPI) entries: Map to Modbus params
    for param_id in p2["MPI"]:
        reg = self._find_register(param_id)
        jka_entries.append([
            reg.json_group or f"Param_{param_id}",
            [reg.json_unit or ""],
            [reg.json_key or ""]
        ])
    
    # Remaining entries: Local/calculated params (if any)
    # ... add local params logic here
    
    return {"JKA": jka_entries}
```

---

## Priority

**CRITICAL - Must fix immediately:**
1. P2.LBI, P2.RPCI structure (sequential indices)
2. P3.MDI structure (sequential indices)
3. P1.NMD calculation
4. Parameter classification (exclude B6.RP from P2/P3)

**HIGH - Should fix:**
5. JKA mapping logic
6. Array membership determination in reverse engine

**MEDIUM - Nice to have:**
7. Better validation
8. More detailed error messages

---

**Status:** Issues identified, fixes designed, ready for implementation
