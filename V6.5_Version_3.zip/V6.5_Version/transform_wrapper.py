"""
Transform Wrapper - Convenience Functions
==========================================

Simple wrapper functions for bidirectional transformation.
Provides easy-to-use function interfaces for the GUI application.

Author: Firmware-aware Application Developer
Version: 1.0
Date: February 6, 2026
"""

from bidirectional_transformer import BidirectionalTransformer

# Create global transformer instance
_transformer = BidirectionalTransformer()


def forward_transform(register_config_path: str, 
                      output_modbus_path: str, 
                      output_paramap_path: str,
                      baudrate: int = 38400,
                      data_format: str = "8N1",
                      profile: int = 0):
    """
    Forward transformation: Register Entry JSON → Modbus + Paramap JSON
    
    Args:
        register_config_path: Path to input Register_Config.json
        output_modbus_path: Path to output Modbus_Config.json
        output_paramap_path: Path to output ParamMap_Config.json
        baudrate: Modbus baudrate (default: 38400)
        data_format: Data format string (default: "8N1")
        profile: Profile type 0, 1, or 2 (default: 0)
    
    Returns:
        Dictionary with status and file paths
    """
    return _transformer.forward_transform(
        register_config_path,
        output_modbus_path,
        output_paramap_path,
        baudrate,
        data_format,
        profile
    )


def reverse_transform(modbus_config_path: str, 
                      paramap_config_path: str,
                      output_register_path: str):
    """
    Reverse transformation: Modbus + Paramap JSON → Register Entry JSON
    
    Args:
        modbus_config_path: Path to input Modbus_Config.json
        paramap_config_path: Path to input ParamMap_Config.json
        output_register_path: Path to output Register_Config.json
    
    Returns:
        Dictionary with status and file path
    """
    return _transformer.reverse_transform(
        modbus_config_path,
        paramap_config_path,
        output_register_path
    )
