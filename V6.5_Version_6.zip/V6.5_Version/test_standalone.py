"""
Test script to simulate what a 3rd party user sees when running
the standalone application with NO supporting files.
"""
import os
import sys

print("=" * 70)
print("TESTING STANDALONE APPLICATION (NO SUPPORT FILES)")
print("=" * 70)
print()

# Get the main application file path
app_file = "modbus_tkinter_app_v6.6_complete.py"

# Read and execute just the import section (first 250 lines)
with open(app_file, encoding='utf-8') as f:
    lines = f.readlines()[:250]
    code = ''.join(lines)
    
print("Executing import section...")
print("-" * 70)
try:
    exec(code)
    print()
    print("-" * 70)
    print("✓ RESULT: Import section executed successfully!")
    print()
    print("If you see exactly ONE message above (✅ JSON formatter loaded),")
    print("that means the standalone file is working perfectly with NO warnings!")
except Exception as e:
    print(f"✗ ERROR: {e}")
    print()

print("=" * 70)
