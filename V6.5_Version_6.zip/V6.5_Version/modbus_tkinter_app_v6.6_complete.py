"""
Modbus Configuration Generator - Enhanced Tkinter Desktop Application v6.5
CRITICAL FIXES APPLIED:
- P3/JKY ordering: Sequential MDI mapping matching firmware's JKY flattened order
- JKY structure: Proper grouping with firmware-compatible format
- Validation: Enhanced firmware-specific checks

NEW IN v6.5 (February 4, 2026):
- ✅ BIDIRECTIONAL TRANSFORMATION: Import Modbus + Paramap JSON to populate registers
- ✅ Reverse transformation engine integrated into GUI
- ✅ Automatic population of communication settings (baudrate, data format, profile)
- ✅ Extract register configurations from existing firmware JSON files
- ✅ "Import Modbus+Paramap JSON" button in toolbar

FEATURES:
- Forward: Register Entry → Modbus + Paramap JSON (original)
- Reverse: Modbus + Paramap JSON → Register Entry (NEW!)
- Full round-trip support for editing and regeneration

Run with: python modbus_tkinter_app_test_6.4.py
No external dependencies except tkinter (comes with Python)
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog, scrolledtext
import json
from datetime import datetime
import os
import csv
import sys
from typing import Any, Dict, List, Optional

# ============================================================================
# EMBEDDED: Custom JSON Formatter (for compact, readable JSON output)
# ============================================================================
class CompactArrayEncoder(json.JSONEncoder):
    """Custom JSON encoder that formats arrays compactly"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.indent_level = 0
    
    def encode(self, obj):
        """Encode object with custom formatting"""
        if isinstance(obj, dict):
            return self._encode_dict(obj)
        elif isinstance(obj, list):
            return self._encode_list(obj)
        else:
            return super().encode(obj)
    
    def _encode_dict(self, obj, level=0):
        """Encode dictionary with proper indentation"""
        if not obj:
            return "{}"
        
        indent = "  " * level
        next_indent = "  " * (level + 1)
        
        items = []
        for key, value in obj.items():
            encoded_value = self._encode_value(value, level + 1)
            items.append(f'{next_indent}"{key}": {encoded_value}')
        
        return "{\n" + ",\n".join(items) + f"\n{indent}}}"
    
    def _encode_value(self, value, level):
        """Encode a value with appropriate formatting"""
        if isinstance(value, dict):
            return self._encode_dict(value, level)
        elif isinstance(value, list):
            return self._encode_list(value, level)
        elif isinstance(value, str):
            return json.dumps(value)
        else:
            return json.dumps(value)
    
    def _encode_list(self, obj, level=0):
        """Encode list with smart formatting"""
        if not obj:
            return "[]"
        
        # Check if list contains only simple types
        is_simple = all(isinstance(item, (int, float, str, bool, type(None))) for item in obj)
        
        if is_simple:
            content = ", ".join(json.dumps(item) for item in obj)
            if len(content) < 80:  # Single line if under 80 chars
                return f"[{content}]"
            else:
                return self._encode_list_multiline(obj, level)
        else:
            return self._encode_list_complex(obj, level)
    
    def _encode_list_multiline(self, obj, level):
        """Encode simple list across multiple lines"""
        indent = "  " * level
        next_indent = "  " * (level + 1)
        
        items_per_row = 10
        rows = []
        for i in range(0, len(obj), items_per_row):
            chunk = obj[i:i + items_per_row]
            row_content = ", ".join(json.dumps(item) for item in chunk)
            rows.append(f"{next_indent}{row_content}")
        
        return "[\n" + ",\n".join(rows) + f"\n{indent}]"
    
    def _encode_list_complex(self, obj, level):
        """Encode complex list with each item on new line"""
        indent = "  " * level
        next_indent = "  " * (level + 1)
        
        items = []
        for item in obj:
            if isinstance(item, list):
                encoded = self._encode_list_compact(item)
            else:
                encoded = self._encode_value(item, level + 1)
            items.append(f"{next_indent}{encoded}")
        
        return "[\n" + ",\n".join(items) + f"\n{indent}]"
    
    def _encode_list_compact(self, obj):
        """Encode nested list compactly (for JKA entries)"""
        items = []
        for item in obj:
            if isinstance(item, list):
                content = ", ".join(json.dumps(x) for x in item)
                items.append(f"[{content}]")
            else:
                items.append(json.dumps(item))
        return "[" + ", ".join(items) + "]"

def format_bmiot_json(data: Dict[str, Any]) -> str:
    """Format BMIoT JSON with readable layout"""
    encoder = CompactArrayEncoder()
    return encoder.encode(data)

def format_and_save_json(data: Dict[str, Any], filepath: str):
    """Format and save BMIoT JSON to file"""
    formatted = format_bmiot_json(data)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(formatted)
        f.write('\n')

# JSON formatter is now always available (embedded)
FORMATTER_AVAILABLE = True
print("[OK] JSON formatter loaded (embedded)")

# ============================================================================
# Import transformation engines for bidirectional conversion
# ============================================================================
try:
    from transform_wrapper import reverse_transform, forward_transform
    ENGINES_AVAILABLE = True
    print("[OK] Transformation engines loaded successfully")
except ImportError:
    # Engines not available - Import/Export features will use basic mode
    ENGINES_AVAILABLE = False


# Import bmiot_constants - Try from same directory first
try:
    import bmiot_constants as bc
    print("[OK] bmiot_constants loaded successfully")
except ImportError:
    # Using embedded fallback constants
    class bc:
        DROPDOWN_OPTIONS = {
            'function_code': ["1 - Read Coil Status", "2 - Read Input Status", "3 - Read Holding Registers", 
                              "4 - Read Input Registers", "5 - Force Single Coil", "6 - Preset Single Register",
                              "15 - Force Multiple Coils", "16 - Preset Multiple Registers"],
            'data_format_code': ["1 - Float 32-bit (Big Endian)", "2 - Float 32-bit (Little Endian)",
                                 "3 - Unsigned 16-bit", "4 - Signed 32-bit (Big Endian)",
                                 "5 - Signed 32-bit (Little Endian)", "6 - Unsigned 32-bit (Big Endian)",
                                 "7 - Unsigned 32-bit (Little Endian)", "8 - Signed 16-bit"],
            'access_type': ["R - Read Only", "W - Write Only", "RW - Read/Write (Write + Verification)"],
            'profile': ["0 - Multiple Slave, Different Types, Non-Uniform, Slave-by-Slave",
                       "1 - Multiple Slave, Same Type, Uniform, Slave-by-Slave",
                       "2 - Multiple Slave, Different Types, Non-Uniform, Single Send"]
        }
        
        @staticmethod
        def get_register_length(fmt_code):
            return 2 if fmt_code in [1, 2, 4, 5, 6, 7] else 1
        
        @staticmethod
        def parse_dropdown_selection(value, dropdown_type):
            if ' - ' in str(value):
                try:
                    part = value.split(' - ')[0]
                    return int(part) if part.isdigit() else part
                except:
                    return value
            return value
        
        @staticmethod
        def validate_slave_id(slave_id):
            """Validate slave ID (1-247)"""
            if not isinstance(slave_id, int):
                return False, "Slave ID must be an integer"
            if slave_id < 1 or slave_id > 247:
                return False, f"Slave ID must be between 1-247, got {slave_id}"
            return True, ""
        
        @staticmethod
        def validate_address(address):
            """Validate Modbus address (0-65535)"""
            if not isinstance(address, int):
                return False, "Address must be an integer"
            if address < 0 or address > 65535:
                return False, f"Address must be between 0-65535, got {address}"
            return True, ""
        
        @staticmethod
        def validate_function_code(fc):
            """Validate function code"""
            valid_codes = [1, 2, 3, 4, 5, 6, 15, 16]
            if fc not in valid_codes:
                return False, f"Function code must be one of {valid_codes}, got {fc}"
            return True, ""
        
        @staticmethod
        def validate_format_code(fmt):
            """Validate format code (1-8)"""
            if fmt not in [1, 2, 3, 4, 5, 6, 7, 8]:
                return False, f"Format code must be 1-8, got {fmt}"
            return True, ""

# Backend Classes
class RegisterEntry:
    def __init__(self, param_id, slave_id, fc, address, length, fmt, multiplier, access, cloud, json_group, json_unit, json_key, array_membership="",
                 parameter_type="read_only", write_param_id=None, feedback_param_id=None, p2_mpi_index=None, p3_mpi_index=None,
                 packet_num=None, packet_sa=None, packet_nrt=None,
                 equipment_group="", device_name="", equipment_type="", jka_equipment_index=-1):
        """
        RegisterEntry with expanded 25-field schema for equipment hierarchy support.
        
        Original 17 fields:
        - param_id, slave_id, fc, address, length, fmt, multiplier, access, cloud
        - json_group, json_unit, json_key, array_membership, packet_id
        
        Phase 1 - Parameter Type Classification (4 fields):
        - parameter_type: str ('write' | 'feedback' | 'read_only')
        - write_param_id: int | None (for feedback reads, points to associated write param)
        - feedback_param_id: int | None (for write params, points to associated feedback read)
        - p2_mpi_index/p3_mpi_index: int | None (MPI ordering determinism)
        
        Phase 2 - Packet Metadata (3 fields):
        - packet_num: int | None (B4 packet number)
        - packet_sa: int | None (B4 packet start address)
        - packet_nrt: int | None (B4 packet register count)
        
        Phase 3 - Equipment Hierarchy (4 fields):
        - equipment_group: str (JKA equipment group name, e.g., "AHU_RL_DIE2", "VALVE", "VFD")
        - device_name: str (specific device/sensor name, e.g., "VFDAM", "CNTRLValve", "Thermostat")
        - equipment_type: str (AI/DI/EM classification)
        - jka_equipment_index: int (which JKA entry this param belongs to, -1 if not in JKA)
        """
        self.param_id = param_id
        self.slave_id = slave_id
        self.fc = fc
        self.address = address
        self.length = length
        self.fmt = fmt
        self.multiplier = multiplier
        self.access = access
        self.cloud = cloud
        self.json_group = json_group
        self.json_unit = json_unit
        self.json_key = json_key
        self.array_membership = array_membership
        self.packet_id = None  # Legacy field, kept for compatibility
        
        # NEW FIELDS - Phase 1: Parameter type classification
        self.parameter_type = parameter_type  # 'write' | 'feedback' | 'read_only'
        self.write_param_id = write_param_id  # For feedback reads
        self.feedback_param_id = feedback_param_id  # For write params
        self.p2_mpi_index = p2_mpi_index  # P2.MPI ordering (for write params)
        self.p3_mpi_index = p3_mpi_index  # P3.MPI ordering (for cloud output params)
        
        # NEW FIELDS - Phase 2: Packet metadata (no recomputation)
        self.packet_num = packet_num  # B4 packet number
        self.packet_sa = packet_sa  # B4 packet start address
        self.packet_nrt = packet_nrt  # B4 packet register count
        
        # NEW FIELDS - Phase 3: Equipment hierarchy
        self.equipment_group = equipment_group  # JKA equipment group name
        self.device_name = device_name  # Specific device/sensor name
        self.equipment_type = equipment_type  # AI/DI/EM classification
        self.jka_equipment_index = jka_equipment_index  # JKA entry index (-1 if not in JKA)
        self.packet_sa = packet_sa    # B4 packet start address
        self.packet_nrt = packet_nrt  # B4 packet register count

class Packet:
    def __init__(self, packet_id, slave_id, fc):
        self.packet_id = packet_id
        self.slave_id = slave_id
        self.fc = fc
        self.start_address = None
        self.register_count = 0
        self.parameters = []

# Backend Logic Functions
def validate_register_schema(reg, serial_no=None):
    """
    Validate the 21-field RegisterEntry schema for consistency.
    Checks parameter_type field and cross-reference integrity.
    
    Args:
        reg: RegisterEntry instance
        serial_no: Optional serial number for error messages
    
    Returns:
        dict: {"status": "ok"} or {"status": "error", "message": "..."}
    """
    prefix = f"Serial No. {serial_no}: " if serial_no else ""
    
    # Validate parameter_type is one of the allowed values
    valid_types = ['write', 'feedback', 'read_only']
    param_type = getattr(reg, 'parameter_type', 'read_only')  # Default to read_only if missing
    
    if param_type not in valid_types:
        return {
            "status": "error",
            "message": f"{prefix}Invalid parameter_type '{param_type}'. Must be one of {valid_types}"
        }
    
    # Check cross-reference consistency
    write_param_id = getattr(reg, 'write_param_id', None)
    feedback_param_id = getattr(reg, 'feedback_param_id', None)
    
    if param_type == 'write':
        # Write parameters can optionally have feedback_param_id
        # (not all write commands have feedback reads)
        pass  # No strict requirement
    
    elif param_type == 'feedback':
        # Feedback reads MUST have write_param_id pointing to the write command
        if write_param_id is None:
            return {
                "status": "error",
                "message": f"{prefix}Parameter type is 'feedback' but write_param_id is None. "
                          f"Feedback reads must reference their associated write parameter."
            }
    
    elif param_type == 'read_only':
        # Read-only parameters should NOT have cross-references
        if write_param_id is not None:
            return {
                "status": "error",
                "message": f"{prefix}Parameter type is 'read_only' but write_param_id is set ({write_param_id}). "
                          f"Read-only parameters should not have write cross-references."
            }
        if feedback_param_id is not None:
            return {
                "status": "error",
                "message": f"{prefix}Parameter type is 'read_only' but feedback_param_id is set ({feedback_param_id}). "
                          f"Read-only parameters should not have feedback cross-references."
            }
    
    # Validate MPI indices if present
    p2_mpi_index = getattr(reg, 'p2_mpi_index', None)
    p3_mpi_index = getattr(reg, 'p3_mpi_index', None)
    
    if p2_mpi_index is not None and p2_mpi_index < 0:
        return {
            "status": "error",
            "message": f"{prefix}p2_mpi_index must be >= 0 or None, got {p2_mpi_index}"
        }
    
    if p3_mpi_index is not None and p3_mpi_index < 0:
        return {
            "status": "error",
            "message": f"{prefix}p3_mpi_index must be >= 0 or None, got {p3_mpi_index}"
        }
    
    # All checks passed
    return {"status": "ok"}

def validate_registers(registers):
    if not registers:
        return {"status": "error", "message": "No registers provided"}
    
    # FIRMWARE LIMITS (from firmware analysis)
    MAX_SLAVES = 50        # B3_szmax
    MAX_PACKETS = 150      # B4_szmax  
    MAX_PARAMETERS = 300   # B5_szmax
    
    # Check firmware limits
    unique_slaves = len(set(reg.slave_id for reg in registers))
    if unique_slaves > MAX_SLAVES:
        return {"status": "error", "message": f"Too many slaves ({unique_slaves}). Firmware limit: {MAX_SLAVES}"}
    
    if len(registers) > MAX_PARAMETERS:
        return {"status": "error", "message": f"Too many parameters ({len(registers)}). Firmware limit: {MAX_PARAMETERS}"}
    
    # Validate individual registers
    for idx, reg in enumerate(registers, 1):
        serial_no = idx  # Serial number visible in tree (1, 2, 3, ...)
        
        # NEW: Validate 21-field schema consistency
        schema_validation = validate_register_schema(reg, serial_no)
        if schema_validation['status'] == 'error':
            return schema_validation
        
        if reg.length > 70:
            return {"status": "error", "message": f"Serial No. {serial_no}: Length {reg.length} exceeds 70 register limit"}
        
        # FIRMWARE-CORRECT: Allow cloud=Yes even if JSON keys are missing
        # The firmware has 97 P3.MPI params but only 79 JKA entries
        # Params without JSON keys will be included in P3.MPI but may not be published to cloud
        # This matches the behavior of the original firmware JSON files
        # NOTE: Validation is now a soft warning, not a hard error
        
        if reg.slave_id < 1 or reg.slave_id > 247:
            return {"status": "error", "message": f"Serial No. {serial_no}: Invalid Slave ID {reg.slave_id} (must be 1-247)"}
        if reg.address < 0 or reg.address > 65535:
            return {"status": "error", "message": f"Serial No. {serial_no}: Invalid Address {reg.address} (must be 0-65535)"}
    
    return {"status": "ok"}

def generate_packets(registers):
    """
    Generate packets with proper grouping logic:
    - Group by Slave ID + Function Code
    - WRITE operations (FC 5,6,15,16): Each parameter = separate packet
    - READ operations (FC 1,2,3,4): Group parameters if span ≤ 70 registers
    """
    packets = []
    packet_counter = 1
    
    # Group by Slave ID and Function Code only
    grouped = {}
    for reg in registers:
        key = (reg.slave_id, reg.fc)
        if key not in grouped:
            grouped[key] = []
        grouped[key].append(reg)
    
    # Sort each group by address
    for key in grouped:
        grouped[key].sort(key=lambda r: r.address)
    
    # Process each group
    for (slave_id, fc), regs in grouped.items():
        # WRITE operations: Each parameter = separate packet
        if fc in [5, 6, 15, 16]:
            for reg in regs:
                packet = Packet(f"PN{packet_counter}", slave_id, fc)
                packet.start_address = reg.address
                packet.register_count = reg.length
                packet.parameters.append(reg)
                reg.packet_id = packet.packet_id
                packets.append(packet)
                packet_counter += 1
        
        # READ operations: Group if span ≤ 70
        else:  # fc in [1, 2, 3, 4]
            i = 0
            while i < len(regs):
                # Start new packet
                current_packet = Packet(f"PN{packet_counter}", slave_id, fc)
                current_packet.parameters.append(regs[i])
                regs[i].packet_id = current_packet.packet_id
                
                # Try to add more parameters to this packet
                j = i + 1
                while j < len(regs):
                    # Calculate span if we add this parameter
                    min_addr = min(r.address for r in current_packet.parameters)
                    max_addr = max(r.address + r.length - 1 for r in current_packet.parameters)
                    
                    # Check if adding regs[j] keeps span ≤ 70
                    new_max_addr = max(max_addr, regs[j].address + regs[j].length - 1)
                    span = new_max_addr - min_addr + 1
                    
                    if span <= 70:
                        current_packet.parameters.append(regs[j])
                        regs[j].packet_id = current_packet.packet_id
                        j += 1
                    else:
                        break
                
                # Finalize packet: calculate start address and register count
                min_addr = min(r.address for r in current_packet.parameters)
                max_addr = max(r.address + r.length - 1 for r in current_packet.parameters)
                current_packet.start_address = min_addr
                current_packet.register_count = max_addr - min_addr + 1
                
                packets.append(current_packet)
                packet_counter += 1
                i = j
    
    # FIRMWARE LIMIT CHECK: Maximum packets
    MAX_PACKETS = 150  # B4_szmax
    if len(packets) > MAX_PACKETS:
        raise ValueError(f"Generated {len(packets)} packets exceeds firmware limit of {MAX_PACKETS}")
    
    return packets

def generate_modbus_io_json(communication, slaves, packets, registers):
    total_params = len(registers)
    total_packets = len(packets)
    
    # Count total register reads across all packets
    total_register_reads = sum(p.register_count for p in packets)
    
    # B1: Summary counts
    b1 = {
        "NOS": len(slaves),           # Number of Slaves
        "NOP": total_params,          # Number of Parameters
        "NPT": total_packets,         # Number of Packets Total
        "NOR": total_register_reads   # Number of Register reads
    }
    
    # B2: Communication settings
    b2 = {
        "BR": communication["baudrate"],  # Baud Rate
        "DF": communication["format"]     # Data Format
    }
    
    # B3: Slave and Packet mapping
    # SP: list of packet numbers that correspond to each slave (1-indexed)
    slave_packet_map = {}
    for idx, packet in enumerate(packets, 1):
        if packet.slave_id not in slave_packet_map:
            slave_packet_map[packet.slave_id] = []
        slave_packet_map[packet.slave_id].append(idx)
    
    # Create SP list in order of SI
    sp_list = []
    for slave_id in slaves:
        if slave_id in slave_packet_map:
            # Add first packet number for this slave
            sp_list.append(slave_packet_map[slave_id][0])
    
    b3 = {
        "SI": slaves,     # Slave IDs
        "SP": sp_list     # Starting Packet for each slave
    }
    
    # B4: Packet details (arrays aligned by packet index)
    sa_list = []   # Start Address
    nrt_list = []  # Number of Registers Total
    fc_list = []   # Function Code
    sid_list = []  # Slave ID
    
    for packet in packets:
        sa_list.append(packet.start_address)
        nrt_list.append(packet.register_count)
        fc_list.append(packet.fc)
        sid_list.append(packet.slave_id)
    
    b4 = {
        "SA": sa_list,    # Start Address for each packet
        "NRT": nrt_list,  # Number of Registers Total for each packet
        "FC": fc_list,    # Function Code for each packet
        "SID": sid_list   # Slave ID for each packet
    }
    
    # B5: Parameter details (arrays aligned by parameter ID)
    id_list = []    # Parameter ID (1-indexed)
    pn_list = []    # Packet Number
    sta_list = []   # Start Address
    ln_list = []    # Length
    fmt_list = []   # Format
    mlt_list = []   # Multiplier
    
    # Map packet_id to packet number (1-indexed)
    packet_id_to_number = {}
    for idx, packet in enumerate(packets, 1):
        packet_id_to_number[packet.packet_id] = idx
    
    for idx, reg in enumerate(registers, 1):
        id_list.append(idx)
        pn_list.append(packet_id_to_number.get(reg.packet_id, 0))
        sta_list.append(reg.address)
        ln_list.append(reg.length)
        fmt_list.append(reg.fmt)
        mlt_list.append(reg.multiplier)
    
    b5 = {
        "ID": id_list,      # Parameter IDs
        "PN": pn_list,      # Packet Number for each parameter
        "STA": sta_list,    # Start Address for each parameter
        "LN": ln_list,      # Length for each parameter
        "FMT": fmt_list,    # Format for each parameter
        "MLT": mlt_list     # Multiplier for each parameter
    }
    
    # B6: Write and Read PARAMETER IDs (not packet numbers!)
    # WP = Write Parameter IDs: All parameters with W or RW access
    # RP = Read Parameter IDs: Write-verification reads
    #      - RW parameters (write+verify in single parameter)
    #      - R parameters that pair with W parameters (separate write+verify)
    #      NOT pure monitoring reads (R access) - those go to Output JSON
    # 
    # CRITICAL: Based on historical Excel mapping analysis:
    # - R parameters (monitoring): Pure telemetry → Go to Output JSON (NOT in RP)
    # - R parameters (verification): Paired with W → Go to RP (NOT in Output JSON)
    # - W parameters: Write only → Go to WP
    # - RW parameters: Write + verification → Go to BOTH WP and RP
    write_param_ids = []
    read_param_ids = []
    
    # Step 1: Add all W and RW parameters to WP
    for idx, reg in enumerate(registers, 1):
        if 'W' in reg.access:
            write_param_ids.append(idx)
    
    # Step 2: Add RW parameters to RP (write+verify in single parameter)
    for idx, reg in enumerate(registers, 1):
        if reg.access == 'RW':
            read_param_ids.append(idx)
    
    # Step 3: Detect R parameters that pair with W parameters (separate write+verify)
    # An R parameter is a verification read if:
    # - Same slave ID, address, length, format as a W parameter
    for idx, reg in enumerate(registers, 1):
        if reg.access == 'R':
            # Check if this R pairs with any W parameter
            for widx, wreg in enumerate(registers, 1):
                if ('W' in wreg.access and
                    wreg.slave_id == reg.slave_id and
                    wreg.address == reg.address and
                    wreg.length == reg.length and
                    wreg.fmt == reg.fmt):
                    # This is a verification read for a write
                    read_param_ids.append(idx)
                    break
    
    b6 = {
        "WP": write_param_ids,  # Write Parameter IDs (W or RW access)
        "RP": read_param_ids    # Write-Verification Read Parameter IDs (ONLY RW access)
    }
    
    return {"B1": b1, "B2": b2, "B3": b3, "B4": b4, "B5": b5, "B6": b6}

def generate_parameter_config_json(registers, profile=0):
    """Generate ParamMap_Config.json V1.2.0 compliant with BD-Algorithm specs.
    
    Args:
        registers: List of register objects
        profile: Profile type (0, 1, or 2) - affects MST.PRF value
    """
    # CRITICAL: Build B6 mappings first to identify write-verification pairs
    b6_wp_ids = set()
    b6_rp_ids = set()
    
    # Step 1: Identify all write parameters for B6.WP
    for idx, reg in enumerate(registers, 1):
        if 'W' in reg.access:
            b6_wp_ids.add(idx)
    
    # Step 2: Identify verification reads for B6.RP
    for idx, reg in enumerate(registers, 1):
        # RW parameters include their own verification
        if reg.access == 'RW':
            b6_rp_ids.add(idx)
        # Detect paired R parameters that verify W parameters
        elif reg.access == 'R':
            for widx, wreg in enumerate(registers, 1):
                if ('W' in wreg.access and
                    wreg.slave_id == reg.slave_id and
                    wreg.address == reg.address and
                    wreg.length == reg.length and
                    wreg.fmt == reg.fmt):
                    b6_rp_ids.add(idx)
                    break
    
    # Step 3: Build Lua Buffer based on Lua script pattern
    # Analysis from MainScript.lua shows:
    # - LBI 1-15: Equipment Write/Status pairs (interleaved by equipment)
    # - LBI 16-19: Verification reads (dual-use: firmware verification + Lua user variables)
    #
    # Pattern: For each equipment → (Write, Status Monitor) pair
    # Then: Standalone monitors
    # Finally: Verification reads for user data storage
    
    lua_buffer_params_with_ids = []  # List of (param_idx, register) tuples for P2.MPI
    verification_for_lua = []  # Verification reads that go to P2.RPCI (LBI 16+)
    
    # Group write parameters by equipment (json_group)
    equipment_groups = {}  # {group_name: {'writes': [], 'monitors': []}}
    standalone_monitors = []  # Monitors without paired writes
    
    # Step 3a: Collect write parameters grouped by equipment
    for idx, reg in enumerate(registers, 1):
        if 'W' in reg.access:
            group = reg.json_group if reg.json_group else "Unknown"
            if group not in equipment_groups:
                equipment_groups[group] = {'writes': [], 'monitors': []}
            equipment_groups[group]['writes'].append((idx, reg))
    
    # Step 3b: Collect monitoring parameters (R access, cloud=Yes, NOT verification)
    for idx, reg in enumerate(registers, 1):
        if reg.access == 'R' and reg.cloud and idx not in b6_rp_ids:
            group = reg.json_group if reg.json_group else "Unknown"
            if group in equipment_groups:
                # Pair with equipment that has writes
                equipment_groups[group]['monitors'].append((idx, reg))
            else:
                # Standalone monitor
                standalone_monitors.append((idx, reg))
    
    # Step 3c: Build interleaved pattern: (Write, Monitor) for each equipment
    for group in sorted(equipment_groups.keys(), key=lambda g: min((p[0] for p in equipment_groups[g]['writes']), default=999)):
        writes = equipment_groups[group]['writes']
        monitors = equipment_groups[group]['monitors']
        
        # Interleave write and monitor for each equipment
        for i, (w_idx, w_reg) in enumerate(writes):
            lua_buffer_params_with_ids.append((w_idx, w_reg))
            if i < len(monitors):
                lua_buffer_params_with_ids.append(monitors[i])
        
        # Add remaining monitors if more monitors than writes
        for i in range(len(writes), len(monitors)):
            lua_buffer_params_with_ids.append(monitors[i])
    
    # Step 3d: Add standalone monitors (sorted by slave_id, then address)
    # This ensures correct LBI order matching Excel "Lua Buffer Side" table
    standalone_monitors.sort(key=lambda x: (x[1].slave_id, x[1].address))
    lua_buffer_params_with_ids.extend(standalone_monitors)
    
    # Step 3e: Add verification reads for Lua user data storage (LBI 16-19)
    # CRITICAL: Take only FIRST 4 verification reads to match Lua LBI structure
    # From Lua: LBI = {[1] = 16, [2] = 17, [3] = 18, [4] = 19}
    # This limits P1.NLB = 15 (MPI) + 4 (RPCI) = 19
    sorted_verification_reads = sorted(b6_rp_ids)
    for param_idx in sorted_verification_reads[:4]:  # Take only first 4
        reg = registers[param_idx - 1]
        verification_for_lua.append((param_idx, reg))
    
    # CRITICAL: Cloud params = pure monitoring reads (R access, NOT verification)
    cloud_params = [r for idx, r in enumerate(registers, 1)
                    if r.cloud and r.access == 'R' and idx not in b6_rp_ids]
    
    # P1: Size calculations
    # NLB = Number of Lua Buffer variables (equipment params + verification reads)
    # NLBIN = Same as NLB (all allocated variables are used)
    # NMD = Total JSON keys (will be calculated after JKY is built)
    total_lua_buffer = lua_buffer_params_with_ids + verification_for_lua
    
    p1 = {
        "NLB": len(total_lua_buffer),                                         # Total Lua buffer count
        "NLBIN": len(total_lua_buffer),                                       # Same as NLB (all are used)
        "NMD": 0  # Will be updated after JKY is built
    }
    
    # P2: Lua Buffer mappings based on Lua script pattern
    # LBI: Sequential [1, 2, 3, ..., 19] for ALL Lua buffer entries
    # MPI: First 15 LBIs → Equipment parameters (writes + monitors)
    # RPCI: LBI 16-19 → Verification reads (used by Lua for user data storage)
    #
    # From Lua analysis:
    # - LBI 1-15 map to equipment Write/Status pairs + monitors
    # - LBI 16-19 map to verification reads (dual-use: firmware + Lua variables)
    
    lbi_list = []   # Sequential [1, 2, 3, ..., 19]
    mpi_list = []   # B5 Param IDs for LBI 1-15 (equipment params)
    rpci_list = []  # B5 Param IDs for LBI 16-19 (verification reads)
    
    # Build MPI from equipment parameters (LBI 1-15)
    for idx, (param_idx, reg) in enumerate(lua_buffer_params_with_ids, 1):
        lbi_list.append(idx)
        mpi_list.append(param_idx)
    
    # Build RPCI from verification reads (LBI 16-19)
    # These are B6.RP params that Lua uses for user variable storage
    for idx, (param_idx, reg) in enumerate(verification_for_lua, len(mpi_list) + 1):
        lbi_list.append(idx)
        rpci_list.append(param_idx)
    
    p2 = {
        "LBI": lbi_list,    # Sequential: [1, 2, 3, ...] for ALL Lua buffer entries
        "MPI": mpi_list,    # B5 Param IDs for LBI 1-15 (equipment params)
        "RPCI": rpci_list   # B5 Param IDs for LBI 16-19 (verification reads)
    }
    
    # CRITICAL FIX: Build P3 and JKY in P2.MPI order (Lua Buffer order), NOT alphabetical
    # P3.MPI = cloud parameters extracted from P2.MPI in same order
    # JKY must follow the same order as P3.MPI
    
    # Step 1: Build P3.MPI by extracting cloud params from P2.MPI order
    p3_mpi_unique = []  # Unique cloud param IDs in P2.MPI order
    p3_mpi_unique_set = set()
    
    for param_idx in mpi_list:  # Iterate P2.MPI in order
        reg = registers[param_idx - 1]
        if reg.cloud and reg.access == 'R' and param_idx not in b6_rp_ids:
            if param_idx not in p3_mpi_unique_set:
                p3_mpi_unique.append(param_idx)
                p3_mpi_unique_set.add(param_idx)
    
    # Step 2: Build JKA structure following P3.MPI order
    jka_structure_ordered = []  # List to preserve order: [(group, {unit: [keys]})]
    group_seen = {}  # Track which groups we've processed
    
    for param_idx in p3_mpi_unique:
        reg = registers[param_idx - 1]
        group = reg.json_group if reg.json_group else ""
        unit = reg.json_unit if reg.json_unit else ""
        
        if not group:
            continue
            
        # Find or create group entry
        if group not in group_seen:
            group_entry = {}
            jka_structure_ordered.append((group, group_entry))
            group_seen[group] = group_entry
        else:
            group_entry = group_seen[group]
        
        if unit not in group_entry:
            group_entry[unit] = []
        
        # Support comma-separated keys
        if reg.json_key:
            keys = [k.strip() for k in reg.json_key.split(',') if k.strip()]
        else:
            keys = []
        
        # Add keys that don't already exist
        for key in keys:
            if key not in group_entry[unit]:
                group_entry[unit].append(key)
    
    # Step 3: Flatten JKA in P2.MPI order and create JKY + P3.MDI
    jka_list = []
    mdi_list = []
    p3_mpi_list = []  # Can have duplicates for multi-key params
    mdi_counter = 1
    
    for group, units_dict in jka_structure_ordered:
        unit_list = list(units_dict.keys())  # Preserve order from P3.MPI
        
        # Collect ALL keys for this group across all units
        all_keys_for_group = []
        for unit in unit_list:
            all_keys_for_group.extend(units_dict[unit])
        
        # Create JKA entry: [group, [units], [all_keys]]
        jka_list.append([group, unit_list, all_keys_for_group])
        
        # Build P3.MDI: Simply count total keys (each key gets an MDI)
        for unit in unit_list:
            for key in units_dict[unit]:
                mdi_list.append(mdi_counter)
                mdi_counter += 1
    
    # P3.MPI is simply the unique parameter list (no duplication per key!)
    # Parameters with multiple keys still appear only ONCE in P3.MPI
    # JKY structure handles the key expansion during JSON generation
    p3_mpi_list = p3_mpi_unique.copy()  # Use the unique list we built earlier
    
    jky = {"JKA": jka_list}
    
    # Calculate total keys in JKY for P1.NMD
    # CRITICAL: Firmware expects P1.NMD = Σ(num_keys × num_names) for each JKA entry
    # JKA structure: [type, [keys], [names]] where keys are units like "FB", "DegC"
    # and names are equipment identifiers like "CNTRL Valve", "VFDRun"
    total_jky_keys = 0
    for jka_entry in jka_list:
        if len(jka_entry) >= 3:
            num_keys = len(jka_entry[1])   # Number of keys/units (index [1])
            num_names = len(jka_entry[2])  # Number of equipment names (index [2])
            total_jky_keys += num_keys * num_names  # MULTIPLY keys × names
    
    # Step 4: Build P3 structure
    # P3 has two sources for output data:
    # - P3.MPI: Maps MDI to B5 Modbus parameter IDs (PC3_MP array)
    # - P3.LBI: Maps MDI to P2 Lua buffer indices (PC3_LB array)
    # 
    # IMPORTANT: P3.LBI is ONLY for Lua-calculated values that don't come from Modbus.
    # Verification reads are Modbus parameters and must output via P3.MPI, not P3.LBI.
    # For most configurations, P3.LBI will be empty [] since all outputs come from Modbus.
    
    p3_lbi_list = []  # Empty for configurations where all outputs are from Modbus params
    # NOTE: P3.LBI would only be populated if Lua script calculates custom values
    # that need to be output to cloud (e.g., aggregated metrics, alarms, etc.)
    
    p3 = {
        "MDI": mdi_list,       # SEQUENTIAL: [1, 2, 3, 4, ...]
        "MPI": p3_mpi_list,    # Maps MDI to B5 Modbus parameter IDs
        "LBI": p3_lbi_list     # Maps MDI to P2 Lua buffer indices (usually empty)
    }
    
    # Update P1.NMD with total JKY keys count
    p1["NMD"] = total_jky_keys
    
    # JKC: JSON Key Configuration (fixed structure from examples)
    jkc = {
        "JKH": "properties",
        "EKS": "DKEY"
    }
    
    # NTC: Network Configuration (template with defaults)
    # User can modify these in the generated JSON
    ntc = {
        "IP": "18.191.222.62",
        "PT": "1234",
        "CI": "Lucas",
        "SN": [1],
        "MI": ["GWAY01"],
        "MT": ["GWAY"],
        "DI": "GW01"
    }
    
    # MST: Master settings
    # PRF: Profile selection (0, 1, or 2)
    #   0 = Multiple Slave, Different Types, Non-Uniform, Slave-by-Slave
    #   1 = Multiple Slaves, Same Type, Uniform, Slave-by-Slave
    #   2 = Multiple Slaves, Different Types, Non-Uniform, All Parameters Once
    mst = {
        "PRF": int(profile)  # Use actual profile from communication settings
    }
    
    return {
        "P1": p1,
        "P2": p2,
        "P3": p3,
        "JKY": jky,
        "JKC": jkc,
        "NTC": ntc,
        "MST": mst
    }


def generate_output_json(param_config, registers):
    """Generate Output JSON template based on ParamMap_Config.json structure.
    
    This Output JSON is used by external systems/cloud for data visualization.
    Structure is defined by JKY (grouping) and P3 (parameter mapping).
    
    Output structure follows Excel mapping logic:
    - Top level: Machine type group (e.g., "CPM")
    - Contains: MSG_TYPE + device groups (e.g., "FAN", "PUMP")
    - Each device group: Array of device objects
    - Each device object: DKEY + parameter key-value pairs
    
    Example:
    {
      "CPM": {
        "MSG_TYPE": "NML_STAT",
        "FAN": [
          {
            "DKEY": "Fan AHU1 VFD1",
            "STAT": 0,
            "RNHR": 510
          }
        ]
      }
    }
    
    Args:
        param_config: Generated ParamMap_Config.json dictionary
        registers: List of register objects for parameter lookup
        
    Returns:
        Dictionary representing the Output JSON structure with placeholder values
    """
    ntc = param_config.get('NTC', {})
    jky = param_config.get('JKY', {})
    jka = jky.get('JKA', [])
    p3 = param_config.get('P3', {})
    jkc = param_config.get('JKC', {})
    
    # Get machine type from NTC (e.g., "CPM", "GWAY")
    machine_type = ntc.get('MT', ['GWAY'])[0] if ntc.get('MT') else 'GWAY'
    
    # Create machine type group with MSG_TYPE
    machine_group = {
        "MSG_TYPE": "NML_STAT"  # Fixed message type for normal status
    }
    
    # Process JKA structure to build device groups
    # JKA format: [[group_name, [device_names], [parameter_keys]], ...]
    # Example: [["FAN", ["Fan AHU1 VFD1"], ["STAT", "RNHR"]], ...]
    
    for jka_entry in jka:
        if len(jka_entry) < 3:
            continue
            
        group_name = jka_entry[0]  # e.g., "FAN", "PUMP", "SENSOR"
        device_names = jka_entry[1]  # e.g., ["Fan AHU1 VFD1", "Fan AHU2 VFD2"]
        param_keys = jka_entry[2]  # e.g., ["STAT", "RNHR", "FREQ"]
        
        # Create array for this device group
        group_array = []
        
        # For each device in this group
        for device_name in device_names:
            # Create device object starting with DKEY (or custom key from JKC.EKS)
            device_obj = {
                jkc.get('EKS', 'DKEY'): device_name
            }
            
            # Add parameters for this device
            # Match device name with parameters from registers
            for param_key in param_keys:
                # Find register(s) with matching device + parameter combination
                # Search through cloud parameters
                param_value = 0  # Placeholder value (runtime provides actual data)
                
                for reg in registers:
                    if not reg.cloud:
                        continue
                    
                    # Check if this register matches device and parameter
                    if reg.json_unit == device_name:
                        # Check if param_key is in this register's json_key
                        if reg.json_key:
                            keys = [k.strip() for k in reg.json_key.split(',')]
                            if param_key in keys:
                                # Found matching parameter
                                # In actual runtime, firmware provides real value
                                # For template generation, use placeholder
                                param_value = 0
                                break
                
                device_obj[param_key] = param_value
            
            group_array.append(device_obj)
        
        # Add this device group to machine_group
        machine_group[group_name] = group_array
    
    # Return output starting directly with machine type group
    # No extra top-level fields (client_id, machine_id, etc.)
    output = {
        machine_type: machine_group
    }
    
    return output


# -----------------
# Validation Engine
# -----------------
def validate_modbus_io(modbus_io, registers, packets, communication, slaves):
    """Validate generated modbus_io structure and consistency.
    Returns a dict: { 'errors': [...], 'warnings': [...] }
    """
    errors = []
    warnings = []

    # Basic structure checks
    for key in ['B1', 'B2', 'B3', 'B4', 'B5', 'B6']:
        if key not in modbus_io:
            errors.append(f"Missing top-level key: {key}")

    # B1 checks
    b1 = modbus_io.get('B1', {})
    if b1.get('NOP', 0) != len(registers):
        warnings.append(f"B1.NOP ({b1.get('NOP')}) does not match number of registers ({len(registers)})")

    # B2 checks (communication)
    b2 = modbus_io.get('B2', {})
    if 'BR' in b2:
        try:
            int(b2['BR'])
        except Exception:
            errors.append(f"B2.BR (baudrate) is not an integer: {b2.get('BR')}")
    
    # B2.DF format validation (firmware constraint)
    if 'DF' in b2:
        df = b2['DF']
        valid_formats = ["8N1", "8E1", "8O1", "7E1", "7O1"]
        if df not in valid_formats:
            errors.append(f"B2.DF must be one of {valid_formats}, got '{df}' (firmware limit)")
    else:
        errors.append("B2.DF is required (data format like '8N1')")

    # B4 packet counts vs packets list
    b4 = modbus_io.get('B4', {})
    sa = b4.get('SA', [])
    nrt = b4.get('NRT', [])
    if len(sa) != len(packets) or len(nrt) != len(packets):
        warnings.append("Number of packet entries in B4 does not match generated packets")

    # B5 parameter packet numbers should reference valid packets
    b5 = modbus_io.get('B5', {})
    pn_list = b5.get('PN', [])
    for i, pn in enumerate(pn_list, 1):
        if pn < 1 or pn > len(packets):
            errors.append(f"Serial No. {i}: References invalid packet number {pn} (total packets: {len(packets)})")

    # B6 read/write consistency
    b6 = modbus_io.get('B6', {})
    rp = b6.get('RP', [])
    wp = b6.get('WP', [])
    for pnum in rp + wp:
        if pnum < 1 or pnum > len(registers):
            errors.append(f"B6 references invalid parameter Serial No. {pnum} (total parameters: {len(registers)})")

    return {'errors': errors, 'warnings': warnings}


def validate_parameter_config(param_cfg, registers):
    """Validate generated parameter_config structure and basic consistency.
    Returns a dict: { 'errors': [...], 'warnings': [...] }
    """
    errors = []
    warnings = []

    # Required top-level keys
    for key in ['P1', 'P2', 'P3', 'JKY']:
        if key not in param_cfg:
            errors.append(f"Missing top-level key in parameter_config: {key}")

    p1 = param_cfg.get('P1', {})
    if 'NLB' in p1 and not isinstance(p1['NLB'], int):
        warnings.append("P1.NLB should be integer count")

    # CRITICAL: Firmware-specific validation
    # Check P1.NMD matches JKY total elements
    p1 = param_cfg.get('P1', {})
    jky = param_cfg.get('JKY', {})
    jka = jky.get('JKA', [])
    
    if 'NMD' in p1:
        expected_nmd = p1['NMD']
        # Count total keys in JKA structure
        # CRITICAL: Firmware expects NMD = Σ(units × keys), NOT just key count!
        total_jky_keys = 0
        for jka_entry in jka:
            if len(jka_entry) >= 3:
                # jka_entry format: [group, [units], [keys]]
                num_units = len(jka_entry[1])
                num_keys = len(jka_entry[2])
                total_jky_keys += num_units * num_keys  # Firmware multiplies units × keys
        
        if total_jky_keys != expected_nmd:
            errors.append(f"CRITICAL: P1.NMD ({expected_nmd}) does not match JKY total keys ({total_jky_keys}) - Firmware will fail!")
    
    # Check P3.MDI is sequential (1, 2, 3, 4, ...)
    p3 = param_cfg.get('P3', {})
    mdi_list = p3.get('MDI', [])
    if mdi_list:
        expected_sequential = list(range(1, len(mdi_list) + 1))
        if mdi_list != expected_sequential:
            errors.append(f"CRITICAL: P3.MDI must be sequential [1,2,3,...] but got {mdi_list} - Firmware expects sequential order!")
    
    # JKY structure checks
    if jka and not isinstance(jka, list):
        errors.append("JKY.JKA should be a list of json key entries")
    
    # Validate JKA format: [[group, [units], [keys]], ...]
    for idx, jka_entry in enumerate(jka):
        if not isinstance(jka_entry, list) or len(jka_entry) != 3:
            errors.append(f"JKA entry {idx} should be [group, [units], [keys]] format")
        elif not isinstance(jka_entry[1], list) or not isinstance(jka_entry[2], list):
            errors.append(f"JKA entry {idx}: units and keys must be lists")
        else:
            # Firmware string length validation: JKY fields max 15 chars
            equipment_type = jka_entry[0]
            device_names = jka_entry[1]
            param_keys = jka_entry[2]
            
            if len(equipment_type) > 15:
                errors.append(f"JKA[{idx}] Equipment Type '{equipment_type}' exceeds 15 chars (firmware limit: char[15])")
            
            for dev_idx, device_name in enumerate(device_names):
                if len(device_name) > 15:
                    errors.append(f"JKA[{idx}] Device Name '{device_name}' exceeds 15 chars (firmware limit: char[15])")
            
            for key_idx, param_key in enumerate(param_keys):
                if len(param_key) > 15:
                    errors.append(f"JKA[{idx}] Parameter Key '{param_key}' exceeds 15 chars (firmware limit: char[15])")
    
    # JKC string length validation: max 15 chars
    jkc = param_cfg.get('JKC', {})
    if 'JKH' in jkc:
        jkh = jkc['JKH']
        if len(jkh) > 15:
            errors.append(f"JKC.JKH '{jkh}' exceeds 15 chars (firmware limit: char[15])")
    
    if 'EKS' in jkc:
        eks = jkc['EKS']
        if len(eks) > 15:
            errors.append(f"JKC.EKS '{eks}' exceeds 15 chars (firmware limit: char[15])")
    
    # NTC string length validation
    ntc = param_cfg.get('NTC', {})
    
    # IP, Client ID, Device ID: max 20 chars
    if 'IP' in ntc and len(ntc['IP']) > 20:
        errors.append(f"NTC.IP '{ntc['IP']}' exceeds 20 chars (firmware limit: char[20])")
    
    if 'CI' in ntc and len(ntc['CI']) > 20:
        errors.append(f"NTC.CI (Client ID) '{ntc['CI']}' exceeds 20 chars (firmware limit: char[20])")
    
    if 'DI' in ntc and len(ntc['DI']) > 20:
        errors.append(f"NTC.DI (Device ID) '{ntc['DI']}' exceeds 20 chars (firmware limit: char[20])")
    
    # Port: max 8 chars
    if 'PT' in ntc and len(ntc['PT']) > 8:
        errors.append(f"NTC.PT (Port) '{ntc['PT']}' exceeds 8 chars (firmware limit: char[8])")
    
    # Machine IDs and Types: max 20 chars each
    if 'MI' in ntc and isinstance(ntc['MI'], list):
        for idx, machine_id in enumerate(ntc['MI']):
            if len(machine_id) > 20:
                errors.append(f"NTC.MI[{idx}] (Machine ID) '{machine_id}' exceeds 20 chars (firmware limit: char[20])")
    
    if 'MT' in ntc and isinstance(ntc['MT'], list):
        for idx, machine_type in enumerate(ntc['MT']):
            if len(machine_type) > 20:
                errors.append(f"NTC.MT[{idx}] (Machine Type) '{machine_type}' exceeds 20 chars (firmware limit: char[20])")
    
    # MST validation
    mst = param_cfg.get('MST', {})
    if 'PRF' in mst:
        prf_value = mst['PRF']
        if not isinstance(prf_value, int) or prf_value not in [0, 1, 2]:
            errors.append(f"MST.PRF must be 0, 1, or 2 but got: {prf_value}")
    else:
        warnings.append("MST.PRF not found - Profile not specified")

    return {'errors': errors, 'warnings': warnings}

# GUI Application


# ============================================================================
# AUTO-ASSIGNMENT FUNCTIONS FOR packet_num AND b5_id
# ============================================================================

def auto_assign_packet_numbers(registers: list) -> list:
    """
    Automatically assign packet numbers based on sequential grouping logic.

    **MANDATORY PACKET FORMATION RULE:**
    - Group by (slave_id, fc) combination
    - Within each group, assign registers sequentially in B5 ID order
    - Maximum 70 registers per packet
    - **DO NOT split packets based on address gaps**
    - Address gaps are acceptable and must not affect packet boundaries
    - Packet simplicity and deterministic behavior over address optimization
    """
    if not registers:
        return registers

    # Sort by slave_id, fc, then by b5_id (sequential order)
    sorted_regs = sorted(registers, key=lambda r: (
        r.get('slave_id', 0),
        r.get('fc', 0),
        r.get('b5_id', r.get('address', 0))
    ))

    packet_num = 1
    registers_in_current_packet = 0
    prev_slave = None
    prev_fc = None
    MAX_REGISTERS_PER_PACKET = 70

    for reg in sorted_regs:
        slave = reg.get('slave_id', 0)
        fc = reg.get('fc', 0)

        # Start new packet if:
        # 1. Different slave_id or function code
        # 2. Current packet has reached maximum size (70 registers)
        if prev_slave is not None:
            if slave != prev_slave or fc != prev_fc:
                packet_num += 1
                registers_in_current_packet = 0
            elif registers_in_current_packet >= MAX_REGISTERS_PER_PACKET:
                packet_num += 1
                registers_in_current_packet = 0

        reg['packet_num'] = packet_num
        registers_in_current_packet += 1

        prev_slave = slave
        prev_fc = fc

    print(f" Auto-assigned {packet_num} packets (max 70 registers, no gap splitting)")
    return registers

def auto_generate_b5_ids(registers: list) -> list:
    """
    Automatically generate B5 IDs sequentially starting from 1.
    
    This is called after packet_num assignment to ensure proper ordering.
    
    Args:
        registers: List of register dictionaries
    
    Returns:
        Updated list with b5_id assigned sequentially
    """
    if not registers:
        return registers
    
    # Sort by packet_num, then by address within packet
    sorted_regs = sorted(registers, key=lambda r: (
        r.get('packet_num', 0),
        r.get('address', 0)
    ))
    
    # Assign sequential b5_ids
    for i, reg in enumerate(sorted_regs, start=1):
        reg['b5_id'] = i
    
    print(f"✓ Auto-generated {len(sorted_regs)} B5 IDs (1-{len(sorted_regs)})")
    return registers


def validate_packet_assignments(registers: list) -> tuple:
    """
    Validate packet assignments and return statistics.
    
    Returns:
        (is_valid, message, stats_dict)
    """
    if not registers:
        return (True, "No registers to validate", {})
    
    # Check all registers have packet_num
    missing_packet = [r for r in registers if 'packet_num' not in r]
    if missing_packet:
        return (False, f"{len(missing_packet)} registers missing packet_num", {})
    
    # Check all registers have b5_id
    missing_b5 = [r for r in registers if 'b5_id' not in r]
    if missing_b5:
        return (False, f"{len(missing_b5)} registers missing b5_id", {})
    
    # Check for duplicate b5_ids
    b5_ids = [r['b5_id'] for r in registers]
    if len(b5_ids) != len(set(b5_ids)):
        return (False, "Duplicate B5 IDs found", {})
    
    # Gather statistics
    packet_nums = set(r['packet_num'] for r in registers)
    stats = {
        'total_registers': len(registers),
        'total_packets': len(packet_nums),
        'b5_id_range': f"{min(b5_ids)}-{max(b5_ids)}",
        'packet_range': f"{min(packet_nums)}-{max(packet_nums)}"
    }
    
    return (True, "All assignments valid", stats)


class ModbusConfigGenerator:
    def __init__(self, root):
        self.root = root
        self.root.title("🔧 Modbus Configuration Generator Pro")
        self.root.geometry("1500x850")
        self.root.configure(bg='#f5f7fa')
        
        # Data storage
        self.register_rows = []
        self.generated_modbus_io = None
        self.generated_parameter_config = None
        self.generated_output_json = None
        self.metadata = {}  # Store metadata for perfect reconstruction
        
        # Configure style
        style = ttk.Style()
        style.theme_use('clam')
        
        # Enhanced color scheme
        style.configure('Title.TLabel', font=('Segoe UI', 18, 'bold'), foreground='#2c3e50', background='#f5f7fa')
        style.configure('Subtitle.TLabel', font=('Segoe UI', 10), foreground='#7f8c8d', background='#f5f7fa')
        style.configure('Section.TLabel', font=('Segoe UI', 13, 'bold'), foreground='#34495e')
        style.configure('Generate.TButton', font=('Segoe UI', 13, 'bold'), padding=12)
        style.configure('Action.TButton', font=('Segoe UI', 10, 'bold'), padding=8)
        
        # Custom colors for buttons
        style.map('Generate.TButton',
                 background=[('active', '#27ae60'), ('!active', '#2ecc71')],
                 foreground=[('active', 'white'), ('!active', 'white')])
        
        self.create_widgets()
        
    def create_widgets(self):
        # Main container with scrollbar
        main_canvas = tk.Canvas(self.root, bg='#f5f7fa', highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.root, orient="vertical", command=main_canvas.yview)
        scrollable_frame = ttk.Frame(main_canvas, style='TFrame')
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: main_canvas.configure(scrollregion=main_canvas.bbox("all"))
        )
        
        main_canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        main_canvas.configure(yscrollcommand=scrollbar.set)
        
        main_canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Bind mouse wheel
        def on_mousewheel(event):
            main_canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        main_canvas.bind_all("<MouseWheel>", on_mousewheel)
        
        # Title Section with gradient-like effect
        title_frame = tk.Frame(scrollable_frame, bg='#3498db', height=100)
        title_frame.pack(fill='x', padx=0, pady=0)
        
        # Add menu bar
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="📘 BMIoT Firmware Architecture", command=self.show_firmware_help)
        help_menu.add_command(label="🔍 Column Descriptions", command=self.show_column_help)
        help_menu.add_separator()
        help_menu.add_command(label="About", command=self.show_about)
        
        title_inner = tk.Frame(title_frame, bg='#3498db')
        title_inner.pack(expand=True, pady=20)
        
        tk.Label(title_inner, text="⚙️ Modbus Configuration Generator Pro", 
                font=('Segoe UI', 20, 'bold'), fg='white', bg='#3498db').pack()
        tk.Label(title_inner, text="✨ Automatically generate modbus_io.json and parameter_config.json with ease", 
                font=('Segoe UI', 11), fg='#ecf0f1', bg='#3498db').pack(pady=5)
        
        # Communication Settings Section
        comm_frame = ttk.LabelFrame(scrollable_frame, text="  📡 Communication Settings  ", padding=20)
        comm_frame.pack(fill='x', padx=25, pady=15)
        
        comm_grid = ttk.Frame(comm_frame)
        comm_grid.pack(fill='x')
        
        # Baudrate
        ttk.Label(comm_grid, text="Baudrate:", font=('Segoe UI', 10, 'bold')).grid(row=0, column=0, sticky='w', padx=10, pady=8)
        self.baudrate_var = tk.StringVar(value="19200")
        baudrate_combo = ttk.Combobox(comm_grid, textvariable=self.baudrate_var, 
                                      values=["1200", "2400", "4800", "9600", "19200", "38400", "57600", "115200"], 
                                      width=20, state='readonly', font=('Segoe UI', 10))
        baudrate_combo.grid(row=0, column=1, padx=10, pady=8)
        ttk.Label(comm_grid, text="bits/sec", font=('Segoe UI', 9), foreground='#7f8c8d').grid(row=0, column=2, sticky='w', padx=5)
        
        # Data Format - Separated into three parts
        ttk.Label(comm_grid, text="Data Format:", font=('Segoe UI', 10, 'bold')).grid(row=0, column=3, sticky='w', padx=(30, 10), pady=8)
        
        format_frame = ttk.Frame(comm_grid)
        format_frame.grid(row=0, column=4, columnspan=3, sticky='w', padx=10)
        
        # Data Bits
        ttk.Label(format_frame, text="Data Bits:", font=('Segoe UI', 9)).grid(row=0, column=0, sticky='w', padx=5)
        self.data_bits_var = tk.StringVar(value="8")
        data_bits_combo = ttk.Combobox(format_frame, textvariable=self.data_bits_var, 
                                      values=["7", "8"], width=5, state='readonly', font=('Segoe UI', 9))
        data_bits_combo.grid(row=0, column=1, padx=5)
        
        # Parity
        ttk.Label(format_frame, text="Parity:", font=('Segoe UI', 9)).grid(row=0, column=2, sticky='w', padx=(15, 5))
        self.parity_var = tk.StringVar(value="E")
        parity_combo = ttk.Combobox(format_frame, textvariable=self.parity_var, 
                                   values=["N (None)", "E (Even)", "O (Odd)"], width=12, state='readonly', font=('Segoe UI', 9))
        parity_combo.grid(row=0, column=3, padx=5)
        parity_combo.set("E (Even)")
        
        # Stop Bits
        ttk.Label(format_frame, text="Stop Bits:", font=('Segoe UI', 9)).grid(row=0, column=4, sticky='w', padx=(15, 5))
        self.stop_bits_var = tk.StringVar(value="1")
        stop_bits_combo = ttk.Combobox(format_frame, textvariable=self.stop_bits_var, 
                                      values=["1", "2"], width=5, state='readonly', font=('Segoe UI', 9))
        stop_bits_combo.grid(row=0, column=5, padx=5)
        
        # Profile Selection
        ttk.Label(comm_grid, text="Profile:", font=('Segoe UI', 10, 'bold')).grid(row=1, column=0, sticky='w', padx=10, pady=8)
        self.profile_var = tk.StringVar(value="0")
        profile_combo = ttk.Combobox(comm_grid, textvariable=self.profile_var,
                                    values=bc.DROPDOWN_OPTIONS['profile'],
                                    width=60, state='readonly', font=('Segoe UI', 9))
        profile_combo.grid(row=1, column=1, columnspan=6, padx=10, pady=8, sticky='ew')
        profile_combo.set(bc.DROPDOWN_OPTIONS['profile'][0])
        
        # Register Configuration Section
        register_frame = ttk.LabelFrame(scrollable_frame, text="  📋 Register Configuration  ", padding=20)
        register_frame.pack(fill='both', expand=True, padx=25, pady=15)
        
        # Button toolbar with icons
        btn_toolbar = ttk.Frame(register_frame)
        btn_toolbar.pack(fill='x', pady=(0, 15))
        
        # Left side buttons
        left_buttons = ttk.Frame(btn_toolbar)
        left_buttons.pack(side='left')
        
        btn_add = ttk.Button(left_buttons, text="➕ Add Register", command=self.add_register_row, style='Action.TButton')
        btn_add.pack(side='left', padx=5)
        
        btn_edit = ttk.Button(left_buttons, text="✏️ Edit Selected", command=self.edit_selected_row, style='Action.TButton')
        btn_edit.pack(side='left', padx=5)
        
        btn_delete = ttk.Button(left_buttons, text="🗑️ Delete Selected", command=self.delete_selected_row, style='Action.TButton')
        btn_delete.pack(side='left', padx=5)
        
        btn_clear = ttk.Button(left_buttons, text="🧹 Clear All", command=self.clear_all_registers, style='Action.TButton')
        btn_clear.pack(side='left', padx=5)
        
        # Right side buttons
        right_buttons = ttk.Frame(btn_toolbar)
        right_buttons.pack(side='right')
        
        btn_sample = ttk.Button(right_buttons, text="📝 Load Sample", command=self.load_sample_data, style='Action.TButton')
        btn_sample.pack(side='left', padx=5)
        
        btn_import = ttk.Button(right_buttons, text="📂 Import Registers", command=self.import_registers, style='Action.TButton')
        btn_import.pack(side='left', padx=5)
        
        btn_export = ttk.Button(right_buttons, text="💾 Export Registers", command=self.export_registers, style='Action.TButton')
        btn_export.pack(side='left', padx=5)
        
        # NEW: Reverse transformation button
        btn_import_json = ttk.Button(right_buttons, text="🔄 Import Modbus+Paramap JSON", command=self.import_modbus_paramap, style='Action.TButton')
        btn_import_json.pack(side='left', padx=5)
        
        # Register Table with enhanced styling
        table_frame = ttk.Frame(register_frame)
        table_frame.pack(fill='both', expand=True)
        
# Create Treeview with Serial Number
        # Note: Columns 18-26 are metadata fields not displayed in GUI but used for validation
        columns = ('S.No', 'Slave ID', 'FC', 'Address', 'Length', 'FMT', 'Multiplier',
                   'Access', 'Cloud Output', 'JSON Group', 'JSON Unit', 'JSON Key', 'Array Membership',
                   'B5 ID', 'Packet Num', 'Packet SA', 'Packet NRT',
                   'Parameter Type', 'Write Param ID', 'Feedback Param ID', 'P2 MPI Index', 'P3 MPI Index',
                   'Equipment Group', 'Device Name', 'Equipment Type', 'JKA Equipment Index')
        
        # Visible columns (1-17) - metadata columns (18-26) are hidden
        visible_columns = columns[:17]
        
        self.tree = ttk.Treeview(table_frame, columns=columns, show='headings', height=12, displaycolumns=visible_columns)
        
        # Define headings with better widths
        self.tree.heading('S.No', text='S.No')
        self.tree.column('S.No', width=50, anchor='center')
        
        # Set specific widths for important columns
        self.tree.column('Array Membership', width=150, anchor='w')
        
        for col in columns[1:]:
            self.tree.heading(col, text=col)
            if col in ['Slave ID', 'FC', 'Address', 'Length', 'FMT', 'B5 ID', 'Packet Num', 'Packet SA', 'Packet NRT']:
                self.tree.column(col, width=80, anchor='center')
            elif col in ['Multiplier', 'Access', 'Cloud Output']:
                self.tree.column(col, width=90, anchor='center')
            else:
                self.tree.column(col, width=130)
        
        # Enhanced scrollbars
        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(table_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        # Add tooltips for firmware-mapped columns
        self.column_help = {
            'B5 ID': 'Parameter index in firmware Block 5 (s_Indx field)',
            'Packet Num': 'Modbus polling packet group number (B5.PN → used by eModbusRTU_Construct)',
            'Packet SA': 'Packet start address from Block 4 (B4.SA)',
            'Packet NRT': 'Number of registers per packet from Block 4 (B4.NRT)',
            'Cloud Output': 'Include in MQTT/HTTPS output buffer (P3.MPI - firmware required)',
            'Array Membership': 'Equipment group in output JSON structure (maps to JKY equipment types)'
        }
        
        self.tree.grid(row=0, column=0, sticky='nsew')
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')
        
        table_frame.grid_rowconfigure(0, weight=1)
        table_frame.grid_columnconfigure(0, weight=1)
        
        # Alternating row colors
        self.tree.tag_configure('oddrow', background='#f9f9f9')
        self.tree.tag_configure('evenrow', background='#ffffff')
        
        # Double-click to edit
        self.tree.bind('<Double-1>', lambda e: self.edit_selected_row())
        
        # Status bar
        status_frame = ttk.Frame(register_frame)
        status_frame.pack(fill='x', pady=(10, 0))
        self.status_label = ttk.Label(status_frame, text="📊 Total Registers: 0", font=('Segoe UI', 10))
        self.status_label.pack(side='left')
        
        # Generate Button with enhanced styling
        generate_frame = tk.Frame(scrollable_frame, bg='#f5f7fa')
        generate_frame.pack(fill='x', padx=25, pady=20)
        
        generate_btn = tk.Button(generate_frame, text="🚀 Generate Configuration Files", 
                                font=('Segoe UI', 14, 'bold'), 
                                bg='#2ecc71', fg='white', 
                                activebackground='#27ae60', activeforeground='white',
                                relief='flat', padx=40, pady=15,
                                cursor='hand2',
                                command=self.generate_configs)
        generate_btn.pack()
        
        # Hover effect
        def on_enter(e):
            generate_btn['background'] = '#27ae60'
        def on_leave(e):
            generate_btn['background'] = '#2ecc71'
        generate_btn.bind("<Enter>", on_enter)
        generate_btn.bind("<Leave>", on_leave)
        
        # Output Section with tabs
        output_frame = ttk.LabelFrame(scrollable_frame, text="  📄 Generated Configuration Files  ", padding=20)
        output_frame.pack(fill='both', expand=True, padx=25, pady=15)
        
        # Status indicator for generated JSONs
        status_info_frame = ttk.Frame(output_frame)
        status_info_frame.pack(fill='x', pady=(0, 5))
        ttk.Label(status_info_frame, text="📊 Status:", font=('Segoe UI', 9, 'bold')).pack(side='left', padx=5)
        self.json_status_label = ttk.Label(status_info_frame, text="No configurations generated yet", 
                                           font=('Segoe UI', 9), foreground='gray')
        self.json_status_label.pack(side='left', padx=5)
        
        # Notebook for tabs
        self.notebook = ttk.Notebook(output_frame)
        self.notebook.pack(fill='both', expand=True, pady=(0, 10))
        
        # Tab 1: modbus_io.json
        modbus_tab = ttk.Frame(self.notebook)
        self.notebook.add(modbus_tab, text="  📑 modbus_io.json  ")
        
        self.modbus_text = scrolledtext.ScrolledText(modbus_tab, wrap=tk.WORD, 
                                                      font=('Consolas', 10),
                                                      bg='#1e1e1e', fg='#d4d4d4',
                                                      insertbackground='white',
                                                      selectbackground='#264f78')
        self.modbus_text.pack(fill='both', expand=True)
        
        # Tab 2: parameter_config.json
        param_tab = ttk.Frame(self.notebook)
        self.notebook.add(param_tab, text="  📑 parameter_config.json  ")
        
        self.param_text = scrolledtext.ScrolledText(param_tab, wrap=tk.WORD, 
                                                    font=('Consolas', 10),
                                                    bg='#1e1e1e', fg='#d4d4d4',
                                                    insertbackground='white',
                                                    selectbackground='#264f78')
        self.param_text.pack(fill='both', expand=True)
        
        # Tab 3: output.json
        output_tab = ttk.Frame(self.notebook)
        self.notebook.add(output_tab, text="  📑 output.json  ")
        
        self.output_text = scrolledtext.ScrolledText(output_tab, wrap=tk.WORD, 
                                                     font=('Consolas', 10),
                                                     bg='#1e1e1e', fg='#d4d4d4',
                                                     insertbackground='white',
                                                     selectbackground='#264f78')
        self.output_text.pack(fill='both', expand=True)
        
        # Add initial placeholder messages
        initial_message = "// Click 'Generate Configs' to create Output JSON\\n// Output JSON will appear here after generation"
        self.modbus_text.insert('1.0', initial_message)
        self.param_text.insert('1.0', initial_message)
        self.output_text.insert('1.0', initial_message)
        
        # Download buttons with icons
        download_frame = ttk.Frame(output_frame)
        download_frame.pack(fill='x')
        
        ttk.Button(download_frame, text="💾 Save modbus_io.json", 
                  command=self.save_modbus_io, style='Action.TButton').pack(side='left', padx=5)
        ttk.Button(download_frame, text="💾 Save parameter_config.json", 
                  command=self.save_parameter_config, style='Action.TButton').pack(side='left', padx=5)
        ttk.Button(download_frame, text="� Save output.json", 
                  command=self.save_output_json, style='Action.TButton').pack(side='left', padx=5)
        ttk.Button(download_frame, text="📦 Save All Files", 
                  command=self.save_all_files, style='Action.TButton').pack(side='left', padx=5)
        self.update_status()
    
    def update_status(self):
        count = len(self.tree.get_children())
        self.status_label.config(text=f"📊 Total Registers: {count}")
    
    def add_register_row(self):
        RegisterDialog(self.root, self)
        
    def edit_selected_row(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("⚠️ Warning", "Please select a row to edit!")
            return
        
        item = selected[0]
        values = self.tree.item(item)['values']
        
        # Create edit dialog with pre-filled values
        EditRegisterDialog(self.root, self, item, values)
    
    def load_sample_data(self):
        """Load sample data with proper validation"""
        sample_data = [
            # Read: UINT16
            {'slave_id': 1, 'fc': 3, 'address': 100, 'length': 1, 'fmt': 3, 
             'multiplier': 1.0, 'access': 'R', 'cloud': 'Yes', 
             'json_group': 'AHU_RL_AIE1', 'json_unit': 'DegC', 'json_key': 'RAT'},
            # Read: INT32 Big Endian
            {'slave_id': 1, 'fc': 3, 'address': 200, 'length': 2, 'fmt': 4, 
             'multiplier': 0.1, 'access': 'R', 'cloud': 'Yes', 
             'json_group': 'AHU_RL_AIE2', 'json_unit': 'Vol', 'json_key': 'ChW_Fb_V'},
            # Read: Float 32-bit Big Endian
            {'slave_id': 1, 'fc': 3, 'address': 300, 'length': 2, 'fmt': 1, 
             'multiplier': 1.0, 'access': 'R', 'cloud': 'Yes', 
             'json_group': 'AHU_RL_Mb1', 'json_unit': 'Watt', 'json_key': 'VFD_P'},
            # Read: UINT32 Little Endian
            {'slave_id': 1, 'fc': 3, 'address': 400, 'length': 2, 'fmt': 7, 
             'multiplier': 1.0, 'access': 'R', 'cloud': 'Yes', 
             'json_group': 'AHU_RL_Mb2', 'json_unit': 'Hour', 'json_key': 'VFD_Rhr'},
            # Write: UINT16
            {'slave_id': 1, 'fc': 6, 'address': 500, 'length': 1, 'fmt': 3, 
             'multiplier': 1.0, 'access': 'W', 'cloud': 'No', 
             'json_group': '', 'json_unit': '', 'json_key': ''},
            # Read-Write: INT16 - Write + verification parameter
            # IMPORTANT: RW parameters should NOT have cloud=Yes
            # The read component is only for write verification, not telemetry
            {'slave_id': 2, 'fc': 3, 'address': 1000, 'length': 1, 'fmt': 8, 
             'multiplier': 0.1, 'access': 'RW', 'cloud': 'No', 
             'json_group': '', 'json_unit': '', 'json_key': ''},
            # Read: Coil (FC=1)
            {'slave_id': 2, 'fc': 1, 'address': 1, 'length': 1, 'fmt': 3, 
             'multiplier': 1.0, 'access': 'R', 'cloud': 'Yes', 
             'json_group': 'Chiller_DIE1', 'json_unit': 'St', 'json_key': 'ChillerRun'},
            # Write: Coil (FC=5)
            {'slave_id': 2, 'fc': 5, 'address': 100, 'length': 1, 'fmt': 3, 
             'multiplier': 1.0, 'access': 'W', 'cloud': 'No', 
             'json_group': '', 'json_unit': '', 'json_key': ''},
        ]
        
        # Validate each sample before loading
        errors = []
        for idx, data in enumerate(sample_data, 1):
            # Validate slave ID
            if data['slave_id'] < 1 or data['slave_id'] > 247:
                errors.append(f"Sample {idx}: Invalid slave ID {data['slave_id']} (must be 1-247)")
            
            # Validate address
            if data['address'] < 0 or data['address'] > 65535:
                errors.append(f"Sample {idx}: Invalid address {data['address']} (must be 0-65535)")
            
            # Validate function code
            if data['fc'] not in [1, 2, 3, 4, 5, 6, 15, 16]:
                errors.append(f"Sample {idx}: Invalid function code {data['fc']}")
            
            # Validate format code
            if data['fmt'] not in [1, 2, 3, 4, 5, 6, 7, 8]:
                errors.append(f"Sample {idx}: Invalid format code {data['fmt']}")
            
            # Validate length matches format
            expected_length = bc.get_register_length(data['fmt'])
            if data['length'] != expected_length:
                errors.append(f"Sample {idx}: Length mismatch - Format {data['fmt']} requires length {expected_length}, got {data['length']}")
            
            # Validate access type
            if data['access'] not in ['R', 'W', 'RW']:
                errors.append(f"Sample {idx}: Invalid access type '{data['access']}' (must be R, W, or RW)")
            
            # Validate multiplier is numeric
            try:
                float(data['multiplier'])
            except (ValueError, TypeError):
                errors.append(f"Sample {idx}: Invalid multiplier '{data['multiplier']}' (must be numeric)")
        
        # If validation errors, show them and abort
        if errors:
            error_msg = "\n".join(errors[:10])
            if len(errors) > 10:
                error_msg += f"\n...and {len(errors) - 10} more errors"
            messagebox.showerror("❌ Sample Data Validation Failed", 
                               f"Sample data contains errors:\n\n{error_msg}")
            return
        
        # Clear existing data
        self.clear_all_registers()
        
        # All validation passed - load the data
        for idx, data in enumerate(sample_data):
            tag = 'evenrow' if idx % 2 == 0 else 'oddrow'
            access = data['access']
            self.tree.insert('', 'end', values=(
                idx + 1,
                data['slave_id'], data['fc'], data['address'], data['length'],
                data['fmt'], data['multiplier'], access, data['cloud'],
                data['json_group'], data['json_unit'], data['json_key'],
                data.get('array_membership', ''),
                data.get('b5_id', idx + 1), data.get('packet_num', 0),
                data.get('packet_sa', data['address']), data.get('packet_nrt', data['length']),
                # Metadata columns (18-26) for sample data
                'write' if access in ['W', 'RW'] else 'read_only',  # parameter_type
                '', '', '', '',  # write_param_id, feedback_param_id, p2_mpi_index, p3_mpi_index
                '', '', '', -1  # equipment_group, device_name, equipment_type, jka_equipment_index
            ), tags=(tag,))
        
        self.update_status()
        messagebox.showinfo("✅ Success", f"Sample data loaded successfully!\n\n{len(sample_data)} parameters added with proper validation.")
    
    def import_registers(self):
        filename = filedialog.askopenfilename(
            title="Import Register Configuration",
            filetypes=[("JSON files", "*.json"), ("CSV files", "*.csv"), ("All files", "*.*")]
        )
        
        if not filename:
            return
        
        try:
            if filename.endswith('.json'):
                with open(filename, 'r') as f:
                    data = json.load(f)
                    registers = data.get('registers', [])
            elif filename.endswith('.csv'):
                with open(filename, 'r') as f:
                    reader = csv.DictReader(f)
                    registers = list(reader)
            else:
                messagebox.showerror("❌ Error", "Unsupported file format!")
                return
            
            # Clear existing and add imported
            self.clear_all_registers()
            
            for idx, reg in enumerate(registers):
                tag = 'evenrow' if idx % 2 == 0 else 'oddrow'
                access = reg.get('access', 'R')
                self.tree.insert('', 'end', values=(
                    idx + 1,
                    reg.get('slave_id', 1),
                    reg.get('fc', 3),
                    reg.get('address', 0),
                    reg.get('length', 1),
                    reg.get('fmt', 1),
                    reg.get('multiplier', 1.0),
                    access,
                    reg.get('cloud', 'No'),
                    reg.get('json_group', ''),
                    reg.get('json_unit', ''),
                    reg.get('json_key', ''),
                    reg.get('array_membership', ''),
                    reg.get('b5_id', idx + 1),
                    reg.get('packet_num', 0),
                    reg.get('packet_sa', reg.get('address', 0)),
                    reg.get('packet_nrt', reg.get('length', 1)),
                    # Metadata columns (18-26) for imported CSV/JSON
                    reg.get('parameter_type', 'write' if access in ['W', 'RW'] else 'read_only'),
                    reg.get('write_param_id', ''),
                    reg.get('feedback_param_id', ''),
                    reg.get('p2_mpi_index', ''),
                    reg.get('p3_mpi_index', ''),
                    reg.get('equipment_group', ''),
                    reg.get('device_name', ''),
                    reg.get('equipment_type', ''),
                    reg.get('jka_equipment_index', -1)
                ), tags=(tag,))
            
            self.update_status()
            messagebox.showinfo("✅ Success", f"Imported {len(registers)} registers successfully!")
        
        except Exception as e:
            messagebox.showerror("❌ Error", f"Failed to import file:\n{str(e)}")
    
    def export_registers(self):
        if not self.tree.get_children():
            messagebox.showwarning("⚠️ Warning", "No registers to export!")
            return
        
        # NEW: Validate cloud parameters before export
        cloud_params = []
        for item in self.tree.get_children():
            values = self.tree.item(item)['values']
            if len(values) > 8 and values[8] == 'Yes':  # Cloud Output column
                cloud_params.append(values[0])  # S.No
        
        if not cloud_params:
            response = messagebox.askyesnocancel(
                "⚠️ Cloud Parameters Required",
                "WARNING: No parameters marked for Cloud Output!\n\n"
                "The firmware requires at least one parameter in P3.MPI (cloud output buffer).\n"
                "Without cloud parameters, the firmware cannot publish data to MQTT/HTTPS.\n\n"
                "• Click 'Yes' to continue anyway (may cause firmware errors)\n"
                "• Click 'No' to go back and mark parameters for cloud output\n"
                "• Click 'Cancel' to abort export"
            )
            if response is None:  # Cancel
                return
            elif not response:  # No - go back
                messagebox.showinfo(
                    "How to Fix",
                    "To mark parameters for cloud output:\n\n"
                    "1. Double-click a register row to edit\n"
                    "2. Set 'Cloud Output' to 'Yes'\n"
                    "3. Fill in JSON Group, JSON Unit, and JSON Key\n"
                    "4. Repeat for all parameters you want to publish to cloud\n"
                    "5. Export again"
                )
                return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("CSV files", "*.csv"), ("All files", "*.*")],
            initialfile="register_config.json"
        )
        
        if not filename:
            return
        
        try:
            registers = []
            for item in self.tree.get_children():
                values = self.tree.item(item)['values']
                registers.append({
                    'slave_id': values[1],
                    'fc': values[2],
                    'address': values[3],
                    'length': values[4],
                    'fmt': values[5],
                    'multiplier': values[6],
                    'access': values[7],
                    'cloud': values[8],
                    'json_group': values[9],
                    'json_unit': values[10],
                    'json_key': values[11],
                    'array_membership': values[12] if len(values) > 12 else ''
                })
            
            if filename.endswith('.json'):
                if FORMATTER_AVAILABLE:
                    format_and_save_json({'registers': registers}, filename)
                else:
                    with open(filename, 'w') as f:
                        json.dump({'registers': registers}, f, indent=2)
            elif filename.endswith('.csv'):
                with open(filename, 'w', newline='') as f:
                    writer = csv.DictWriter(f, fieldnames=registers[0].keys())
                    writer.writeheader()
                    writer.writerows(registers)
            
            messagebox.showinfo("✅ Success", f"Exported {len(registers)} registers successfully!")
        
        except Exception as e:
            messagebox.showerror("❌ Error", f"Failed to export file:\n{str(e)}")
    
    def import_modbus_paramap(self):
        """Import Modbus and Paramap JSON files to populate register configuration"""
        processing_dialog = None
        try:
            # Ask for Modbus JSON file
            modbus_file = filedialog.askopenfilename(
                title="Select Modbus JSON file (e.g., Modbus_Config.json)",
                filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
            )
            
            if not modbus_file:
                return
            
            # Ask for Paramap JSON file
            paramap_file = filedialog.askopenfilename(
                title="Select Paramap JSON file (e.g., ParamMap_Config.json)",
                filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
            )
            
            if not paramap_file:
                return
            
            # Show processing dialog
            processing_dialog = tk.Toplevel(self.root)
            processing_dialog.title("Processing...")
            processing_dialog.geometry("400x150")
            processing_dialog.transient(self.root)
            processing_dialog.grab_set()
            
            tk.Label(processing_dialog, text="🔄 Reverse Transformation in Progress...", 
                    font=('Segoe UI', 12, 'bold')).pack(pady=20)
            progress_label = tk.Label(processing_dialog, text="Loading JSON files...", 
                                     font=('Segoe UI', 10))
            progress_label.pack(pady=10)
            
            processing_dialog.update()
            
            # Load JSON files
            with open(modbus_file, 'r', encoding='utf-8') as f:
                modbus_json = json.load(f)
            
            with open(paramap_file, 'r', encoding='utf-8') as f:
                paramap_json = json.load(f)
            
            progress_label.config(text="Extracting configurations...")
            processing_dialog.update()
            
            # Perform reverse transformation
            result = self._reverse_transform(modbus_json, paramap_json)
            
            # Check if we got valid results
            if not result or 'registers' not in result or not result['registers']:
                if processing_dialog:
                    processing_dialog.destroy()
                messagebox.showwarning("⚠️ Warning", "No registers were extracted from the JSON files.\n\nPlease check that the files contain valid configuration data.")
                return
            
            progress_label.config(text="Populating application...")
            processing_dialog.update()
            
            # Clear existing data
            for item in self.tree.get_children():
                self.tree.delete(item)
            
            # Populate communication settings
            if 'B2' in modbus_json:
                br = modbus_json['B2'].get('BR', 19200)
                self.baudrate_var.set(str(br))
                
                data_format = modbus_json['B2'].get('DF', '8E1')
                # Parse data format (e.g., "8N1", "8E1")
                if len(data_format) >= 3:
                    self.data_bits_var.set(data_format[0])
                    parity = data_format[1]
                    parity_map = {'N': 'N (None)', 'E': 'E (Even)', 'O': 'O (Odd)'}
                    self.parity_var.set(parity_map.get(parity, 'E (Even)'))
                    self.stop_bits_var.set(data_format[2])
            
            # Populate profile if available
            if 'MST' in paramap_json and 'PRF' in paramap_json['MST']:
                profile_val = paramap_json['MST']['PRF']
                # Find matching profile in dropdown
                for profile_option in bc.DROPDOWN_OPTIONS['profile']:
                    if profile_option.startswith(str(profile_val)):
                        self.profile_var.set(profile_option)
                        break
            
            # Add registers to tree with all 26 columns (17 visible + 9 metadata)
            for i, reg in enumerate(result['registers'], 1):
                self.tree.insert('', 'end', values=(
                    i,
                    reg['slave_id'],
                    reg['fc'],
                    reg['address'],
                    reg['length'],
                    reg['fmt'],
                    reg['multiplier'],
                    reg['access'],
                    reg['cloud'],
                    reg['json_group'],
                    reg['json_unit'],
                    reg['json_key'],
                    reg.get('array_membership', ''),
                    reg.get('b5_id', i),
                    reg.get('packet_num', 0),
                    reg.get('packet_sa', reg['address']),
                    reg.get('packet_nrt', reg['length']),
                    # Metadata columns from reverse engine (columns 18-26)
                    reg.get('parameter_type', 'read_only'),
                    reg.get('write_param_id', ''),
                    reg.get('feedback_param_id', ''),
                    reg.get('p2_mpi_index', ''),
                    reg.get('p3_mpi_index', ''),
                    # Phase 3: Equipment hierarchy columns (23-26)
                    reg.get('equipment_group', ''),
                    reg.get('device_name', ''),
                    reg.get('equipment_type', ''),
                    reg.get('jka_equipment_index', -1)
                ), tags=('evenrow' if i % 2 == 0 else 'oddrow',))
            
            self.update_status()
            
            if processing_dialog:
                processing_dialog.destroy()
                processing_dialog = None
            
            # Show success message
            messagebox.showinfo("✅ Success", 
                              f"Reverse transformation completed!\n\n"
                              f"✅ Loaded {len(result['registers'])} register entries\n"
                              f"✅ Communication settings updated\n"
                              f"✅ Profile settings updated\n\n"
                              f"You can now:\n"
                              f"• Edit registers as needed\n"
                              f"• Generate new configuration files\n"
                              f"• Export to CSV")
        
        except FileNotFoundError as e:
            if processing_dialog:
                processing_dialog.destroy()
            messagebox.showerror("❌ Error", f"File not found:\n{str(e)}")
        except json.JSONDecodeError as e:
            if processing_dialog:
                processing_dialog.destroy()
            messagebox.showerror("❌ Error", f"Invalid JSON file:\n{str(e)}\n\nPlease ensure the file is valid JSON format.")
        except KeyError as e:
            if processing_dialog:
                processing_dialog.destroy()
            messagebox.showerror("❌ Error", f"Missing required key in JSON: {str(e)}\n\nPlease ensure both files are valid Modbus and Paramap JSON files with all required sections (B5, B6, P2, P3).")
        except Exception as e:
            if processing_dialog:
                processing_dialog.destroy()
            messagebox.showerror("❌ Error", f"Reverse transformation failed:\n{str(e)}\n\nCheck console for detailed error.")
            import traceback
            print("="*70)
            print("REVERSE TRANSFORMATION ERROR:")
            print("="*70)
            traceback.print_exc()
            print("="*70)
    
    def _reverse_transform(self, modbus_json, paramap_json):
        """Internal reverse transformation logic using updated reverse_engine"""
        try:
            # Use the updated reverse_engine module
            from reverse_engine import ReverseTransformationEngine
            
            engine = ReverseTransformationEngine()
            result = engine.transform(modbus_json, paramap_json)
            
            # Store metadata for perfect reconstruction
            self.metadata = result.get('metadata', {})
            
            return result
        except ImportError:
            # Fallback to old logic if reverse_engine not available
            pass
        
        # Original validation
        required_modbus = ['B5', 'B4']
        for key in required_modbus:
            if key not in modbus_json:
                raise KeyError(f"Modbus JSON missing required section: {key}")
        
        required_paramap = ['P2', 'P3']
        for key in required_paramap:
            if key not in paramap_json:
                raise KeyError(f"Paramap JSON missing required section: {key}")
        
        # Extract B5 mappings
        b5 = modbus_json['B5']
        required_b5_keys = ['ID', 'PN', 'STA', 'LN', 'FMT', 'MLT']
        for key in required_b5_keys:
            if key not in b5:
                raise KeyError(f"B5 section missing required key: {key}")
        
        # Check B5 array lengths are consistent
        b5_length = len(b5['ID'])
        for key in required_b5_keys:
            if len(b5[key]) != b5_length:
                raise ValueError(f"B5 array length mismatch: {key} has {len(b5[key])} elements, expected {b5_length}")
        
        b5_id_to_props = {}
        for i in range(len(b5['ID'])):
            b5_id = b5['ID'][i]
            b5_id_to_props[b5_id] = {
                'packet_num': b5['PN'][i],
                'address': b5['STA'][i],
                'length': b5['LN'][i],
                'fmt': b5['FMT'][i],
                'multiplier': b5['MLT'][i]
            }
        
        # Extract B4 mappings (packet to slave/FC)
        b4 = modbus_json['B4']
        required_b4_keys = ['SA', 'FC', 'SID']
        for key in required_b4_keys:
            if key not in b4:
                raise KeyError(f"B4 section missing required key: {key}")
        
        packet_to_slave_fc = {}
        for i in range(len(b4.get('SA', []))):
            packet_num = i + 1
            packet_to_slave_fc[packet_num] = {
                'slave_id': b4['SID'][i] if i < len(b4['SID']) else 0,
                'fc': b4['FC'][i] if i < len(b4['FC']) else 0
            }
        
        # Classify parameters
        b6 = modbus_json.get('B6', {'WP': [], 'RP': []})
        write_params = set(b6.get('WP', []))
        feedback_params = set(b6.get('RP', []))
        p2_mpi = set(paramap_json['P2'].get('MPI', []))
        p3_mpi = set(paramap_json['P3'].get('MPI', []))
        # Extract all P2/P3 arrays for array_membership tracking
        p2_lbi = set(paramap_json["P2"].get("LBI", []))
        p2_rpci = set(paramap_json["P2"].get("RPCI", []))
        p3_mdi = set(paramap_json["P3"].get("MDI", []))
        
        
        # Extract JKY mappings
        b5_to_json_keys = {}
        if 'JKY' in paramap_json:
            jky = paramap_json['JKY']
            jka = jky.get('JKA', [])
            p3 = paramap_json['P3']
            
            # Build MDI to B5 mapping - with validation
            if 'MDI' in p3 and 'MPI' in p3:
                mdi_to_b5 = {}
                min_len = min(len(p3['MDI']), len(p3['MPI']))
                for i in range(min_len):
                    mdi = p3['MDI'][i]
                    b5_id = p3['MPI'][i]
                    mdi_to_b5[mdi] = b5_id
                
                # Flatten JKY structure
                mdi_counter = 1
                for jka_entry in jka:
                    if not isinstance(jka_entry, list) or len(jka_entry) < 3:
                        continue
                    
                    group = str(jka_entry[0])
                    units = jka_entry[1] if isinstance(jka_entry[1], list) else []
                    keys = jka_entry[2] if isinstance(jka_entry[2], list) else []
                    
                    # Ensure units and keys are lists and same length
                    min_entries = min(len(units), len(keys))
                    for j in range(min_entries):
                        if mdi_counter in mdi_to_b5:
                            b5_id = mdi_to_b5[mdi_counter]
                            b5_to_json_keys[b5_id] = {
                                'json_group': group,
                                'json_unit': str(units[j]),
                                'json_key': str(keys[j])
                            }
                        mdi_counter += 1
        
        # Determine access type function
        def determine_access(b5_id):
            if b5_id in write_params:
                # Check if has paired feedback
                try:
                    wp_list = b6.get('WP', [])
                    rp_list = b6.get('RP', [])
                    if b5_id in wp_list:
                        wp_index = wp_list.index(b5_id)
                        if wp_index < len(rp_list):
                            return 'RW'
                except (ValueError, KeyError, IndexError):
                    pass
                return 'W'
            return 'R'

        # Determine array membership function
        def determine_array_membership(b5_id):
            memberships = []
            if b5_id in p2_lbi:
                memberships.append("P2.LBI")
            if b5_id in p2_rpci:
                memberships.append("P2.RPCI")
            if b5_id in p2_mpi:
                memberships.append("P2.MPI")
            if b5_id in p3_mpi:
                memberships.append("P3.MPI")
            if b5_id in p3_mdi:
                memberships.append("P3.MDI")
            return ",".join(memberships)

        
        # Reconstruct registers
        registers = []
        for b5_id in sorted(b5['ID']):
            if b5_id not in b5_id_to_props:
                continue  # Skip if mapping doesn't exist
            
            props = b5_id_to_props[b5_id]
            packet_num = props['packet_num']
            slave_fc = packet_to_slave_fc.get(packet_num, {'slave_id': 0, 'fc': 0})
            
            # Ensure slave_id and fc are valid
            slave_id = slave_fc.get('slave_id', 0)
            fc = slave_fc.get('fc', 0)
            
            # Skip invalid entries
            if slave_id == 0 or fc == 0:
                continue
            
            cloud = 'Yes' if b5_id in b5_to_json_keys else 'No'
            json_keys = b5_to_json_keys.get(b5_id, {
                'json_group': '',
                'json_unit': '',
                'json_key': ''
            })
            
            register = {
                'slave_id': slave_id,
                'fc': fc,
                'address': props['address'],
                'length': props['length'],
                'fmt': props['fmt'],
                'multiplier': props['multiplier'],
                'access': determine_access(b5_id),
                'cloud': cloud,
                'json_group': json_keys.get('json_group', ''),
                'json_unit': json_keys.get('json_unit', ''),
                'json_key': json_keys.get('json_key', ''),
                'array_membership': determine_array_membership(b5_id)
            }
            
            registers.append(register)
        
        return {'registers': registers}
    
    def clear_all_registers(self):
        if not self.tree.get_children():
            return
        
        if messagebox.askyesno("⚠️ Confirm", "Are you sure you want to clear all registers?"):
            for item in self.tree.get_children():
                self.tree.delete(item)
            self.update_status()
    
    def delete_selected_row(self):
        selected = self.tree.selection()
        if selected:
            if messagebox.askyesno("⚠️ Confirm", "Delete selected register(s)?"):
                for item in selected:
                    self.tree.delete(item)
                # Renumber all items
                self.renumber_items()
                self.update_status()
        else:
            messagebox.showwarning("⚠️ Warning", "Please select a row to delete!")
    
    def renumber_items(self):
        for idx, item in enumerate(self.tree.get_children()):
            values = list(self.tree.item(item)['values'])
            values[0] = idx + 1
            tag = 'evenrow' if idx % 2 == 0 else 'oddrow'
            self.tree.item(item, values=values, tags=(tag,))
    
    def get_register_data(self):
        registers = []
        slaves_set = set()
        for idx, item in enumerate(self.tree.get_children()):
            values = self.tree.item(item)['values']
            slaves_set.add(int(values[1]))
            
            access = values[7]
            cloud = values[8] == 'Yes'
            
            # Read metadata from columns 18-22 if available (from imported JSON)
            # Otherwise, infer parameter_type based on access settings
            if len(values) >= 18 and values[17]:  # Column 18: parameter_type
                parameter_type = values[17]
            else:
                # Fallback inference for manually added registers
                if access in ['W', 'RW']:
                    parameter_type = 'write'
                else:
                    parameter_type = 'read_only'
            
            # Helper to convert empty string to None
            def get_optional_int(val):
                if val == '' or val is None:
                    return None
                try:
                    return int(val)
                except (ValueError, TypeError):
                    return None
            
            # Read cross-reference IDs from columns 19-20
            write_param_id = None
            feedback_param_id = None
            if len(values) >= 19:
                write_param_id = get_optional_int(values[18])  # Column 19
            if len(values) >= 20:
                feedback_param_id = get_optional_int(values[19])  # Column 20
            
            # Read MPI indices from columns 21-22
            p2_mpi_index = None
            p3_mpi_index = None
            if len(values) >= 21:
                p2_mpi_index = get_optional_int(values[20])  # Column 21
            if len(values) >= 22:
                p3_mpi_index = get_optional_int(values[21])  # Column 22
            
            # Read equipment hierarchy from columns 23-26
            equipment_group = ""
            device_name = ""
            equipment_type = ""
            jka_equipment_index = -1
            if len(values) >= 23:
                equipment_group = str(values[22]) if values[22] else ""
            if len(values) >= 24:
                device_name = str(values[23]) if values[23] else ""
            if len(values) >= 25:
                equipment_type = str(values[24]) if values[24] else ""
            if len(values) >= 26:
                jka_equipment_index = get_optional_int(values[25])
                if jka_equipment_index is None:
                    jka_equipment_index = -1
            
            reg = RegisterEntry(
                param_id=f"P{idx + 1}",
                slave_id=int(values[1]),
                fc=int(values[2]),
                address=int(values[3]),
                length=int(values[4]),
                fmt=int(values[5]),
                multiplier=float(values[6]),
                access=access,
                cloud=cloud,
                json_group=values[9],
                json_unit=values[10],
                json_key=values[11],
                array_membership=values[12] if len(values) > 12 else "",
                parameter_type=parameter_type,
                write_param_id=write_param_id,
                feedback_param_id=feedback_param_id,
                p2_mpi_index=p2_mpi_index,
                p3_mpi_index=p3_mpi_index,
                equipment_group=equipment_group,
                device_name=device_name,
                equipment_type=equipment_type,
                jka_equipment_index=jka_equipment_index
            )
            
            # Add legacy fields if available from tree view (for backward compatibility)
            if len(values) > 13:
                reg.b5_id = values[13]
            if len(values) > 14:
                reg.packet_num = values[14]
            if len(values) > 15:
                reg.packet_sa = values[15]
            if len(values) > 16:
                reg.packet_nrt = values[16]
            
            registers.append(reg)
        return registers, sorted(list(slaves_set))
    
    def generate_configs(self):
        try:
            registers, slaves = self.get_register_data()
            
            if not registers:
                messagebox.showerror("❌ Error", "Please add at least one register!")
                return
            
            # Validate
            validation = validate_registers(registers)
            if validation['status'] == 'error':
                messagebox.showerror("❌ Validation Error", validation['message'])
                return
            
            # Get data format
            parity_map = {"N (None)": "N", "E (Even)": "E", "O (Odd)": "O"}
            parity_value = self.parity_var.get()
            parity = parity_map.get(parity_value, parity_value[0] if parity_value else "E")
            data_format = f"{self.data_bits_var.get()}{parity}{self.stop_bits_var.get()}"
            
            # Communication settings
            communication = {
                'baudrate': int(self.baudrate_var.get()),
                'format': data_format
            }
            
            # Extract profile value from dropdown (format: "0 - Description")
            profile_text = self.profile_var.get()
            try:
                profile = int(profile_text.split(' - ')[0]) if ' - ' in profile_text else int(profile_text)
            except (ValueError, IndexError):
                profile = 0  # Default to Profile 0 if parsing fails
            
            # Generate packets
            packets = generate_packets(registers)

            # Generate JSONs (but validate first)
            tentative_modbus_io = generate_modbus_io_json(communication, slaves, packets, registers)
            tentative_param_cfg = generate_parameter_config_json(registers, profile)

            # Run internal validation and surface results via messageboxes
            v1 = validate_modbus_io(tentative_modbus_io, registers, packets, communication, slaves)
            v2 = validate_parameter_config(tentative_param_cfg, registers)

            all_errors = v1['errors'] + v2['errors']
            all_warnings = v1['warnings'] + v2['warnings']

            if all_errors:
                short = '\n'.join(all_errors[:20])
                more = len(all_errors) - 20
                if more > 0:
                    short += f"\n...and {more} more errors"
                full = '\n'.join(all_errors + ["\n"] + ["Warnings:"] + all_warnings)
                if messagebox.askyesno("Validation Failed", f"Validation found errors:\n\n{short}\n\nShow full details in a text file?"):
                    try:
                        path = os.path.join(os.getcwd(), f"validation_errors_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt")
                        with open(path, 'w', encoding='utf-8') as fh:
                            fh.write(full)
                        messagebox.showinfo("Saved", f"Full validation details saved to:\n{path}")
                    except Exception as e:
                        messagebox.showerror("Save Failed", f"Failed to save validation details: {e}")
                return

            if all_warnings:
                short_w = '\n'.join(all_warnings[:20])
                more_w = len(all_warnings) - 20
                if more_w > 0:
                    short_w += f"\n...and {more_w} more warnings"
                if not messagebox.askyesno("Validation Warnings", f"Validation completed with warnings:\n\n{short_w}\n\nProceed with generation?"):
                    return

            # Accept and set generated
            self.generated_modbus_io = tentative_modbus_io
            self.generated_parameter_config = tentative_param_cfg
            
            # Generate Output JSON template
            try:
                self.generated_output_json = generate_output_json(tentative_param_cfg, registers)
            except Exception as e:
                messagebox.showwarning("⚠️ Warning", f"Output JSON generation failed:\n{str(e)}\n\nContinuing with Modbus and ParamMap JSON only.")
                self.generated_output_json = None
            
            # Display in text widgets
            self.modbus_text.delete('1.0', tk.END)
            if FORMATTER_AVAILABLE:
                self.modbus_text.insert('1.0', format_bmiot_json(self.generated_modbus_io))
            else:
                self.modbus_text.insert('1.0', json.dumps(self.generated_modbus_io, indent=2))
            
            self.param_text.delete('1.0', tk.END)
            if FORMATTER_AVAILABLE:
                self.param_text.insert('1.0', format_bmiot_json(self.generated_parameter_config))
            else:
                self.param_text.insert('1.0', json.dumps(self.generated_parameter_config, indent=2))
            
            # Display Output JSON in third tab
            self.output_text.delete('1.0', tk.END)
            if self.generated_output_json:
                if FORMATTER_AVAILABLE:
                    self.output_text.insert('1.0', format_bmiot_json(self.generated_output_json))
                else:
                    self.output_text.insert('1.0', json.dumps(self.generated_output_json, indent=2))
            else:
                error_msg = '''// ⚠️ Output JSON Generation Failed
// 
// Possible reasons:
// 1. No cloud parameters configured (Cloud="Yes" required)
// 2. Missing JSON Group, Unit, or Key fields for cloud parameters
// 3. Invalid ParamMap JSON structure
// 
// To fix:
// - Add at least one register with Cloud="Yes"
// - Fill JSON Group, JSON Unit, and JSON Key fields
// - Regenerate configurations
//
// Output JSON requires cloud parameters to generate device groups.'''
                self.output_text.insert('1.0', error_msg)
            
            # Automatically switch to Output JSON tab to show result
            if self.generated_output_json:
                self.notebook.select(2)  # Switch to third tab (Output JSON)
            
            # Update status label
            if self.generated_output_json:
                self.json_status_label.config(text="✅ Modbus IO  ✅ ParamMap Config  ✅ Output JSON", foreground='green')
            else:
                self.json_status_label.config(text="✅ Modbus IO  ✅ ParamMap Config  ⚠️ Output JSON (failed)", foreground='orange')
            
            # Show success message with details
            success_msg = "Configuration files generated successfully!"
            if self.generated_output_json:
                success_msg += "\n\n✅ Modbus_IO.json\n✅ ParamMap_Config.json\n✅ Output.json template\n\nAll three JSONs are now displayed in their respective tabs."
            else:
                success_msg += "\n\n✅ Modbus_IO.json\n✅ ParamMap_Config.json\n⚠️  Output.json generation failed"
            
            messagebox.showinfo("✅ Success", success_msg)
            
        except Exception as e:
            messagebox.showerror("❌ Error", f"Error generating configurations:\n{str(e)}")

    # run_validation removed — validation now runs internally in generate_configs
    
    def save_modbus_io(self):
        if not self.generated_modbus_io:
            messagebox.showwarning("⚠️ Warning", "Please generate configurations first!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            initialfile="modbus_io.json"
        )
        
        if filename:
            if FORMATTER_AVAILABLE:
                format_and_save_json(self.generated_modbus_io, filename)
            else:
                with open(filename, 'w') as f:
                    json.dump(self.generated_modbus_io, f, indent=2)
            messagebox.showinfo("✅ Success", f"File saved:\n{filename}")

    def save_parameter_config(self):
        if not self.generated_parameter_config:
            messagebox.showwarning("⚠️ Warning", "Please generate configurations first!")
            return

        filename = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            initialfile="parameter_config.json"
        )

        if filename:
            if FORMATTER_AVAILABLE:
                format_and_save_json(self.generated_parameter_config, filename)
            else:
                with open(filename, 'w') as f:
                    json.dump(self.generated_parameter_config, f, indent=2)
            messagebox.showinfo("✅ Success", f"File saved:\n{filename}")

    def save_both_files(self):
        if not self.generated_modbus_io or not self.generated_parameter_config:
            messagebox.showwarning("⚠️ Warning", "Please generate configurations first!")
            return

        # Ask where to save modbus_io.json
        modbus_file = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            initialfile="modbus_io.json"
        )
        if not modbus_file:
            return

        # Ask where to save parameter_config.json
        param_file = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            initialfile="parameter_config.json"
        )
        if not param_file:
            return

        try:
            if FORMATTER_AVAILABLE:
                format_and_save_json(self.generated_modbus_io, modbus_file)
                format_and_save_json(self.generated_parameter_config, param_file)
            else:
                with open(modbus_file, 'w') as f:
                    json.dump(self.generated_modbus_io, f, indent=2)
                with open(param_file, 'w') as f:
                    json.dump(self.generated_parameter_config, f, indent=2)
            messagebox.showinfo("✅ Success", f"Files saved:\n{modbus_file}\n{param_file}")
        except Exception as e:
            messagebox.showerror("❌ Error", f"Failed to save files:\n{e}")
    
    def save_output_json(self):
        """Save Output JSON template"""
        if not self.generated_output_json:
            messagebox.showwarning("⚠️ Warning", "Output JSON not generated!\n\nPlease generate configurations first.")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            initialfile="output.json"
        )
        
        if filename:
            try:
                if FORMATTER_AVAILABLE:
                    format_and_save_json(self.generated_output_json, filename)
                else:
                    with open(filename, 'w') as f:
                        json.dump(self.generated_output_json, f, indent=2)
                messagebox.showinfo("✅ Success", f"Output JSON template saved:\n{filename}\n\nNote: This is a template with placeholder values.\nActual values come from runtime Modbus data.")
            except Exception as e:
                messagebox.showerror("❌ Error", f"Failed to save file:\n{e}")
    
    def save_all_files(self):
        """Save all three JSON files"""
        if not self.generated_modbus_io or not self.generated_parameter_config:
            messagebox.showwarning("⚠️ Warning", "Please generate configurations first!")
            return
        
        # Ask for directory
        directory = filedialog.askdirectory(title="Select folder to save all files")
        if not directory:
            return
        
        try:
            # Save Modbus_IO.json
            modbus_file = os.path.join(directory, "modbus_io.json")
            if FORMATTER_AVAILABLE:
                format_and_save_json(self.generated_modbus_io, modbus_file)
            else:
                with open(modbus_file, 'w') as f:
                    json.dump(self.generated_modbus_io, f, indent=2)
            
            # Save ParamMap_Config.json
            param_file = os.path.join(directory, "parameter_config.json")
            if FORMATTER_AVAILABLE:
                format_and_save_json(self.generated_parameter_config, param_file)
            else:
                with open(param_file, 'w') as f:
                    json.dump(self.generated_parameter_config, f, indent=2)
            
            success_msg = f"Files saved to:\n{directory}\n\n✅ modbus_io.json\n✅ parameter_config.json"
            
            # Save Output.json if available
            if self.generated_output_json:
                output_file = os.path.join(directory, "output.json")
                if FORMATTER_AVAILABLE:
                    format_and_save_json(self.generated_output_json, output_file)
                else:
                    with open(output_file, 'w') as f:
                        json.dump(self.generated_output_json, f, indent=2)
                success_msg += "\n✅ output.json (template)"
            
            messagebox.showinfo("✅ Success", success_msg)
        except Exception as e:
            messagebox.showerror("❌ Error", f"Failed to save files:\n{e}")
    
    def show_firmware_help(self):
        """Display BMIoT firmware architecture information"""
        help_window = tk.Toplevel(self.root)
        help_window.title("📘 BMIoT Gateway Firmware Architecture")
        help_window.geometry("900x700")
        help_window.configure(bg='white')
        
        # Create scrollable text widget
        text_frame = ttk.Frame(help_window)
        text_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        text_widget = tk.Text(text_frame, wrap='word', font=('Segoe UI', 10), padx=15, pady=15)
        scrollbar = ttk.Scrollbar(text_frame, command=text_widget.yview)
        text_widget.configure(yscrollcommand=scrollbar.set)
        
        scrollbar.pack(side='right', fill='y')
        text_widget.pack(side='left', fill='both', expand=True)
        
        # Firmware architecture content
        content = """
📘 BMIoT Gateway Firmware Architecture
═══════════════════════════════════════════════════════════════════════

🔄 M-Das OTA Configuration System
────────────────────────────────────────────────────────────────────────
M-Das (mDash) is the cloud-based device management platform for:
  • Over-the-air (OTA) firmware updates
  • Remote file management via RPC commands
  • Device shadow synchronization
  • Remote configuration updates

Configuration Update Workflow:
  1. Generate JSONs using this application
  2. Upload to device via M-Das dashboard using FS.Put RPC
  3. Files stored in device SPIFFS filesystem
  4. Reboot device to reload configurations
  5. Firmware loads and validates both JSON files


📦 Required JSON Files
────────────────────────────────────────────────────────────────────────
The firmware requires BOTH configuration files:

1️⃣ Modbus_Config.json (6 Mandatory Blocks)
   • B1: Overview - slave count, packet count, register count, parameter count
   • B2: Communication - baud rate (38400), data format ('8N1')
   • B3: Slave Configuration - slave IDs and start packet numbers
   • B4: Packet Configuration - start address, register count, function code, slave ID
   • B5: Parameter Configuration - ID, packet number, address, length, format, multiplier
   • B6: Write-Read Mapping - maps write parameters to verification read parameters

2️⃣ ParamMap_Config.json (7 Mandatory Sections)
   • P1: Buffer Sizes - NLB (Lua buffer), NLBIN (Lua input), NMD (output data buffer)
   • P2: Lua Buffer Mapping - MPI (Modbus params), RPCI (RPC commands)
   • P3: Output Buffer Mapping - MPI (Modbus cloud params), LBI (Lua variables)
   • JKY: JSON Key Arrays - equipment groups and keys for cloud payload structure
   • JKC: JSON Common Strings - header and equipment key strings
   • NTC: Network/Device Details - IP, client ID, device ID, slave names
   • MST: Profile Setup - profile flag

⚠️ ALL sections are mandatory! Firmware validation checks for all keys.


🔧 Firmware Data Flow
────────────────────────────────────────────────────────────────────────
Startup:
  1. SPIFFS_config.begin() → Mount SPIFFS filesystem
  2. MB_Config.load(Modbus_Config.json) → Load and validate B1-B6 blocks
  3. PMap_Config.load(ParamMap_Config.json) → Load and validate P1-P3, JKY, JKC, NTC, MST
  4. eModbusRTU_PacketInit() → Initialize packet structures from B4
  5. eModbusRTU_Construct() → Build Modbus polling packets using B4 data
  
Runtime Loop (every 10s):
  1. eModbusRTU_Loop() → Poll configured Modbus packets from slaves
  2. Map_MdataBuffSync() → Fill M_data output buffer using P3.MPI mapping
  3. Lua_IO_Sync() → Execute Lua scripts with P2.MPI data
  4. M_data buffer contains cloud parameters for publishing

Publishing (every 30-300s):
  1. Build JSON payload using JKY equipment structure
  2. Insert M_data values into JSON groups/keys
  3. Publish via MQTT or HTTPS to cloud platform
  4. Cloud dashboard displays equipment-organized data


📊 GUI Field Mapping to Firmware
────────────────────────────────────────────────────────────────────────
This Application          →  Firmware Block       →  Usage
═════════════════════════════════════════════════════════════════════════
Slave ID                  →  B3.SI, B4.SID        →  Modbus slave address
FC (Function Code)        →  B4.FC                →  Modbus function (3=read, 6=write)
Address                   →  B4.SA, B5.STA        →  Register start address
Length                    →  B5.LN                →  Register length (1-4)
FMT (Format)              →  B5.FMT               →  Data format (I16, U16, I32, F32)
Multiplier                →  B5.MLT               →  Scaling factor
Access                    →  B6.WP/RP mapping     →  R=read, W=write, RW=write+verify
Cloud Output              →  P3.MPI               →  Include in M_data buffer (REQUIRED)
JSON Group/Unit/Key       →  JKY.JKA              →  Cloud payload structure
Array Membership          →  P2.MPI, P3.MPI       →  Parameter grouping
B5 ID                     →  B5.ID                →  Parameter index in B5 block
Packet Num                →  B5.PN                →  Packet grouping for polling
Packet SA/NRT             →  B4.SA, B4.NRT        →  Packet metadata


✅ Best Practices
────────────────────────────────────────────────────────────────────────
1. Always mark at least one parameter for Cloud Output (P3.MPI required)
2. Fill JSON Group, Unit, and Key for all cloud parameters
3. Group related parameters in same equipment type for organized dashboard
4. Use descriptive JSON keys (e.g., "chiller_temp", "flow_rate")
5. Test with minimal configuration first (1 slave, 5 parameters)
6. Upload both JSONs and reboot device after configuration changes
7. Check device serial output for loading errors after reboot


📚 For More Information
────────────────────────────────────────────────────────────────────────
Firmware Source: Thermelgy-Gateway-BMIoT/lib/
  • MBConfig_Lib - Modbus configuration loader
  • ParamMapConfig_Lib - Parameter mapping loader
  • eModbusRTU_Lib - Modbus communication engine
  • LuaEngine_Lib - Lua script execution
  • Com_Lib - MQTT/HTTPS publishing

API Documentation: API Documentation/html/index.html
"""
        
        text_widget.insert('1.0', content)
        text_widget.configure(state='disabled')  # Make read-only
        
        # Add close button
        btn_frame = ttk.Frame(help_window)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Close", command=help_window.destroy, style='Action.TButton').pack()
    
    def show_column_help(self):
        """Display column descriptions"""
        help_window = tk.Toplevel(self.root)
        help_window.title("🔍 Column Descriptions")
        help_window.geometry("800x600")
        help_window.configure(bg='white')
        
        # Create scrollable text widget
        text_frame = ttk.Frame(help_window)
        text_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        text_widget = tk.Text(text_frame, wrap='word', font=('Courier New', 9), padx=15, pady=15)
        scrollbar = ttk.Scrollbar(text_frame, command=text_widget.yview)
        text_widget.configure(yscrollcommand=scrollbar.set)
        
        scrollbar.pack(side='right', fill='y')
        text_widget.pack(side='left', fill='both', expand=True)
        
        # Column descriptions
        content = """
🔍 Register Configuration Columns
══════════════════════════════════════════════════════════════════════════════

COLUMN              FIRMWARE MAPPING          DESCRIPTION
──────────────────────────────────────────────────────────────────────────────
S.No                Sequential index          Display-only serial number

Slave ID            B3.SI, B4.SID             Modbus slave device address (1-247)
                                              Maps to physical device on RTU bus

FC                  B4.FC                     Modbus function code:
                                              • 3 = Read Holding Registers
                                              • 6 = Write Single Register
                                              • 16 = Write Multiple Registers

Address             B4.SA, B5.STA             Modbus register start address (0-65535)
                                              Address of parameter in slave device

Length              B5.LN                     Number of Modbus registers (1-4):
                                              • 1 = 16-bit (I16, U16)
                                              • 2 = 32-bit (I32, U32, F32)
                                              • 4 = 64-bit (rarely used)

FMT                 B5.FMT                    Data format identifier (0-9):
                                              • 0 = I16 (signed 16-bit)
                                              • 1 = U16 (unsigned 16-bit)
                                              • 2 = I32 (signed 32-bit)
                                              • 3 = U32 (unsigned 32-bit)
                                              • 4 = F32 (32-bit float)

Multiplier          B5.MLT                    Scaling factor (0.01-1000.0)
                                              Final value = raw_value × multiplier

Access              B6.WP, B6.RP              Parameter access type:
                                              • R = Read Only (monitoring)
                                              • W = Write Only (setpoint, no verify)
                                              • RW = Read-Write (setpoint + verify)

Cloud Output        P3.MPI (REQUIRED!)        Include in MQTT/HTTPS output buffer?
                                              • Yes = Add to M_data[] array
                                              • No = Skip in cloud publishing
                                              ⚠️ At least one must be Yes!

JSON Group          JKY.JKA equipment type    Equipment category for cloud payload:
                                              e.g., "Chiller", "Pump", "VFD"
                                              Groups related parameters together

JSON Unit           JKY.JKA equipment name    Specific equipment unit identifier:
                                              e.g., "CH-1", "Pump-A", "VFD-01"
                                              Identifies individual device

JSON Key            JKY.JKA parameter key     Parameter name in cloud JSON:
                                              e.g., "temp", "flow_rate", "speed"
                                              Must be unique within equipment unit

Array Membership    P2.MPI, P3.MPI, etc.      Parameter grouping in ParamMap:
                                              • P2.MPI = Lua buffer (Modbus params)
                                              • P2.RPCI = RPC commands
                                              • P3.MPI = Cloud output (Modbus)
                                              • P3.LBI = Cloud output (Lua vars)

B5 ID               B5.ID (s_Indx)            Parameter index in firmware Block 5
                                              Unique identifier (1-300)

Packet Num          B5.PN (s_PckNo)           Modbus polling packet number (1-150)
                                              Groups parameters polled together
                                              Used by eModbusRTU_Construct()

Packet SA           B4.SA                     Packet start address
                                              First register address in packet

Packet NRT          B4.NRT (s_NosRgtrs)       Registers per packet
                                              Number of registers polled in packet


💡 USAGE TIPS
──────────────────────────────────────────────────────────────────────────────
1. Cloud Output = Yes → Required for firmware to publish data via MQTT/HTTPS
2. JSON Group/Unit/Key → Organize cloud dashboard by equipment type
3. Packet Num → Firmware groups registers into packets for efficient polling
4. B5 ID → Auto-assigned, uniquely identifies each parameter
5. Access = RW → Firmware writes value then reads back to verify success


⚠️ COMMON MISTAKES
──────────────────────────────────────────────────────────────────────────────
❌ No cloud parameters (all Cloud Output = No)
   → Firmware cannot publish to cloud, P3.MPI is empty

❌ Cloud Output = Yes but missing JSON Group/Unit/Key
   → Firmware fails to build output JSON payload

❌ Duplicate B5 IDs
   → Firmware mapping conflicts

❌ Wrong packet grouping (parameters from different slaves in same packet)
   → Modbus communication fails

"""
        
        text_widget.insert('1.0', content)
        text_widget.configure(state='disabled')  # Make read-only
        
        # Add close button
        btn_frame = ttk.Frame(help_window)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Close", command=help_window.destroy, style='Action.TButton').pack()
    
    def show_about(self):
        """Display about information"""
        about_text = """
🔧 Modbus Configuration Generator Pro
Version 6.6 - BMIoT Gateway Edition

Firmware-Aligned Configuration Tool for Thermelgy BMIoT Gateway

Features:
• Bidirectional JSON transformation (Register ↔ Modbus+ParamMap)
• Firmware-validated configuration generation
• M-Das OTA compatible JSON output
• 17-field register management with packet grouping
• Cloud output parameter mapping (P3.MPI)
• Equipment-based JSON structure (JKY)

Generated Files:
• Modbus_Config.json (B1-B6 blocks)
• ParamMap_Config.json (P1-P3, JKY, JKC, NTC, MST)
• Output_JSON.json (cloud payload template)

Firmware Requirements:
• ESP32-based Thermelgy BMIoT Gateway
• M-Das cloud connectivity
• eModbusRTU, MBConfig_Lib, ParamMapConfig_Lib

For help, click Help → BMIoT Firmware Architecture
"""
        messagebox.showinfo("About", about_text)

class RegisterDialog:
    def __init__(self, parent, app):
        self.app = app
        self.dialog = tk.Toplevel(parent)
        self.dialog.title("➕ Add New Register")
        self.dialog.geometry("550x700")
        self.dialog.transient(parent)
        self.dialog.grab_set()
        self.dialog.configure(bg='#f5f7fa')
        
        # Title
        title_frame = tk.Frame(self.dialog, bg='#3498db', height=60)
        title_frame.pack(fill='x')
        tk.Label(title_frame, text="📝 Register Information", 
                font=('Segoe UI', 14, 'bold'), fg='white', bg='#3498db').pack(pady=15)
        
        # Create form
        frame = ttk.Frame(self.dialog, padding=30)
        frame.pack(fill='both', expand=True)
        
        row = 0
        
        # Slave ID
        ttk.Label(frame, text="Slave ID:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.slave_id_var = tk.IntVar(value=1)
        ttk.Spinbox(frame, from_=1, to=247, textvariable=self.slave_id_var, width=30, font=('Segoe UI', 10)).grid(row=row, column=1, pady=10, sticky='ew')
        row += 1
        
        # Function Code
        ttk.Label(frame, text="Function Code:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.fc_var = tk.StringVar(value="3")
        self.fc_combo = ttk.Combobox(frame, textvariable=self.fc_var, 
                               values=bc.DROPDOWN_OPTIONS['function_code'], 
                               width=28, state='readonly', font=('Segoe UI', 10))
        self.fc_combo.grid(row=row, column=1, pady=10, sticky='ew')
        self.fc_combo.set(bc.DROPDOWN_OPTIONS['function_code'][2])  # Default: "3 - Read Holding Registers"
        row += 1
        
        # Address
        ttk.Label(frame, text="Address:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.address_var = tk.IntVar(value=0)
        ttk.Spinbox(frame, from_=0, to=65535, textvariable=self.address_var, width=30, font=('Segoe UI', 10)).grid(row=row, column=1, pady=10, sticky='ew')
        row += 1
        
        # Length (auto-calculated, read-only)
        ttk.Label(frame, text="Length:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.length_var = tk.IntVar(value=1)
        self.length_entry = ttk.Entry(frame, textvariable=self.length_var, width=30, font=('Segoe UI', 10), state='readonly')
        self.length_entry.grid(row=row, column=1, pady=10, sticky='ew')
        ttk.Label(frame, text="🔒 Auto-calculated from Format", 
                 font=('Segoe UI', 8), foreground='#7f8c8d').grid(row=row, column=2, padx=5, sticky='w')
        row += 1
        
        # Format
        ttk.Label(frame, text="Format (FMT):", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.fmt_var = tk.StringVar(value="3")
        self.fmt_combo = ttk.Combobox(frame, textvariable=self.fmt_var, 
                                values=bc.DROPDOWN_OPTIONS['data_format_code'], 
                                width=28, state='readonly', font=('Segoe UI', 10))
        self.fmt_combo.grid(row=row, column=1, pady=10, sticky='ew')
        self.fmt_combo.set(bc.DROPDOWN_OPTIONS['data_format_code'][2])  # Default: "3 - Unsigned 16-bit"
        self.fmt_combo.bind("<<ComboboxSelected>>", lambda e: self.update_length_from_format())
        row += 1
        
        # Multiplier
        ttk.Label(frame, text="Multiplier:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.multiplier_var = tk.DoubleVar(value=1.0)
        ttk.Entry(frame, textvariable=self.multiplier_var, width=30, font=('Segoe UI', 10)).grid(row=row, column=1, pady=10, sticky='ew')
        row += 1
        
        # Access
        ttk.Label(frame, text="Access:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.access_var = tk.StringVar(value="R")
        self.access_combo = ttk.Combobox(frame, textvariable=self.access_var, 
                                   values=bc.DROPDOWN_OPTIONS['access_type'], 
                                   width=28, state='readonly', font=('Segoe UI', 10))
        self.access_combo.grid(row=row, column=1, pady=10, sticky='ew')
        self.access_combo.set(bc.DROPDOWN_OPTIONS['access_type'][0])  # Default: "R - Read Only"
        row += 1
        
        # Cloud Output
        ttk.Label(frame, text="Cloud Output:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.cloud_var = tk.StringVar(value="Yes")
        cloud_combo = ttk.Combobox(frame, textvariable=self.cloud_var, 
                                  values=["Yes", "No"], 
                                  width=28, state='readonly', font=('Segoe UI', 10))
        cloud_combo.grid(row=row, column=1, pady=10, sticky='ew')
        row += 1
        
        # JSON Group
        ttk.Label(frame, text="JSON Group:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.json_group_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.json_group_var, width=30, font=('Segoe UI', 10)).grid(row=row, column=1, pady=10, sticky='ew')
        row += 1
        
        # JSON Unit
        ttk.Label(frame, text="JSON Unit:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.json_unit_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.json_unit_var, width=30, font=('Segoe UI', 10)).grid(row=row, column=1, pady=10, sticky='ew')
        row += 1
        
        # JSON Key
        ttk.Label(frame, text="JSON Key:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.json_key_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.json_key_var, width=30, font=('Segoe UI', 10)).grid(row=row, column=1, pady=10, sticky='ew')
        ttk.Label(frame, text="💡 Tip: Use commas for multiple keys (e.g., Key1,Key2,Key3)", 
                 font=('Segoe UI', 8), foreground='#7f8c8d').grid(row=row+1, column=0, columnspan=2, pady=2)
        row += 2
        
        frame.columnconfigure(1, weight=1)
        
        # Initialize length from default format
        self.update_length_from_format()
        
        # Buttons
        btn_frame = tk.Frame(self.dialog, bg='#f5f7fa')
        btn_frame.pack(fill='x', padx=30, pady=20)
        
        add_btn = tk.Button(btn_frame, text="✅ Add Register", command=self.add_register,
                           font=('Segoe UI', 11, 'bold'), bg='#2ecc71', fg='white',
                           relief='flat', padx=20, pady=10, cursor='hand2')
        add_btn.pack(side='left', padx=5)
        
        cancel_btn = tk.Button(btn_frame, text="❌ Cancel", command=self.dialog.destroy,
                              font=('Segoe UI', 11), bg='#95a5a6', fg='white',
                              relief='flat', padx=20, pady=10, cursor='hand2')
        cancel_btn.pack(side='left', padx=5)
    
    def update_length_from_format(self):
        """Auto-calculate length based on selected format"""
        try:
            fmt_text = self.fmt_var.get()
            if fmt_text and ' - ' in fmt_text:
                fmt_code = int(fmt_text.split(' - ')[0])
                length = bc.get_register_length(fmt_code)
                self.length_var.set(length)
        except Exception:
            # If parsing fails, default to 1
            self.length_var.set(1)
    
    def add_register(self):
        """Add register with comprehensive validation"""
        try:
            # Extract numeric values from combo selections with error handling
            fc_text = self.fc_var.get()
            if not fc_text or fc_text.strip() == "":
                messagebox.showerror("❌ Validation Error", "Function Code is required!\nPlease select a function code from the dropdown.")
                return
            
            fmt_text = self.fmt_var.get()
            if not fmt_text or fmt_text.strip() == "":
                messagebox.showerror("❌ Validation Error", "Format is required!\nPlease select a data format from the dropdown.")
                return
            
            access_text = self.access_var.get()
            if not access_text or access_text.strip() == "":
                messagebox.showerror("❌ Validation Error", "Access type is required!\nPlease select an access type from the dropdown.")
                return
            
            # Parse dropdown values with error handling
            try:
                fc = bc.parse_dropdown_selection(fc_text, 'function_code')
                if not isinstance(fc, int):
                    fc = int(fc)
            except (ValueError, TypeError, AttributeError) as e:
                messagebox.showerror("❌ Parsing Error", 
                                   f"Invalid Function Code format!\nSelected: '{fc_text}'\nError: {str(e)}")
                return
            
            try:
                fmt = bc.parse_dropdown_selection(fmt_text, 'data_format_code')
                if not isinstance(fmt, int):
                    fmt = int(fmt)
            except (ValueError, TypeError, AttributeError) as e:
                messagebox.showerror("❌ Parsing Error", 
                                   f"Invalid Format Code format!\nSelected: '{fmt_text}'\nError: {str(e)}")
                return
            
            try:
                access = bc.parse_dropdown_selection(access_text, 'access_type')
                if not isinstance(access, str):
                    access = str(access)
            except (ValueError, TypeError, AttributeError) as e:
                messagebox.showerror("❌ Parsing Error", 
                                   f"Invalid Access Type format!\nSelected: '{access_text}'\nError: {str(e)}")
                return
            
            # Get and validate numeric values
            try:
                slave_id = int(self.slave_id_var.get())
            except (ValueError, TypeError):
                messagebox.showerror("❌ Validation Error", 
                                   f"Slave ID must be a number!\nGot: '{self.slave_id_var.get()}'")
                return
            
            try:
                address = int(self.address_var.get())
            except (ValueError, TypeError):
                messagebox.showerror("❌ Validation Error", 
                                   f"Address must be a number!\nGot: '{self.address_var.get()}'")
                return
            
            try:
                length = int(self.length_var.get())
            except (ValueError, TypeError):
                messagebox.showerror("❌ Validation Error", 
                                   f"Length must be a number!\nGot: '{self.length_var.get()}'")
                return
            
            try:
                multiplier = float(self.multiplier_var.get())
            except (ValueError, TypeError):
                messagebox.showerror("❌ Validation Error", 
                                   f"Multiplier must be a number!\nGot: '{self.multiplier_var.get()}'")
                return
            
            # VALIDATION: Slave ID
            is_valid, error_msg = bc.validate_slave_id(slave_id)
            if not is_valid:
                messagebox.showerror("❌ Validation Error", f"Slave ID Error:\n{error_msg}\n\nValid range: 1-247")
                return
            
            # VALIDATION: Address
            is_valid, error_msg = bc.validate_address(address)
            if not is_valid:
                messagebox.showerror("❌ Validation Error", f"Address Error:\n{error_msg}\n\nValid range: 0-65535")
                return
            
            # VALIDATION: Function Code
            is_valid, error_msg = bc.validate_function_code(fc)
            if not is_valid:
                messagebox.showerror("❌ Validation Error", f"Function Code Error:\n{error_msg}\n\nValid codes: 1,2,3,4,5,6,15,16")
                return
            
            # VALIDATION: Format Code
            is_valid, error_msg = bc.validate_format_code(fmt)
            if not is_valid:
                messagebox.showerror("❌ Validation Error", f"Format Code Error:\n{error_msg}\n\nValid codes: 1-8")
                return
            
            # VALIDATION: Length must match format
            expected_length = bc.get_register_length(fmt)
            if length != expected_length:
                messagebox.showerror("❌ Validation Error", 
                                   f"Length Mismatch:\n\nFormat {fmt} requires length {expected_length}, but got {length}.\n\nLength is auto-calculated from Format.\nPlease reselect the format to update length.")
                return
            
            # VALIDATION: Length limit
            if length > 70:
                messagebox.showerror("❌ Validation Error", 
                                   f"Length Too Large:\n\nLength {length} exceeds firmware limit of 70 registers.\n\nPlease use a different data format.")
                return
            
            # VALIDATION: Function Code vs Access Type Logic
            # READ FCs (1,2,3,4) should only work with 'R' or 'RW'
            # WRITE FCs (5,6,15,16) should only work with 'W' or 'RW'
            read_fcs = [1, 2, 3, 4]
            write_fcs = [5, 6, 15, 16]
            
            if fc in read_fcs:
                if 'R' not in access:
                    messagebox.showerror("❌ Logic Error", 
                                       f"Function Code Mismatch:\n\n"
                                       f"FC {fc} is a READ function code.\n"
                                       f"Access type must be 'R' or 'RW' (not '{access}').\n\n"
                                       f"READ FCs (1,2,3,4) → Access must contain 'R'\n"
                                       f"WRITE FCs (5,6,15,16) → Access must contain 'W'")
                    return
            elif fc in write_fcs:
                if 'W' not in access:
                    messagebox.showerror("❌ Logic Error", 
                                       f"Function Code Mismatch:\n\n"
                                       f"FC {fc} is a WRITE function code.\n"
                                       f"Access type must be 'W' or 'RW' (not '{access}').\n\n"
                                       f"READ FCs (1,2,3,4) → Access must contain 'R'\n"
                                       f"WRITE FCs (5,6,15,16) → Access must contain 'W'")
                    return
            
            # VALIDATION: Check for duplicate/overlapping registers
            # Check if a register with same Slave ID and overlapping address range already exists
            for item in self.app.tree.get_children():
                values = self.app.tree.item(item)['values']
                existing_serial = values[0]
                existing_slave = int(values[1])
                existing_fc = int(values[2])
                existing_addr = int(values[3])
                existing_len = int(values[4])
                existing_access = values[7]
                
                # Check if same slave ID
                if existing_slave == slave_id:
                    # Calculate address ranges
                    existing_end_addr = existing_addr + existing_len - 1
                    new_end_addr = address + length - 1
                    
                    # Check for overlapping address ranges
                    overlap = not (new_end_addr < existing_addr or address > existing_end_addr)
                    
                    if overlap:
                        # Determine if it's read or write operation
                        operation_type = "READ" if fc in read_fcs else "WRITE"
                        existing_operation = "READ" if existing_fc in read_fcs else "WRITE"
                        
                        # Build detailed warning message
                        overlap_msg = (
                            f"⚠️ Duplicate/Overlapping Register Detected!\n\n"
                            f"You are trying to {operation_type}:\n"
                            f"  • Slave ID: {slave_id}\n"
                            f"  • FC: {fc}\n"
                            f"  • Address: {address}-{new_end_addr}\n"
                            f"  • Access: {access}\n\n"
                            f"But Serial No. {existing_serial} already {existing_operation}s:\n"
                            f"  • Slave ID: {existing_slave}\n"
                            f"  • FC: {existing_fc}\n"
                            f"  • Address: {existing_addr}-{existing_end_addr}\n"
                            f"  • Access: {existing_access}\n\n"
                            f"This creates an overlapping register configuration.\n\n"
                            f"Do you want to add it anyway?"
                        )
                        
                        result = messagebox.askyesno("⚠️ Duplicate Register Warning", overlap_msg)
                        if not result:
                            return
                        # If user clicked Yes, continue to add the register
                        break
            
            # VALIDATION: Cloud output restrictions based on access type
            cloud_enabled = self.cloud_var.get() == "Yes"
            
            # CRITICAL: Only R (Read Only) parameters can have Cloud=Yes
            # W and RW parameters are commands/control, not monitoring telemetry
            # Based on historical Excel mapping analysis and firmware behavior
            if cloud_enabled and access in ['W', 'RW']:
                messagebox.showerror("❌ Invalid Cloud Configuration",
                                   f"Cannot enable Cloud output for Access Type '{access}'.\n\n"
                                   f"📋 Cloud Output Rules:\n"
                                   f"  ✅ R (Read Only): Monitoring/telemetry → Cloud allowed\n"
                                   f"  ❌ W (Write Only): Commands → Cloud NOT allowed\n"
                                   f"  ❌ RW (Read/Write): Write + verification → Cloud NOT allowed\n\n"
                                   f"💡 Reason:\n"
                                   f"  • W/RW parameters are control commands, not status values\n"
                                   f"  • RW read component is only for write verification\n"
                                   f"  • Only independent monitoring values go to cloud\n\n"
                                   f"Please change Access to 'R' or set Cloud to 'No'.")
                return
            
            # VALIDATION: JSON fields for cloud parameters
            json_group = self.json_group_var.get().strip()
            json_unit = self.json_unit_var.get().strip()
            json_key = self.json_key_var.get().strip()
            
            if cloud_enabled:
                warnings = []
                if not json_group:
                    warnings.append("• JSON Group is empty")
                if not json_unit:
                    warnings.append("• JSON Unit is empty")
                if not json_key:
                    warnings.append("• JSON Key is empty")
                
                if warnings:
                    warning_msg = "\n".join(warnings)
                    result = messagebox.askyesno("⚠️ Cloud Parameter Warning", 
                                               f"Cloud output enabled but:\n\n{warning_msg}\n\nThis parameter will not be published to cloud.\n\nDo you want to continue adding this register anyway?")
                    if not result:
                        return
            
            # TEST: Create a RegisterEntry to ensure it works
            try:
                test_register = RegisterEntry(
                    param_id="TEST",
                    slave_id=slave_id,
                    fc=fc,
                    address=address,
                    length=length,
                    fmt=fmt,
                    multiplier=multiplier,
                    access=access,
                    cloud=cloud_enabled,
                    json_group=json_group,
                    json_unit=json_unit,
                    json_key=json_key
                )
            except Exception as e:
                messagebox.showerror("❌ Register Creation Error", 
                                   f"Failed to create register with provided data:\n\n{str(e)}\n\nPlease check all fields and try again.")
                return
            
            # All validations passed - Add to tree
            children_count = len(self.app.tree.get_children())
            tag = 'evenrow' if children_count % 2 == 0 else 'oddrow'
            
            self.app.tree.insert('', 'end', values=(
                children_count + 1,
                slave_id,
                fc,
                address,
                length,
                fmt,
                multiplier,
                access,
                self.cloud_var.get(),
                json_group,
                json_unit,
                json_key,
                '',  # array_membership - will be populated during reverse transform
                children_count + 1,  # b5_id - default to serial number
                0,  # packet_num - will be calculated
                address,  # packet_sa - default to address
                length,  # packet_nrt - default to length
                # Metadata columns (18-26) - defaults for manually added registers
                'write' if access in ['W', 'RW'] else 'read_only',  # parameter_type
                '',  # write_param_id - empty for now
                '',  # feedback_param_id - empty for now
                '',  # p2_mpi_index - will be calculated
                '',  # p3_mpi_index - will be calculated
                '',  # equipment_group - empty for manually added
                '',  # device_name - empty for manually added
                '',  # equipment_type - empty for manually added
                -1   # jka_equipment_index - not in JKA
            ), tags=(tag,))
            
            self.app.update_status()
            self.dialog.destroy()
            messagebox.showinfo("✅ Success", f"Register added successfully!\n\nParameter ID: {children_count + 1}\nSlave: {slave_id}, FC: {fc}, Address: {address}")
            
        except Exception as e:
            import traceback
            error_details = traceback.format_exc()
            messagebox.showerror("❌ Unexpected Error", 
                               f"An unexpected error occurred:\n\n{str(e)}\n\nPlease report this error with the following details:\n\n{error_details[:200]}...")

class EditRegisterDialog:
    def __init__(self, parent, app, tree_item, values):
        self.app = app
        self.tree_item = tree_item
        self.dialog = tk.Toplevel(parent)
        self.dialog.title("✏️ Edit Register")
        self.dialog.geometry("550x700")
        self.dialog.transient(parent)
        self.dialog.grab_set()
        self.dialog.configure(bg='#f5f7fa')
        
        # Title
        title_frame = tk.Frame(self.dialog, bg='#3498db', height=60)
        title_frame.pack(fill='x')
        tk.Label(title_frame, text="✏️ Edit Register Information", 
                font=('Segoe UI', 14, 'bold'), fg='white', bg='#3498db').pack(pady=15)
        
        # Create form with pre-filled values
        frame = ttk.Frame(self.dialog, padding=30)
        frame.pack(fill='both', expand=True)
        
        row = 0
        
        # Slave ID
        ttk.Label(frame, text="Slave ID:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.slave_id_var = tk.IntVar(value=values[1])
        ttk.Spinbox(frame, from_=1, to=247, textvariable=self.slave_id_var, width=30, font=('Segoe UI', 10)).grid(row=row, column=1, pady=10, sticky='ew')
        row += 1
        
        # Function Code
        ttk.Label(frame, text="Function Code:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.fc_var = tk.StringVar()
        self.fc_combo = ttk.Combobox(frame, textvariable=self.fc_var, 
                               values=bc.DROPDOWN_OPTIONS['function_code'], 
                               width=28, state='readonly', font=('Segoe UI', 10))
        self.fc_combo.grid(row=row, column=1, pady=10, sticky='ew')
        # Find matching dropdown option
        fc_val = values[2]
        for opt in bc.DROPDOWN_OPTIONS['function_code']:
            if opt.startswith(f"{fc_val} -"):
                self.fc_combo.set(opt)
                break
        row += 1
        
        # Address
        ttk.Label(frame, text="Address:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.address_var = tk.IntVar(value=values[3])
        ttk.Spinbox(frame, from_=0, to=65535, textvariable=self.address_var, width=30, font=('Segoe UI', 10)).grid(row=row, column=1, pady=10, sticky='ew')
        row += 1
        
        # Length (auto-calculated, read-only)
        ttk.Label(frame, text="Length:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.length_var = tk.IntVar(value=values[4])
        self.length_entry = ttk.Entry(frame, textvariable=self.length_var, width=30, font=('Segoe UI', 10), state='readonly')
        self.length_entry.grid(row=row, column=1, pady=10, sticky='ew')
        ttk.Label(frame, text="🔒 Auto-calculated from Format", 
                 font=('Segoe UI', 8), foreground='#7f8c8d').grid(row=row, column=2, padx=5, sticky='w')
        row += 1
        
        # Format
        ttk.Label(frame, text="Format (FMT):", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.fmt_var = tk.StringVar()
        self.fmt_combo = ttk.Combobox(frame, textvariable=self.fmt_var, 
                                values=bc.DROPDOWN_OPTIONS['data_format_code'], 
                                width=28, state='readonly', font=('Segoe UI', 10))
        self.fmt_combo.grid(row=row, column=1, pady=10, sticky='ew')
        # Find matching dropdown option
        fmt_val = values[5]
        for opt in bc.DROPDOWN_OPTIONS['data_format_code']:
            if opt.startswith(f"{fmt_val} -"):
                self.fmt_combo.set(opt)
                break
        self.fmt_combo.bind("<<ComboboxSelected>>", lambda e: self.update_length_from_format())
        row += 1
        
        # Multiplier
        ttk.Label(frame, text="Multiplier:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.multiplier_var = tk.DoubleVar(value=values[6])
        ttk.Entry(frame, textvariable=self.multiplier_var, width=30, font=('Segoe UI', 10)).grid(row=row, column=1, pady=10, sticky='ew')
        row += 1
        
        # Access
        ttk.Label(frame, text="Access:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.access_var = tk.StringVar()
        self.access_combo = ttk.Combobox(frame, textvariable=self.access_var, 
                                   values=bc.DROPDOWN_OPTIONS['access_type'], 
                                   width=28, state='readonly', font=('Segoe UI', 10))
        self.access_combo.grid(row=row, column=1, pady=10, sticky='ew')
        # Find matching dropdown option
        access_val = values[7]
        for opt in bc.DROPDOWN_OPTIONS['access_type']:
            if opt.startswith(f"{access_val} -"):
                self.access_combo.set(opt)
                break
        row += 1
        
        # Cloud Output
        ttk.Label(frame, text="Cloud Output:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.cloud_var = tk.StringVar(value=values[8])
        cloud_combo = ttk.Combobox(frame, textvariable=self.cloud_var, 
                                  values=["Yes", "No"], 
                                  width=28, state='readonly', font=('Segoe UI', 10))
        cloud_combo.grid(row=row, column=1, pady=10, sticky='ew')
        row += 1
        
        # JSON Group
        ttk.Label(frame, text="JSON Group:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.json_group_var = tk.StringVar(value=values[9])
        ttk.Entry(frame, textvariable=self.json_group_var, width=30, font=('Segoe UI', 10)).grid(row=row, column=1, pady=10, sticky='ew')
        row += 1
        
        # JSON Unit
        ttk.Label(frame, text="JSON Unit:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.json_unit_var = tk.StringVar(value=values[10])
        ttk.Entry(frame, textvariable=self.json_unit_var, width=30, font=('Segoe UI', 10)).grid(row=row, column=1, pady=10, sticky='ew')
        row += 1
        
        # JSON Key
        ttk.Label(frame, text="JSON Key:", font=('Segoe UI', 10, 'bold')).grid(row=row, column=0, sticky='w', pady=10)
        self.json_key_var = tk.StringVar(value=values[11])
        ttk.Entry(frame, textvariable=self.json_key_var, width=30, font=('Segoe UI', 10)).grid(row=row, column=1, pady=10, sticky='ew')
        ttk.Label(frame, text="💡 Tip: Use commas for multiple keys (e.g., Key1,Key2,Key3)", 
                 font=('Segoe UI', 8), foreground='#7f8c8d').grid(row=row+1, column=0, columnspan=2, pady=2)
        row += 2
        
        frame.columnconfigure(1, weight=1)
        
        # Buttons
        btn_frame = tk.Frame(self.dialog, bg='#f5f7fa')
        btn_frame.pack(fill='x', padx=30, pady=20)
        
        save_btn = tk.Button(btn_frame, text="💾 Save Changes", command=self.save_changes,
                           font=('Segoe UI', 11, 'bold'), bg='#3498db', fg='white',
                           relief='flat', padx=20, pady=10, cursor='hand2')
        save_btn.pack(side='left', padx=5)
        
        cancel_btn = tk.Button(btn_frame, text="❌ Cancel", command=self.dialog.destroy,
                              font=('Segoe UI', 11), bg='#95a5a6', fg='white',
                              relief='flat', padx=20, pady=10, cursor='hand2')
        cancel_btn.pack(side='left', padx=5)
    
    def update_length_from_format(self):
        """Auto-calculate length based on selected format"""
        try:
            fmt_text = self.fmt_var.get()
            if fmt_text and ' - ' in fmt_text:
                fmt_code = int(fmt_text.split(' - ')[0])
                length = bc.get_register_length(fmt_code)
                self.length_var.set(length)
        except Exception:
            # If parsing fails, keep current value
            pass
    
    def save_changes(self):
        """Save changes with comprehensive validation"""
        try:
            # Extract numeric values from combo selections with error handling
            fc_text = self.fc_var.get()
            if not fc_text or fc_text.strip() == "":
                messagebox.showerror("❌ Validation Error", "Function Code is required!\nPlease select a function code from the dropdown.")
                return
            
            fmt_text = self.fmt_var.get()
            if not fmt_text or fmt_text.strip() == "":
                messagebox.showerror("❌ Validation Error", "Format is required!\nPlease select a data format from the dropdown.")
                return
            
            access_text = self.access_var.get()
            if not access_text or access_text.strip() == "":
                messagebox.showerror("❌ Validation Error", "Access type is required!\nPlease select an access type from the dropdown.")
                return
            
            # Parse dropdown values with error handling
            try:
                fc = bc.parse_dropdown_selection(fc_text, 'function_code')
                if not isinstance(fc, int):
                    fc = int(fc)
            except (ValueError, TypeError, AttributeError) as e:
                messagebox.showerror("❌ Parsing Error", 
                                   f"Invalid Function Code format!\nSelected: '{fc_text}'\nError: {str(e)}")
                return
            
            try:
                fmt = bc.parse_dropdown_selection(fmt_text, 'data_format_code')
                if not isinstance(fmt, int):
                    fmt = int(fmt)
            except (ValueError, TypeError, AttributeError) as e:
                messagebox.showerror("❌ Parsing Error", 
                                   f"Invalid Format Code format!\nSelected: '{fmt_text}'\nError: {str(e)}")
                return
            
            try:
                access = bc.parse_dropdown_selection(access_text, 'access_type')
                if not isinstance(access, str):
                    access = str(access)
            except (ValueError, TypeError, AttributeError) as e:
                messagebox.showerror("❌ Parsing Error", 
                                   f"Invalid Access Type format!\nSelected: '{access_text}'\nError: {str(e)}")
                return
            
            # Get and validate numeric values
            try:
                slave_id = int(self.slave_id_var.get())
            except (ValueError, TypeError):
                messagebox.showerror("❌ Validation Error", 
                                   f"Slave ID must be a number!\nGot: '{self.slave_id_var.get()}'")
                return
            
            try:
                address = int(self.address_var.get())
            except (ValueError, TypeError):
                messagebox.showerror("❌ Validation Error", 
                                   f"Address must be a number!\nGot: '{self.address_var.get()}'")
                return
            
            try:
                length = int(self.length_var.get())
            except (ValueError, TypeError):
                messagebox.showerror("❌ Validation Error", 
                                   f"Length must be a number!\nGot: '{self.length_var.get()}'")
                return
            
            try:
                multiplier = float(self.multiplier_var.get())
            except (ValueError, TypeError):
                messagebox.showerror("❌ Validation Error", 
                                   f"Multiplier must be a number!\nGot: '{self.multiplier_var.get()}'")
                return
            
            # VALIDATION: Slave ID
            is_valid, error_msg = bc.validate_slave_id(slave_id)
            if not is_valid:
                messagebox.showerror("❌ Validation Error", f"Slave ID Error:\n{error_msg}\n\nValid range: 1-247")
                return
            
            # VALIDATION: Address
            is_valid, error_msg = bc.validate_address(address)
            if not is_valid:
                messagebox.showerror("❌ Validation Error", f"Address Error:\n{error_msg}\n\nValid range: 0-65535")
                return
            
            # VALIDATION: Function Code
            is_valid, error_msg = bc.validate_function_code(fc)
            if not is_valid:
                messagebox.showerror("❌ Validation Error", f"Function Code Error:\n{error_msg}\n\nValid codes: 1,2,3,4,5,6,15,16")
                return
            
            # VALIDATION: Format Code
            is_valid, error_msg = bc.validate_format_code(fmt)
            if not is_valid:
                messagebox.showerror("❌ Validation Error", f"Format Code Error:\n{error_msg}\n\nValid codes: 1-8")
                return
            
            # VALIDATION: Length must match format
            expected_length = bc.get_register_length(fmt)
            if length != expected_length:
                messagebox.showerror("❌ Validation Error", 
                                   f"Length Mismatch:\n\nFormat {fmt} requires length {expected_length}, but got {length}.\n\nLength is auto-calculated from Format.\nPlease reselect the format to update length.")
                return
            
            # VALIDATION: Length limit
            if length > 70:
                messagebox.showerror("❌ Validation Error", 
                                   f"Length Too Large:\n\nLength {length} exceeds firmware limit of 70 registers.\n\nPlease use a different data format.")
                return
            
            # VALIDATION: Function Code vs Access Type Logic
            # READ FCs (1,2,3,4) should only work with 'R' or 'RW'
            # WRITE FCs (5,6,15,16) should only work with 'W' or 'RW'
            read_fcs = [1, 2, 3, 4]
            write_fcs = [5, 6, 15, 16]
            
            if fc in read_fcs:
                if 'R' not in access:
                    messagebox.showerror("❌ Logic Error", 
                                       f"Function Code Mismatch:\n\n"
                                       f"FC {fc} is a READ function code.\n"
                                       f"Access type must be 'R' or 'RW' (not '{access}').\n\n"
                                       f"READ FCs (1,2,3,4) → Access must contain 'R'\n"
                                       f"WRITE FCs (5,6,15,16) → Access must contain 'W'")
                    return
            elif fc in write_fcs:
                if 'W' not in access:
                    messagebox.showerror("❌ Logic Error", 
                                       f"Function Code Mismatch:\n\n"
                                       f"FC {fc} is a WRITE function code.\n"
                                       f"Access type must be 'W' or 'RW' (not '{access}').\n\n"
                                       f"READ FCs (1,2,3,4) → Access must contain 'R'\n"
                                       f"WRITE FCs (5,6,15,16) → Access must contain 'W'")
                    return
            
            # VALIDATION: Check for duplicate/overlapping registers (excluding current item being edited)
            # Get current serial number
            old_values = self.app.tree.item(self.tree_item)['values']
            current_serial = old_values[0]
            
            for item in self.app.tree.get_children():
                values = self.app.tree.item(item)['values']
                existing_serial = values[0]
                
                # Skip checking against itself
                if existing_serial == current_serial:
                    continue
                
                existing_slave = int(values[1])
                existing_fc = int(values[2])
                existing_addr = int(values[3])
                existing_len = int(values[4])
                existing_access = values[7]
                
                # Check if same slave ID
                if existing_slave == slave_id:
                    # Calculate address ranges
                    existing_end_addr = existing_addr + existing_len - 1
                    new_end_addr = address + length - 1
                    
                    # Check for overlapping address ranges
                    overlap = not (new_end_addr < existing_addr or address > existing_end_addr)
                    
                    if overlap:
                        # Determine if it's read or write operation
                        operation_type = "READ" if fc in read_fcs else "WRITE"
                        existing_operation = "READ" if existing_fc in read_fcs else "WRITE"
                        
                        # Build detailed warning message
                        overlap_msg = (
                            f"⚠️ Duplicate/Overlapping Register Detected!\n\n"
                            f"You are trying to {operation_type}:\n"
                            f"  • Slave ID: {slave_id}\n"
                            f"  • FC: {fc}\n"
                            f"  • Address: {address}-{new_end_addr}\n"
                            f"  • Access: {access}\n\n"
                            f"But Serial No. {existing_serial} already {existing_operation}s:\n"
                            f"  • Slave ID: {existing_slave}\n"
                            f"  • FC: {existing_fc}\n"
                            f"  • Address: {existing_addr}-{existing_end_addr}\n"
                            f"  • Access: {existing_access}\n\n"
                            f"This creates an overlapping register configuration.\n\n"
                            f"Do you want to update it anyway?"
                        )
                        
                        result = messagebox.askyesno("⚠️ Duplicate Register Warning", overlap_msg)
                        if not result:
                            return
                        # If user clicked Yes, continue to update the register
                        break
            
            # VALIDATION: Cloud output restrictions based on access type
            cloud_enabled = self.cloud_var.get() == "Yes"
            
            # CRITICAL: Only R (Read Only) parameters can have Cloud=Yes
            # W and RW parameters are commands/control, not monitoring telemetry
            if cloud_enabled and access in ['W', 'RW']:
                messagebox.showerror("❌ Invalid Cloud Configuration",
                                   f"Cannot enable Cloud output for Access Type '{access}'.\n\n"
                                   f"📋 Cloud Output Rules:\n"
                                   f"  ✅ R (Read Only): Monitoring/telemetry → Cloud allowed\n"
                                   f"  ❌ W (Write Only): Commands → Cloud NOT allowed\n"
                                   f"  ❌ RW (Read/Write): Write + verification → Cloud NOT allowed\n\n"
                                   f"💡 Reason:\n"
                                   f"  • W/RW parameters are control commands, not status values\n"
                                   f"  • RW read component is only for write verification\n"
                                   f"  • Only independent monitoring values go to cloud\n\n"
                                   f"Please change Access to 'R' or set Cloud to 'No'.")
                return
            
            # VALIDATION: JSON fields for cloud parameters
            json_group = self.json_group_var.get().strip()
            json_unit = self.json_unit_var.get().strip()
            json_key = self.json_key_var.get().strip()
            
            if cloud_enabled:
                warnings = []
                if not json_group:
                    warnings.append("• JSON Group is empty")
                if not json_unit:
                    warnings.append("• JSON Unit is empty")
                if not json_key:
                    warnings.append("• JSON Key is empty")
                
                if warnings:
                    warning_msg = "\n".join(warnings)
                    result = messagebox.askyesno("⚠️ Cloud Parameter Warning", 
                                               f"Cloud output enabled but:\n\n{warning_msg}\n\nThis parameter will not be published to cloud.\n\nDo you want to continue updating this register anyway?")
                    if not result:
                        return
            
            # TEST: Create a RegisterEntry to ensure it works
            try:
                test_register = RegisterEntry(
                    param_id="TEST",
                    slave_id=slave_id,
                    fc=fc,
                    address=address,
                    length=length,
                    fmt=fmt,
                    multiplier=multiplier,
                    access=access,
                    cloud=cloud_enabled,
                    json_group=json_group,
                    json_unit=json_unit,
                    json_key=json_key
                )
            except Exception as e:
                messagebox.showerror("❌ Register Creation Error", 
                                   f"Failed to create register with provided data:\n\n{str(e)}\n\nPlease check all fields and try again.")
                return
            
            # Get current serial number
            old_values = self.app.tree.item(self.tree_item)['values']
            serial_no = old_values[0]
            
            # All validations passed - Update the tree item
            self.app.tree.item(self.tree_item, values=(
                serial_no,
                slave_id,
                fc,
                address,
                length,
                fmt,
                multiplier,
                access,
                self.cloud_var.get(),
                json_group,
                json_unit,
                json_key,
                self.values[12] if len(self.values) > 12 else '',  # array_membership
                self.values[13] if len(self.values) > 13 else serial_no,  # b5_id
                self.values[14] if len(self.values) > 14 else 0,  # packet_num
                self.values[15] if len(self.values) > 15 else address,  # packet_sa
                self.values[16] if len(self.values) > 16 else length,  # packet_nrt
                # Preserve metadata columns (18-26) if they exist, otherwise use defaults
                self.values[17] if len(self.values) > 17 else ('write' if access in ['W', 'RW'] else 'read_only'),  # parameter_type
                self.values[18] if len(self.values) > 18 else '',  # write_param_id
                self.values[19] if len(self.values) > 19 else '',  # feedback_param_id
                self.values[20] if len(self.values) > 20 else '',  # p2_mpi_index
                self.values[21] if len(self.values) > 21 else '',  # p3_mpi_index
                self.values[22] if len(self.values) > 22 else '',  # equipment_group
                self.values[23] if len(self.values) > 23 else '',  # device_name
                self.values[24] if len(self.values) > 24 else '',  # equipment_type
                self.values[25] if len(self.values) > 25 else -1   # jka_equipment_index
            ))
            
            self.dialog.destroy()
            messagebox.showinfo("✅ Success", f"Register updated successfully!\n\nParameter ID: {serial_no}\nSlave: {slave_id}, FC: {fc}, Address: {address}")
            
        except Exception as e:
            import traceback
            error_details = traceback.format_exc()
            messagebox.showerror("❌ Unexpected Error", 
                               f"An unexpected error occurred:\n\n{str(e)}\n\nPlease report this error with the following details:\n\n{error_details[:200]}...")

# Entry point
    def _auto_assign_packets(self):
        """Auto-assign packet numbers and b5_ids to all registers"""
        try:
            # Get current registers from tree
            registers = []
            for item in self.tree.get_children():
                values = self.tree.item(item)['values']
                if len(values) >= 9:
                    reg = {
                        'slave_id': int(values[1]) if values[1] else 0,
                        'fc': int(values[2]) if values[2] else 0,
                        'address': int(values[3]) if values[3] else 0,
                        'length': int(values[4]) if values[4] else 1,
                        'fmt': int(values[5]) if values[5] else 3,
                        'multiplier': float(values[6]) if values[6] else 1.0,
                        'access': str(values[7]) if values[7] else 'R',
                        'cloud': str(values[8]) if values[8] else 'No',
                        'json_group': str(values[9]) if len(values) > 9 else '',
                        'json_unit': str(values[10]) if len(values) > 10 else '',
                        'json_key': str(values[11]) if len(values) > 11 else ''
                    }
                    registers.append(reg)
            
            if not registers:
                messagebox.showwarning("Warning", "No registers to assign packets to")
                return
            
            # Auto-assign packet numbers
            registers = auto_assign_packet_numbers(registers)
            
            # Auto-generate b5_ids
            registers = auto_generate_b5_ids(registers)
            
            # Update tree
            self.tree.delete(*self.tree.get_children())
            for idx, reg in enumerate(registers):
                tag = 'evenrow' if idx % 2 == 0 else 'oddrow'
                self.tree.insert("", "end", values=(
                    idx + 1,  # S.No
                    reg.get('slave_id', ''),
                    reg.get('fc', ''),
                    reg.get('address', ''),
                    reg.get('length', ''),
                    reg.get('fmt', ''),
                    reg.get('multiplier', ''),
                    reg.get('access', ''),
                    reg.get('cloud', ''),
                    reg.get('json_group', ''),
                    reg.get('json_unit', ''),
                    reg.get('json_key', ''),
                    reg.get('array_membership', ''),
                    reg.get('b5_id', idx + 1),
                    reg.get('packet_num', 0),
                    reg.get('packet_sa', reg.get('address', 0)),
                    reg.get('packet_nrt', reg.get('length', 1))
                ), tags=(tag,))
            
            # Validate
            is_valid, msg, stats = validate_packet_assignments(registers)
            
            if is_valid:
                info_msg = f"✓ Auto-assignment complete!\n\n"
                info_msg += f"Total Registers: {stats['total_registers']}\n"
                info_msg += f"Total Packets: {stats['total_packets']}\n"
                info_msg += f"B5 ID Range: {stats['b5_id_range']}\n"
                info_msg += f"Packet Range: {stats['packet_range']}"
                messagebox.showinfo("Success", info_msg)
            else:
                messagebox.showerror("Validation Error", msg)
                
        except Exception as e:
            messagebox.showerror("Error", f"Auto-assignment failed: {str(e)}")
    
    def _validate_assignments(self):
        """Validate current packet and b5_id assignments"""
        try:
            # Get current registers from tree
            registers = []
            for item in self.tree.get_children():
                values = self.tree.item(item)['values']
                if len(values) >= 2:
                    reg = {
                        'b5_id': int(values[0]) if values[0] else None,
                        'packet_num': int(values[1]) if values[1] else None
                    }
                    registers.append(reg)
            
            if not registers:
                messagebox.showwarning("Warning", "No registers to validate")
                return
            
            is_valid, msg, stats = validate_packet_assignments(registers)
            
            if is_valid:
                info_msg = f"✓ Validation passed!\n\n"
                info_msg += f"Total Registers: {stats['total_registers']}\n"
                info_msg += f"Total Packets: {stats['total_packets']}\n"
                info_msg += f"B5 ID Range: {stats['b5_id_range']}\n"
                info_msg += f"Packet Range: {stats['packet_range']}"
                messagebox.showinfo("Validation Success", info_msg)
            else:
                messagebox.showerror("Validation Error", msg)
                
        except Exception as e:
            messagebox.showerror("Error", f"Validation failed: {str(e)}")


if __name__ == "__main__":
    root = tk.Tk()
    app = ModbusConfigGenerator(root)
    root.mainloop()
