"""
Quick Verification - Test Before Sending
Verifies the application can run in different modes
"""

import os
import sys

print("=" * 80)
print("  BMIoT Configuration Generator - Deployment Verification")
print("=" * 80)
print()

# Test 1: Check main file exists
print("Test 1: Check main application file...")
if os.path.exists("modbus_tkinter_app_v6.6_complete.py"):
    size_kb = os.path.getsize("modbus_tkinter_app_v6.6_complete.py") / 1024
    print(f"  ✅ Found: modbus_tkinter_app_v6.6_complete.py ({size_kb:.1f} KB)")
else:
    print("  ❌ ERROR: Main file not found!")
    sys.exit(1)

# Test 2: Check optional engine files
print("\nTest 2: Check optional engine files...")
optional_files = {
    "reverse_engine.py": "Import feature",
    "forward_engine.py": "Export feature", 
    "transform_wrapper.py": "Coordinator",
    "bmiot_constants.py": "Enhanced validation"
}

engines_available = True
for filename, purpose in optional_files.items():
    if os.path.exists(filename):
        size_kb = os.path.getsize(filename) / 1024
        print(f"  ✅ {filename:30s} ({size_kb:5.1f} KB) - {purpose}")
    else:
        print(f"  ⚠️  {filename:30s} (MISSING) - {purpose}")
        engines_available = False

# Test 3: Check documentation
print("\nTest 3: Check documentation files...")
doc_files = ["README.md", "DEPLOYMENT_GUIDE.md", "READY_TO_SHARE.md"]
for filename in doc_files:
    if os.path.exists(filename):
        size_kb = os.path.getsize(filename) / 1024
        print(f"  ✅ {filename:30s} ({size_kb:5.1f} KB)")
    else:
        print(f"  ⚠️  {filename:30s} (MISSING)")

# Test 4: Test imports
print("\nTest 4: Test critical imports...")
try:
    print("  Testing: json module... ", end="")
    import json
    print("✅")
except ImportError as e:
    print(f"❌ {e}")

try:
    print("  Testing: tkinter module... ", end="")
    import tkinter
    print("✅")
except ImportError as e:
    print(f"❌ {e}")
    print("     WARNING: tkinter not available. Application won't run!")

# Summary
print()
print("=" * 80)
print("  DEPLOYMENT READINESS SUMMARY")
print("=" * 80)
print()

if engines_available:
    print("📦 Package Type: FULL PACKAGE")
    print("   All features available (100% functionality)")
    print()
    print("   Files to zip (6 files):")
    print("     - modbus_tkinter_app_v6.6_complete.py")
    print("     - reverse_engine.py")
    print("     - forward_engine.py")
    print("     - transform_wrapper.py")
    print("     - bmiot_constants.py")
    print("     - README.md")
    print()
    print("   Zip name: BMIoT_Config_Generator_v6.6_Full.zip")
else:
    print("📦 Package Type: STANDALONE")
    print("   Basic features available (~70% functionality)")
    print()
    print("   File to send:")
    print("     - modbus_tkinter_app_v6.6_complete.py")
    print()
    print("   Filename: BMIoT_Config_Generator_v6.6_Standalone.py")
    print()
    print("   Note: Warnings are normal. App still works!")

print()
print("✅ Ready to deploy!")
print()
print("=" * 80)
