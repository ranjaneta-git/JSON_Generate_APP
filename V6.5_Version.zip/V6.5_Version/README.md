﻿# Modbus Configuration Generator v6.6

**Production-Ready Bidirectional JSON Transformation Tool**

## Quick Start

```bash
python modbus_config_generator.py
```

## Features

✅ Import Modbus+Paramap JSON files  
✅ Manual register entry with validation  
✅ Generate JSON files (both directions)  
✅ Packet# grouping for Modbus optimization  
✅ Perfect round-trip metadata preservation  
✅ CSV export capability  

## Required Files

All files must be in same directory:
- `modbus_config_generator.py` - Main application
- `reverse_engine.py` - JSON → Registers transformation
- `forward_engine.py` - Registers → JSON transformation  
- `bmiot_constants.py` - Validation constants

## Key Fields

| Field | Description | Valid Values |
|-------|-------------|--------------|
| **Packet#** | Groups registers polled together | 1-999 |
| **Slave ID** | Modbus device address | 1-247 |
| **FC** | Function code | 3, 6, 16 |
| **Address** | Register address | 0-65535 |
| **Length** | Register count | 1, 2 |
| **FMT** | Data format | 1-8 |
| **Access** | Read/Write type | R, W, RW |
| **Cloud** | Telemetry enabled | Yes, No |

## Workflow

1. **Import**: Load existing JSON files → Table populated
2. **Edit**: Modify registers in table
3. **Generate**: Export to new JSON files

**Perfect Round-Trip**: Import → Edit → Generate preserves all metadata

## Version

- **Version**: 6.6 Production
- **Date**: February 4, 2026
- **Status**: Fully Tested & Validated

For detailed documentation, see `Help → User Guide` in the application.
