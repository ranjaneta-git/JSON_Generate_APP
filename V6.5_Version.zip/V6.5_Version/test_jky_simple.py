"""Simple test to isolate JKY extraction"""
import json
from pathlib import Path

# Load production ParamMap JSON
production_path = Path(r"c:\Users\DELL\Documents\GitHub\Thermelgy-Gway-BMIoT\Thermelgy-Gateway-BMIoT\data")
with open(production_path / "ParamMap_Config.json", "r") as f:
    paramap_json = json.load(f)

# Simulate _extract_jky_mappings
b5_to_json_keys = {}
jky = paramap_json.get("JKY", {})

print(f"JKY keys present: {list(jky.keys())}")
print(f"'JK' in jky: {'JK' in jky}")
print(f"'JKA' in jky: {'JKA' in jky}")

if "JK" in jky:
    print("\nProcessing JK format...")
    for entry in jky.get("JK", []):
        if isinstance(entry, dict) and "B5_id" in entry:
            b5_id = entry["B5_id"]
            b5_to_json_keys[b5_id] = {
                "json_group": entry.get("json_group", ""),
                "json_unit": entry.get("json_unit", ""),
                "json_key": entry.get("json_key", "")
            }
elif "JKA" in jky:
    print("\nProcessing JKA format...")
    for entry in jky.get("JKA", []):
        if isinstance(entry, list) and len(entry) >= 3:
            b5_id = entry[0]
            json_unit = entry[1][0] if isinstance(entry[1], list) and len(entry[1]) > 0 else ""
            json_key = entry[2][0] if isinstance(entry[2], list) and len(entry[2]) > 0 else ""
            
            b5_to_json_keys[b5_id] = {
                "json_group": "",
                "json_unit": json_unit,
                "json_key": json_key
            }
            if len(b5_to_json_keys) <= 3:
                print(f"  Added: {b5_id} -> unit={json_unit}, key={json_key}")

print(f"\nTotal entries extracted: {len(b5_to_json_keys)}")
