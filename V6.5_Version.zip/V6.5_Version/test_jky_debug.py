"""Debug JKY extraction"""
import json
from pathlib import Path

# Load production ParamMap JSON
production_path = Path(r"c:\Users\DELL\Documents\GitHub\Thermelgy-Gway-BMIoT\Thermelgy-Gateway-BMIoT\data")
with open(production_path / "ParamMap_Config.json", "r") as f:
    paramap_json = json.load(f)

jky = paramap_json.get("JKY", {})
print(f"JKY keys: {jky.keys()}")

if "JKA" in jky:
    jka_entries = jky["JKA"]
    print(f"\nJKA has {len(jka_entries)} entries")
    print(f"First 3 entries:")
    for i, entry in enumerate(jka_entries[:3]):
        print(f"  {i}: {entry}")
        if isinstance(entry, list) and len(entry) >= 3:
            param_id = entry[0]
            json_unit = entry[1][0] if isinstance(entry[1], list) and len(entry[1]) > 0 else ""
            json_key = entry[2][0] if isinstance(entry[2], list) and len(entry[2]) > 0 else ""
            print(f"     -> param_id={param_id}, unit={json_unit}, key={json_key}")
