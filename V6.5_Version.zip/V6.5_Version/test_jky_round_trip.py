"""Debug round-trip JKY handling"""
import json
from pathlib import Path
from reverse_engine import ReverseTransformationEngine
from forward_engine import ForwardTransformationEngine

# Load production configs
production_path = Path(r"c:\Users\DELL\Documents\GitHub\Thermelgy-Gway-BMIoT\Thermelgy-Gateway-BMIoT\data")
with open(production_path / "Modbus_Config.json", "r") as f:
    modbus_json = json.load(f)
with open(production_path / "ParamMap_Config.json", "r") as f:
    paramap_json = json.load(f)

print("=" * 70)
print("STEP 1: Reverse Transform")
print("=" * 70)

# Reverse transform
reverse_engine = ReverseTransformationEngine()
registers_json = reverse_engine.transform(modbus_json, paramap_json)
registers = registers_json["registers"]

# Count cloud params
cloud_params = [r for r in registers if r["cloud"] == "Yes"]
print(f"Total registers: {len(registers)}")
print(f"Cloud params: {len(cloud_params)}")

# Check first few cloud params
print(f"\nFirst 3 cloud params:")
for i, reg in enumerate(cloud_params[:3]):
    print(f"  {i}: {reg['param_id']}")
    print(f"     cloud={reg['cloud']}, json_unit='{reg['json_unit']}', json_key='{reg['json_key']}'")

# Check if any cloud params have empty json fields
empty_json_params = [r for r in cloud_params if not r["json_unit"] or not r["json_key"]]
print(f"\nCloud params with empty json fields: {len(empty_json_params)}")

print("\n" + "=" * 70)
print("STEP 2: Forward Transform")
print("=" * 70)

# Forward transform
forward_engine = ForwardTransformationEngine()
forward_engine._load_registers(registers)
forward_engine._classify_registers()

print(f"Cloud params in forward engine: {len(forward_engine.cloud_params)}")

# Build JKY
jky_output = forward_engine._build_jky()
print(f"JKA entries built: {len(jky_output.get('JKA', []))}")

if len(jky_output.get('JKA', [])) > 0:
    print(f"\nFirst 3 JKA entries:")
    for i, entry in enumerate(jky_output["JKA"][:3]):
        print(f"  {i}: {entry}")
