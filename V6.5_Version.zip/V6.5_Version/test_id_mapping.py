"""Check B5 ID vs JKA param_id mapping"""
import json
from pathlib import Path

production_path = Path(r"c:\Users\DELL\Documents\GitHub\Thermelgy-Gway-BMIoT\Thermelgy-Gateway-BMIoT\data")
with open(production_path / "Modbus_Config.json", "r") as f:
    modbus_json = json.load(f)
with open(production_path / "ParamMap_Config.json", "r") as f:
    paramap_json = json.load(f)

b5 = modbus_json["B5"]
jka = paramap_json["JKY"]["JKA"]

print(f"B5.ID count: {len(b5['ID'])}")
print(f"B5.ID first 5: {b5['ID'][:5]}")
print(f"B5.ID types: {[type(x).__name__ for x in b5['ID'][:5]]}")

print(f"\nJKA count: {len(jka)}")
print(f"JKA first 5 param_ids: {[entry[0] for entry in jka[:5]]}")
print(f"JKA param_id types: {[type(entry[0]).__name__ for entry in jka[:5]]}")

# Check P2 and P3
p2 = paramap_json["P2"]
p3 = paramap_json["P3"]
print(f"\nP2.MPI length: {len(p2['MPI'])}")
print(f"P2.MPI first 10: {p2['MPI'][:10]}")
print(f"\nP3.MPI length: {len(p3['MPI'])}")
print(f"P3.MPI first 10: {p3['MPI'][:10]}")

print(f"\nTotal MPI entries (P2 + P3): {len(p2['MPI']) + len(p3['MPI'])}")
print(f"JKA entries: {len(jka)}")
print(f"Should match? {len(p2['MPI']) + len(p3['MPI']) == len(jka) or len(p2['MPI']) == len(jka)}")

# The MPI values are likely indices into B5.ID
# Let me check if P2.MPI[i] gives us the B5.ID index for cloud param i
print(f"\nChecking MPI mapping:")
for i, mpi_idx in enumerate(p2['MPI'][:5]):
    b5_id = b5['ID'][mpi_idx - 1]  # MPI is 1-based
    jka_param = jka[i][0] if i < len(jka) else "N/A"
    print(f"  JKA[{i}] = {jka_param}, P2.MPI[{i}] = {mpi_idx}, B5.ID[{mpi_idx-1}] = {b5_id}")
