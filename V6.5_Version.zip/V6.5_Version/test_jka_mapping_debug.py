"""Debug the missing 8 JKA entries"""
import json
from pathlib import Path

production_path = Path(r"c:\Users\DELL\Documents\GitHub\Thermelgy-Gway-BMIoT\Thermelgy-Gateway-BMIoT\data")
with open(production_path / "ParamMap_Config.json", "r") as f:
    paramap_json = json.load(f)

p2_mpi = paramap_json["P2"]["MPI"]
p2_lbi = paramap_json["P2"]["LBI"]
jka = paramap_json["JKY"]["JKA"]

print(f"P2.MPI: {len(p2_mpi)} entries")
print(f"P2.LBI: {len(p2_lbi)} entries")
print(f"JKA: {len(jka)} entries")
print(f"\nJKA breakdown:")
print(f"  First {len(p2_mpi)} -> P2.MPI")
print(f"  Remaining {len(jka) - len(p2_mpi)} -> P2.LBI")
print(f"\nP2.LBI available: {len(p2_lbi)}")

# Calculate how many we can map
remaining_jka = len(jka) - len(p2_mpi)
print(f"\nNeed to map {remaining_jka} JKA entries from index {len(p2_mpi)} to {len(jka)-1}")
print(f"P2.LBI indices we'll use: 0 to {remaining_jka-1}")
print(f"P2.LBI has {len(p2_lbi)} entries, so {'ENOUGH' if len(p2_lbi) >= remaining_jka else 'NOT ENOUGH'}")

# Check if the issue is index bounds
if len(p2_lbi) >= remaining_jka:
    print(f"\nP2.LBI should cover all {remaining_jka} remaining JKA entries")
    print(f"Last JKA index: {len(p2_mpi) + remaining_jka - 1}")
    print(f"Last P2.LBI index needed: {remaining_jka - 1}")
    print(f"P2.LBI[{remaining_jka-1}] = {p2_lbi[remaining_jka-1]}")
else:
    print(f"\nP2.LBI only has {len(p2_lbi)} entries, SHORT by {remaining_jka - len(p2_lbi)}")
