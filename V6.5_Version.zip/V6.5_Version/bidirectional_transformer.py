"""
Bidirectional Modbus Configuration Transformer
===============================================

A unified application supporting both forward and reverse JSON transformations:

FORWARD FLOW:
  Register Entry JSON → Modbus JSON + Paramap JSON

REVERSE FLOW:
  Modbus JSON + Paramap JSON → Register Entry JSON

This ensures complete round-trip compatibility and maintains firmware logic integrity.

Author: Firmware-aware Application Developer
Version: 1.0
Date: February 4, 2026
"""

import json
import sys
import os
from typing import Dict, List, Optional
from datetime import datetime


class BidirectionalTransformer:
    """
    Main application class for bidirectional JSON transformation.
    Supports both forward and reverse transformation flows.
    """
    
    def __init__(self):
        self.validation_errors = []
        self.warnings = []
    
    def forward_transform(self, register_config_path: str, 
                          output_modbus_path: str, 
                          output_paramap_path: str,
                          baudrate: int = 38400,
                          data_format: str = "8N1",
                          profile: int = 0) -> Dict:
        """
        Forward transformation: Register Entry JSON → Modbus + Paramap JSON
        
        Args:
            register_config_path: Path to input Register_Config.json
            output_modbus_path: Path to output Modbus_Config.json
            output_paramap_path: Path to output ParamMap_Config.json
            baudrate: Modbus baudrate (default: 38400)
            data_format: Data format string (default: "8N1")
            profile: Profile type 0, 1, or 2 (default: 0)
        
        Returns:
            Dictionary with status and file paths
        """
        print("\n" + "="*70)
        print("FORWARD TRANSFORMATION: Register → Modbus + Paramap")
        print("="*70)
        
        try:
            # Load register config
            print(f"\n📂 Loading: {register_config_path}")
            with open(register_config_path, 'r') as f:
                register_config = json.load(f)
            
            registers = register_config.get('registers', [])
            print(f"   - Loaded {len(registers)} registers")
            
            # Import forward transformation logic
            from forward_engine import ForwardTransformationEngine, auto_assign_packet_numbers, auto_assign_b5_ids
            
            # Auto-assign packet numbers and b5_ids if missing
            if registers and 'packet_num' not in registers[0]:
                print("\n🔄 Auto-assigning packet numbers...")
                registers = auto_assign_packet_numbers(registers)
            
            if registers and 'b5_id' not in registers[0]:
                print("🔄 Auto-assigning B5 IDs...")
                registers = auto_assign_b5_ids(registers)
            
            # Create metadata for B2 and MST
            metadata_cache = {
                'B2': {'BR': baudrate, 'DF': data_format},
                'MST': {'PRF': profile}
            }
            
            # Perform forward transformation
            print("\n🔄 Starting forward transformation...")
            engine = ForwardTransformationEngine(metadata_cache)
            
            modbus_json = engine.generate_modbus_json(registers)
            print(f"   ✓ Generated Modbus JSON ({len(modbus_json['B4']['SA'])} packets)")
            
            paramap_json = engine.generate_paramap_json(registers)
            print(f"   ✓ Generated Paramap JSON ({len(paramap_json['P3']['MPI'])} params)")
            
            # Save output files
            print(f"\n💾 Saving: {output_modbus_path}")
            with open(output_modbus_path, 'w') as f:
                json.dump(modbus_json, f, indent=2)
            
            print(f"💾 Saving: {output_paramap_path}")
            with open(output_paramap_path, 'w') as f:
                json.dump(paramap_json, f, indent=2)
            
            print("\n" + "="*70)
            print("✅ FORWARD TRANSFORMATION COMPLETE")
            print("="*70)
            print(f"📊 Statistics:")
            print(f"   - Input registers: {len(registers)}")
            print(f"   - Generated packets: {len(modbus_json['B4']['SA'])}")
            print(f"   - Output files:")
            print(f"     • {output_modbus_path}")
            print(f"     • {output_paramap_path}")
            
            result = {
                "status": "success",
                "message": "Forward transformation completed",
                "modbus_path": output_modbus_path,
                "paramap_path": output_paramap_path
            }
            
            return result
            
        except FileNotFoundError as e:
            print(f"❌ Error: File not found - {e}")
            return {"status": "error", "message": str(e)}
        except json.JSONDecodeError as e:
            print(f"❌ Error: Invalid JSON - {e}")
            return {"status": "error", "message": str(e)}
        except Exception as e:
            print(f"❌ Error: {e}")
            return {"status": "error", "message": str(e)}
    
    def reverse_transform(self, modbus_config_path: str, 
                          paramap_config_path: str,
                          output_register_path: str) -> Dict:
        """
        Reverse transformation: Modbus + Paramap JSON → Register Entry JSON
        
        Args:
            modbus_config_path: Path to input Modbus_Config.json
            paramap_config_path: Path to input ParamMap_Config.json
            output_register_path: Path to output Register_Config.json
        
        Returns:
            Dictionary with status and file path
        """
        print("\n" + "="*70)
        print("REVERSE TRANSFORMATION: Modbus + Paramap → Register")
        print("="*70)
        
        try:
            # Import reverse engine
            from reverse_engine import ReverseTransformationEngine
            
            # Load input files
            print(f"\n📂 Loading: {modbus_config_path}")
            with open(modbus_config_path, 'r') as f:
                modbus_json = json.load(f)
            
            print(f"📂 Loading: {paramap_config_path}")
            with open(paramap_config_path, 'r') as f:
                paramap_json = json.load(f)
            
            # Perform reverse transformation
            print("\n🔄 Starting reverse transformation...")
            engine = ReverseTransformationEngine()
            result = engine.transform(modbus_json, paramap_json)
            
            # Save output
            print(f"\n💾 Saving: {output_register_path}")
            with open(output_register_path, 'w') as f:
                json.dump(result, f, indent=2)
            
            print("\n" + "="*70)
            print("✅ REVERSE TRANSFORMATION COMPLETE")
            print("="*70)
            print(f"📊 Statistics:")
            print(f"   - Total registers reconstructed: {len(result['registers'])}")
            print(f"   - Output file: {output_register_path}")
            
            return {
                "status": "success",
                "message": "Reverse transformation completed",
                "register_path": output_register_path,
                "register_count": len(result['registers'])
            }
            
        except FileNotFoundError as e:
            print(f"\n❌ Error: File not found - {e}")
            return {"status": "error", "message": str(e)}
        except json.JSONDecodeError as e:
            print(f"\n❌ Error: Invalid JSON - {e}")
            return {"status": "error", "message": str(e)}
        except Exception as e:
            print(f"\n❌ Error: {e}")
            import traceback
            traceback.print_exc()
            return {"status": "error", "message": str(e)}
    
    def validate_roundtrip(self, original_register_path: str,
                           temp_dir: str = "./temp") -> Dict:
        """
        Validate round-trip transformation:
        Original Register → Modbus + Paramap → Reconstructed Register
        
        Args:
            original_register_path: Path to original Register_Config.json
            temp_dir: Temporary directory for intermediate files
        
        Returns:
            Dictionary with validation results
        """
        print("\n" + "="*70)
        print("ROUND-TRIP VALIDATION")
        print("="*70)
        
        # Create temp directory if needed
        os.makedirs(temp_dir, exist_ok=True)
        
        # Define intermediate file paths
        modbus_path = os.path.join(temp_dir, "temp_modbus.json")
        paramap_path = os.path.join(temp_dir, "temp_paramap.json")
        reconstructed_path = os.path.join(temp_dir, "temp_reconstructed.json")
        
        try:
            # Step 1: Forward transformation
            print("\n🔄 Step 1: Forward transformation...")
            forward_result = self.forward_transform(
                original_register_path,
                modbus_path,
                paramap_path
            )
            
            if forward_result["status"] != "success":
                return {
                    "status": "error",
                    "message": "Forward transformation failed",
                    "details": forward_result
                }
            
            # Step 2: Reverse transformation
            print("\n🔄 Step 2: Reverse transformation...")
            reverse_result = self.reverse_transform(
                modbus_path,
                paramap_path,
                reconstructed_path
            )
            
            if reverse_result["status"] != "success":
                return {
                    "status": "error",
                    "message": "Reverse transformation failed",
                    "details": reverse_result
                }
            
            # Step 3: Compare original vs reconstructed
            print("\n🔍 Step 3: Comparing original vs reconstructed...")
            comparison = self._compare_register_configs(
                original_register_path,
                reconstructed_path
            )
            
            if comparison["identical"]:
                print("\n✅ ROUND-TRIP VALIDATION PASSED")
                print("   Original and reconstructed configurations are identical")
            else:
                print("\n⚠️  ROUND-TRIP VALIDATION: Differences detected")
                print(f"   Differences: {comparison['difference_count']}")
            
            return {
                "status": "success",
                "identical": comparison["identical"],
                "comparison": comparison,
                "forward_result": forward_result,
                "reverse_result": reverse_result
            }
            
        except Exception as e:
            print(f"\n❌ Round-trip validation error: {e}")
            import traceback
            traceback.print_exc()
            return {"status": "error", "message": str(e)}
    
    def _compare_register_configs(self, path1: str, path2: str) -> Dict:
        """Compare two register configuration files"""
        with open(path1, 'r') as f:
            config1 = json.load(f)
        
        with open(path2, 'r') as f:
            config2 = json.load(f)
        
        registers1 = config1.get("registers", [])
        registers2 = config2.get("registers", [])
        
        if len(registers1) != len(registers2):
            return {
                "identical": False,
                "difference_count": abs(len(registers1) - len(registers2)),
                "message": f"Different register counts: {len(registers1)} vs {len(registers2)}"
            }
        
        # Compare each register
        differences = []
        for i, (r1, r2) in enumerate(zip(registers1, registers2)):
            for key in r1.keys():
                if key not in r2:
                    differences.append(f"Register {i}: Missing key '{key}' in reconstructed")
                elif r1[key] != r2[key]:
                    differences.append(f"Register {i}: {key} mismatch - {r1[key]} vs {r2[key]}")
        
        return {
            "identical": len(differences) == 0,
            "difference_count": len(differences),
            "differences": differences[:10]  # Show first 10 differences
        }


def print_usage():
    """Print usage information"""
    print("\n" + "="*70)
    print("Bidirectional Modbus Configuration Transformer")
    print("="*70)
    print("\nUsage:")
    print("  Forward transformation:")
    print("    python bidirectional_transformer.py forward <register.json> <modbus_out.json> <paramap_out.json>")
    print("\n  Reverse transformation:")
    print("    python bidirectional_transformer.py reverse <modbus.json> <paramap.json> <register_out.json>")
    print("\n  Round-trip validation:")
    print("    python bidirectional_transformer.py validate <register.json>")
    print("\nExamples:")
    print("  # Forward")
    print("  python bidirectional_transformer.py forward Register_Config.json Modbus_Config.json ParamMap_Config.json")
    print("\n  # Reverse")
    print("  python bidirectional_transformer.py reverse Generated_Modbus_Config.json Generated_ParamMap_Config.json Reconstructed_Register_Config.json")
    print("\n  # Validate")
    print("  python bidirectional_transformer.py validate Original_Register_Config.json")
    print()


def main():
    """Main entry point for CLI application"""
    if len(sys.argv) < 2:
        print_usage()
        sys.exit(1)
    
    transformer = BidirectionalTransformer()
    command = sys.argv[1].lower()
    
    if command == "forward":
        if len(sys.argv) < 5:
            print("❌ Error: Forward transformation requires 3 file paths")
            print_usage()
            sys.exit(1)
        
        register_path = sys.argv[2]
        modbus_path = sys.argv[3]
        paramap_path = sys.argv[4]
        
        result = transformer.forward_transform(register_path, modbus_path, paramap_path)
        sys.exit(0 if result["status"] == "success" else 1)
    
    elif command == "reverse":
        if len(sys.argv) < 5:
            print("❌ Error: Reverse transformation requires 3 file paths")
            print_usage()
            sys.exit(1)
        
        modbus_path = sys.argv[2]
        paramap_path = sys.argv[3]
        register_path = sys.argv[4]
        
        result = transformer.reverse_transform(modbus_path, paramap_path, register_path)
        sys.exit(0 if result["status"] == "success" else 1)
    
    elif command == "validate":
        if len(sys.argv) < 3:
            print("❌ Error: Round-trip validation requires register config path")
            print_usage()
            sys.exit(1)
        
        register_path = sys.argv[2]
        
        result = transformer.validate_roundtrip(register_path)
        sys.exit(0 if result["status"] == "success" and result.get("identical", False) else 1)
    
    else:
        print(f"❌ Error: Unknown command '{command}'")
        print_usage()
        sys.exit(1)


if __name__ == "__main__":
    main()
