"""
Reverse Transformation Engine - Smart Version
Converts Modbus JSON + Paramap JSON  Register Entry JSON
WITHOUT extra metadata fields - uses intelligent reconstruction
"""

import json
from typing import Dict, List, Set, Tuple, Optional
from dataclasses import dataclass


@dataclass
class ReconstructedRegister:
    """Reconstructed register entry from reverse transformation - 21-field schema"""
    param_id: int
    slave_id: int
    fc: int
    address: int
    length: int
    fmt: int
    multiplier: float
    access: str
    cloud: str
    json_group: str
    json_unit: str
    json_key: str
    array_membership: str
    b5_id: int  # Original B5.ID
    packet_num: int  # B5.PN - packet number
    packet_sa: int  # B4.SA[packet_num-1] - packet start address
    packet_nrt: int  # B4.NRT[packet_num-1] - num registers in packet
    # NEW FIELDS for 21-field schema
    parameter_type: str  # 'write' | 'feedback' | 'read_only'
    write_param_id: Optional[int]  # For feedback params
    feedback_param_id: Optional[int]  # For write params
    p2_mpi_index: Optional[int]  # P2.MPI ordering
    p3_mpi_index: Optional[int]  # P3.MPI ordering


class ReverseTransformationEngine:
    """Smart reverse transformation - no metadata needed"""

    def __init__(self):
        self.modbus_json = None
        self.paramap_json = None
        self.b5_id_to_props = {}
        self.packet_to_slave_fc = {}
        self.b5_to_json_keys = {}
        self.write_params = set()
        self.feedback_params = set()

    def transform(self, modbus_json: Dict, paramap_json: Dict) -> Dict:
        """Main entry point for reverse transformation"""
        self.modbus_json = modbus_json
        self.paramap_json = paramap_json

        self._validate_input()
        self._extract_b5_mappings()
        self._extract_b4_mappings()
        self._classify_parameters()
        self._extract_mpi_indices()  # NEW: Extract MPI ordering
        self._extract_jky_mappings()

        registers = self._reconstruct_registers()
        self._validate_output(registers)
        
        # Extract metadata for perfect reconstruction
        metadata = self._extract_metadata()

        return {
            "registers": [self._register_to_dict(r) for r in registers],
            "metadata": metadata
        }

    def _validate_input(self):
        """Validate input JSON structure"""
        required_modbus_keys = ["B1", "B2", "B3", "B4", "B5", "B6"]
        for key in required_modbus_keys:
            if key not in self.modbus_json:
                raise ValueError(f"Missing required key in Modbus JSON: {key}")

        required_paramap_keys = ["P1", "P2", "P3", "JKY"]
        for key in required_paramap_keys:
            if key not in self.paramap_json:
                raise ValueError(f"Missing required key in Paramap JSON: {key}")

    def _extract_b5_mappings(self):
        """Extract B5 parameter properties including array_membership if stored"""
        b5 = self.modbus_json["B5"]
        
        # Support both field name formats: AD/STA for address, MP/MLT for multiplier
        address_key = "AD" if "AD" in b5 else "STA"
        multiplier_key = "MP" if "MP" in b5 else "MLT"

        for i, b5_id in enumerate(b5["ID"]):
            self.b5_id_to_props[b5_id] = {
                "address": b5[address_key][i],
                "length": b5["LN"][i],
                "fmt": b5["FMT"][i],
                "multiplier": b5[multiplier_key][i],
                "packet_num": b5["PN"][i],  # Add packet number
                "array_membership": b5.get("AM", [])[i] if "AM" in b5 and i < len(b5.get("AM", [])) else ""  # Store if available
            }

    def _extract_b4_mappings(self):
        """Extract B4 packet to slave/FC mappings"""
        b4 = self.modbus_json["B4"]

        # Build packet_num to slave/FC mapping
        for packet_num in range(1, len(b4.get("SID", [])) + 1):
            idx = packet_num - 1
            self.packet_to_slave_fc[packet_num] = {
                "slave_id": b4.get("SID", [])[idx] if idx < len(b4.get("SID", [])) else 0,
                "fc": b4.get("FC", [])[idx] if idx < len(b4.get("FC", [])) else 0
            }

    def _classify_parameters(self):
        """Classify parameters as write, read, or feedback using B6"""
        b6 = self.modbus_json.get("B6", {})
        
        self.write_params = set(b6.get("WP", []))
        self.feedback_params = set(b6.get("RP", []))
        
        # Build write-feedback cross-reference mappings
        # For feedback params, find their corresponding write param
        self.feedback_to_write = {}  # feedback_param_id -> write_param_id
        self.write_to_feedback = {}  # write_param_id -> feedback_param_id
        
        # Strategy: feedback params in B6.RP correspond to write params in B6.WP
        # Typically they are in the same order, but we'll match by position if available
        wp_list = b6.get("WP", [])
        rp_list = b6.get("RP", [])
        
        # Simple heuristic: pair by index if lists have same length
        if len(wp_list) == len(rp_list):
            for i in range(len(wp_list)):
                write_id = wp_list[i]
                feedback_id = rp_list[i]
                self.write_to_feedback[write_id] = feedback_id
                self.feedback_to_write[feedback_id] = write_id
    
    def _extract_mpi_indices(self):
        """Extract P2.MPI and P3.MPI indices for deterministic ordering"""
        self.p2_mpi_indices = {}  # param_id -> index in P2.MPI
        self.p3_mpi_indices = {}  # param_id -> index in P3.MPI
        
        # Extract P2.MPI ordering
        p2 = self.paramap_json.get("P2", {})
        p2_mpi = p2.get("MPI", [])
        for idx, param_id in enumerate(p2_mpi):
            self.p2_mpi_indices[param_id] = idx
        
        # Extract P3.MPI ordering
        p3 = self.paramap_json.get("P3", {})
        p3_mpi = p3.get("MPI", [])
        for idx, param_id in enumerate(p3_mpi):
            self.p3_mpi_indices[param_id] = idx
    
    def _determine_array_membership(self, b5_id: int, stored_membership: str = "") -> str:
        """Determine which arrays this parameter belongs to
        
        Strategy: If stored_membership is available and non-empty, use it.
        Otherwise, reconstruct from P2/P3 arrays.
        """
        # If we have stored array_membership, use it (prevents enrichment)
        if stored_membership:
            return stored_membership
        
        # Otherwise, reconstruct from P2/P3 arrays
        arrays = []
        
        # Check P2 arrays
        p2 = self.paramap_json.get("P2", {})
        if b5_id in p2.get("LBI", []):
            arrays.append("P2.LBI")
        if b5_id in p2.get("RPCI", []):
            arrays.append("P2.RPCI")
        if b5_id in p2.get("MPI", []):
            arrays.append("P2.MPI")
        
        # Check P3 arrays
        p3 = self.paramap_json.get("P3", {})
        if b5_id in p3.get("MPI", []):
            arrays.append("P3.MPI")
        if b5_id in p3.get("MDI", []):
            arrays.append("P3.MDI")
        
        return ",".join(arrays)

    def _extract_jky_mappings(self):
        """Extract cloud JSON key mappings from JKY
        Supports both JK (dict format) and JKA (array format) field names
        Uses P2.MPI for cloud parameter mapping"""
        jky = self.paramap_json.get("JKY", {})
        
        # Support both formats:
        # JK format: [{"B5_id": "...", "json_group": "...", ...}]
        # JKA format: [["param_id", ["unit"], ["key"]]]
        
        # Debug: JKY keys extraction
        
        if "JK" in jky:
            # Old format: dict entries with explicit B5_id
            for entry in jky.get("JK", []):
                if isinstance(entry, dict) and "B5_id" in entry:
                    b5_id = entry["B5_id"]
                    self.b5_to_json_keys[b5_id] = {
                        "json_group": entry.get("json_group", ""),
                        "json_unit": entry.get("json_unit", ""),
                        "json_key": entry.get("json_key", "")
                    }
            pass  # JK format extracted
        elif "JKA" in jky:
            # Production format: array entries [param_name, [unit], [key]]
            # JKA ordering: First N entries map to P2.MPI, remaining map to P2.LBI
            p2 = self.paramap_json.get("P2", {})
            p2_mpi = p2.get("MPI", [])
            p2_lbi = p2.get("LBI", [])
            jka_entries = jky.get("JKA", [])
            
            # First len(p2_mpi) JKA entries map to Modbus params via P2.MPI
            for jka_idx in range(len(p2_mpi)):
                if jka_idx < len(jka_entries):
                    entry = jka_entries[jka_idx]
                    if isinstance(entry, list) and len(entry) >= 3:
                        param_name = entry[0]
                        json_unit = entry[1][0] if isinstance(entry[1], list) and len(entry[1]) > 0 else ""
                        json_key = entry[2][0] if isinstance(entry[2], list) and len(entry[2]) > 0 else ""
                        
                        b5_id = p2_mpi[jka_idx]  # P2.MPI contains B5.ID values
                        
                        self.b5_to_json_keys[b5_id] = {
                            "json_group": "",
                            "json_unit": json_unit,
                            "json_key": json_key,
                            "param_name": param_name,
                            "jka_index": jka_idx  # Store for forward transform
                        }
            
            # Remaining JKA entries map to local/digital params via P2.LBI
            # Skip duplicates - P2.MPI takes priority over P2.LBI
            mpi_count = len(p2_mpi)
            for jka_idx in range(mpi_count, len(jka_entries)):
                entry = jka_entries[jka_idx]
                lbi_idx = jka_idx - mpi_count
                
                if isinstance(entry, list) and len(entry) >= 3 and lbi_idx < len(p2_lbi):
                    param_name = entry[0]
                    json_unit = entry[1][0] if isinstance(entry[1], list) and len(entry[1]) > 0 else ""
                    json_key = entry[2][0] if isinstance(entry[2], list) and len(entry[2]) > 0 else ""
                    
                    # P2.LBI values are sequential indices (1, 2, 3...) that map to B5.ID
                    b5_id = p2_lbi[lbi_idx]
                    
                    # Skip if already mapped via P2.MPI (avoid duplicates)
                    if b5_id not in self.b5_to_json_keys:
                        self.b5_to_json_keys[b5_id] = {
                            "json_group": "",
                            "json_unit": json_unit,
                            "json_key": json_key,
                            "param_name": param_name,
                            "jka_index": jka_idx  # Store for forward transform
                        }
            
            pass  # JKA format extracted

    def _reconstruct_registers(self) -> List[ReconstructedRegister]:
        """Reconstruct register entries from B5 with all 21 fields"""
        registers = []
        b5 = self.modbus_json["B5"]
        b5_ids = b5["ID"]
        packet_nums = b5["PN"]
        
        # Reconstructing registers

        for i, b5_id in enumerate(b5_ids):
            packet_num = packet_nums[i]
            props = self.b5_id_to_props.get(b5_id, {})
            slave_fc = self.packet_to_slave_fc.get(packet_num, {})
            json_keys = self.b5_to_json_keys.get(b5_id, {})

            # Determine access type
            access = self._determine_access_type(b5_id)
            
            # NEW: Determine parameter_type using B6 cross-reference
            parameter_type = self._determine_parameter_type(b5_id, access)

            # Determine cloud status
            cloud = "Yes" if b5_id in self.b5_to_json_keys else "No"
            
            # Cloud status determined
            
            # Determine array membership (use stored value if available)
            stored_membership = props.get("array_membership", "")
            array_membership = self._determine_array_membership(b5_id, stored_membership)

            # Get packet information
            packet_num = props.get("packet_num", 0)
            packet_idx = packet_num - 1 if packet_num > 0 else 0
            
            # Extract packet metadata from B4
            b4 = self.modbus_json.get("B4", {})
            packet_sa = b4.get("SA", [])[packet_idx] if packet_idx < len(b4.get("SA", [])) else 0
            packet_nrt = b4.get("NRT", [])[packet_idx] if packet_idx < len(b4.get("NRT", [])) else 0
            
            # NEW: Extract write/feedback cross-references
            write_param_id = self.feedback_to_write.get(b5_id) if parameter_type == 'feedback' else None
            feedback_param_id = self.write_to_feedback.get(b5_id) if parameter_type == 'write' else None
            
            # NEW: Extract MPI indices
            p2_mpi_index = self.p2_mpi_indices.get(b5_id)
            p3_mpi_index = self.p3_mpi_indices.get(b5_id)

            register = ReconstructedRegister(
                param_id=b5_id,
                slave_id=slave_fc.get("slave_id", 0),
                fc=slave_fc.get("fc", 0),
                address=props.get("address", 0),
                length=props.get("length", 0),
                fmt=props.get("fmt", 0),
                multiplier=props.get("multiplier", 1.0),
                access=access,
                cloud=cloud,
                json_group=json_keys.get("param_name", ""),  # Store param_name in json_group for production format
                json_unit=json_keys.get("json_unit", ""),
                json_key=json_keys.get("json_key", ""),
                array_membership=array_membership,
                b5_id=b5_id,
                packet_num=packet_num,
                packet_sa=packet_sa,
                packet_nrt=packet_nrt,
                parameter_type=parameter_type,
                write_param_id=write_param_id,
                feedback_param_id=feedback_param_id,
                p2_mpi_index=p2_mpi_index,
                p3_mpi_index=p3_mpi_index
            )

            registers.append(register)

        return registers

    def _determine_access_type(self, b5_id: int) -> str:
        """Determine access type (R, W, RW)"""
        is_write = b5_id in self.write_params
        is_feedback = b5_id in self.feedback_params

        if is_write and is_feedback:
            return "RW"
        elif is_write:
            return "W"
        else:
            return "R"
    
    def _determine_parameter_type(self, b5_id: int, access: str) -> str:
        """Determine parameter_type using B6 cross-reference logic
        
        Logic:
        - If b5_id in B6.WP -> 'write'
        - If b5_id in B6.RP -> 'feedback' (read for verification)
        - Otherwise -> 'read_only' (monitoring/telemetry)
        """
        if b5_id in self.write_params:
            return 'write'
        elif b5_id in self.feedback_params:
            return 'feedback'
        else:
            return 'read_only'

    def _validate_output(self, registers: List):
        """Validate reconstructed registers"""
        if not registers:
            raise ValueError("No registers were reconstructed")

    def _register_to_dict(self, register: ReconstructedRegister) -> Dict:
        """Convert register to dictionary with all 21 fields"""
        return {
            "param_id": register.param_id,
            "slave_id": register.slave_id,
            "fc": register.fc,
            "address": register.address,
            "length": register.length,
            "fmt": register.fmt,
            "multiplier": register.multiplier,
            "access": register.access,
            "cloud": register.cloud,
            "json_group": register.json_group,
            "json_unit": register.json_unit,
            "json_key": register.json_key,
            "array_membership": register.array_membership,
            "b5_id": register.b5_id,
            "packet_num": register.packet_num,
            "packet_sa": register.packet_sa,
            "packet_nrt": register.packet_nrt,
            "parameter_type": register.parameter_type,
            "write_param_id": register.write_param_id,
            "feedback_param_id": register.feedback_param_id,
            "p2_mpi_index": register.p2_mpi_index,
            "p3_mpi_index": register.p3_mpi_index
        }

    def _extract_metadata(self) -> Dict:
        """Extract metadata sections for perfect reconstruction"""
        metadata = {}
        
        # Extract B1, B2, B3 from Modbus JSON
        if "B1" in self.modbus_json:
            metadata["b1"] = self.modbus_json["B1"]
        if "B2" in self.modbus_json:
            metadata["b2"] = self.modbus_json["B2"]
        if "B3" in self.modbus_json:
            metadata["b3"] = self.modbus_json["B3"]
            
        # Extract P1, JKC, NTC, MST from Paramap JSON
        if "P1" in self.paramap_json:
            metadata["p1"] = self.paramap_json["P1"]
        if "JKY" in self.paramap_json:
            metadata["jky"] = self.paramap_json["JKY"]  # Store complete JKY for perfect reconstruction
        if "JKC" in self.paramap_json:
            metadata["jkc"] = self.paramap_json["JKC"]
        if "NTC" in self.paramap_json:
            metadata["ntc"] = self.paramap_json["NTC"]
        if "MST" in self.paramap_json:
            metadata["mst"] = self.paramap_json["MST"]
            
        return metadata
