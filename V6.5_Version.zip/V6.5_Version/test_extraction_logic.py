"""Test extraction logic directly"""
import json
from pathlib import Path

production_path = Path(r"c:\Users\DELL\Documents\GitHub\Thermelgy-Gway-BMIoT\Thermelgy-Gateway-BMIoT\data")
with open(production_path / "Modbus_Config.json", "r") as f:
    modbus_json = json.load(f)
with open(production_path / "ParamMap_Config.json", "r") as f:
    paramap_json = json.load(f)

b5 = modbus_json["B5"]
jky = paramap_json.get("JKY", {})
p2 = paramap_json.get("P2", {})
p2_mpi = p2.get("MPI", [])
p2_lbi = p2.get("LBI", [])
jka_entries = jky.get("JKA", [])

b5_to_json_keys = {}

# Extract from P2.MPI
mpi_count = 0
for jka_idx in range(len(p2_mpi)):
    if jka_idx < len(jka_entries):
        entry = jka_entries[jka_idx]
        if isinstance(entry, list) and len(entry) >= 3:
            b5_id = p2_mpi[jka_idx]
            b5_to_json_keys[b5_id] = f"JKA[{jka_idx}] via P2.MPI"
            mpi_count += 1

print(f"Extracted from P2.MPI: {mpi_count}")

# Extract from P2.LBI
lbi_count = 0
mpi_length = len(p2_mpi)
for jka_idx in range(mpi_length, len(jka_entries)):
    entry = jka_entries[jka_idx]
    lbi_idx = jka_idx - mpi_length
    
    if isinstance(entry, list) and len(entry) >= 3:
        if lbi_idx < len(p2_lbi):
            b5_id = p2_lbi[lbi_idx]
            
            # Check if B5.ID is valid
            if b5_id <= len(b5["ID"]) and b5_id > 0:
                b5_to_json_keys[b5_id] = f"JKA[{jka_idx}] via P2.LBI[{lbi_idx}]={b5_id}"
                lbi_count += 1
            else:
                print(f"  SKIP: JKA[{jka_idx}] -> P2.LBI[{lbi_idx}]={b5_id} (B5.ID out of range)")
        else:
            print(f"  SKIP: JKA[{jka_idx}] -> P2.LBI[{lbi_idx}] (LBI index out of range)")
    else:
        print(f"  SKIP: JKA[{jka_idx}] invalid entry format")

print(f"Extracted from P2.LBI: {lbi_count}")
print(f"Total extracted: {mpi_count + lbi_count}")
print(f"Expected: {len(jka_entries)}")
print(f"Missing: {len(jka_entries) - (mpi_count + lbi_count)}")

# Check for duplicates
unique_b5_ids = len(set(b5_to_json_keys.keys()))
print(f"\nUnique B5.IDs: {unique_b5_ids} (duplicates: {len(b5_to_json_keys) - unique_b5_ids})")
