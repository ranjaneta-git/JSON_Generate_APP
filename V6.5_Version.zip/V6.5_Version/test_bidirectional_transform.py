"""
Bidirectional Transformation Test Suite
Tests round-trip transformation with 21-field schema

Test Strategy:
1. Create minimal 5-parameter test case
2. Forward transform: Register JSON -> Modbus + Paramap JSON
3. Reverse transform: Modbus + Paramap JSON -> Register JSON
4. Verify byte-level equality of original vs reconstructed

Expected Result: 100% round-trip success
"""

import json
import sys
from typing import Dict, Any

# Import transformation engines
try:
    from forward_engine import ForwardTransformationEngine
    from reverse_engine import ReverseTransformationEngine
    print("✅ Transformation engines imported successfully")
except ImportError as e:
    print(f"❌ Failed to import engines: {e}")
    sys.exit(1)


def create_test_case_small() -> Dict:
    """
    Create a minimal 5-parameter test case with all parameter types:
    - 2 write parameters (W)
    - 2 feedback reads (RW - read component)
    - 1 read-only cloud parameter (R)
    """
    return {
        "registers": [
            {
                "param_id": 1,
                "slave_id": 1,
                "fc": 6,  # Write Single Register
                "address": 100,
                "length": 1,
                "fmt": 3,  # Unsigned 16-bit
                "multiplier": 1.0,
                "access": "W",
                "cloud": "No",
                "json_group": "",
                "json_unit": "",
                "json_key": "",
                "array_membership": "P2.RPCI",
                "b5_id": 1,
                "packet_num": 1,
                "packet_sa": 100,
                "packet_nrt": 1,
                "parameter_type": "write",
                "write_param_id": None,
                "feedback_param_id": 2,  # Has feedback read
                "p2_mpi_index": None,  # Not in P2.MPI (only in RPCI)
                "p3_mpi_index": None
            },
            {
                "param_id": 2,
                "slave_id": 1,
                "fc": 3,  # Read Holding Registers
                "address": 100,
                "length": 1,
                "fmt": 3,
                "multiplier": 1.0,
                "access": "R",
                "cloud": "No",
                "json_group": "",
                "json_unit": "",
                "json_key": "",
                "array_membership": "",
                "b5_id": 2,
                "packet_num": 2,
                "packet_sa": 100,
                "packet_nrt": 1,
                "parameter_type": "feedback",
                "write_param_id": 1,  # Feedback for param 1
                "feedback_param_id": None,
                "p2_mpi_index": None,
                "p3_mpi_index": None
            },
            {
                "param_id": 3,
                "slave_id": 1,
                "fc": 6,
                "address": 200,
                "length": 1,
                "fmt": 3,
                "multiplier": 1.0,
                "access": "W",
                "cloud": "No",
                "json_group": "",
                "json_unit": "",
                "json_key": "",
                "array_membership": "P2.RPCI",
                "b5_id": 3,
                "packet_num": 3,
                "packet_sa": 200,
                "packet_nrt": 1,
                "parameter_type": "write",
                "write_param_id": None,
                "feedback_param_id": 4,
                "p2_mpi_index": None,  # Not in P2.MPI (only in RPCI)
                "p3_mpi_index": None
            },
            {
                "param_id": 4,
                "slave_id": 1,
                "fc": 3,
                "address": 200,
                "length": 1,
                "fmt": 3,
                "multiplier": 1.0,
                "access": "R",
                "cloud": "No",
                "json_group": "",
                "json_unit": "",
                "json_key": "",
                "array_membership": "",
                "b5_id": 4,
                "packet_num": 4,
                "packet_sa": 200,
                "packet_nrt": 1,
                "parameter_type": "feedback",
                "write_param_id": 3,
                "feedback_param_id": None,
                "p2_mpi_index": None,
                "p3_mpi_index": None
            },
            {
                "param_id": 5,
                "slave_id": 1,
                "fc": 3,
                "address": 300,
                "length": 2,
                "fmt": 1,  # Float 32-bit
                "multiplier": 1.0,
                "access": "R",
                "cloud": "Yes",
                "json_group": "sensor",
                "json_unit": "unit1",
                "json_key": "temperature",
                "array_membership": "P2.MPI,P3.MPI",
                "b5_id": 5,
                "packet_num": 5,
                "packet_sa": 300,
                "packet_nrt": 2,
                "parameter_type": "read_only",
                "write_param_id": None,
                "feedback_param_id": None,
                "p2_mpi_index": 0,  # First (and only) item in P2.MPI
                "p3_mpi_index": 0   # First (and only) item in P3.MPI
            }
        ],
        "metadata": {
            "b1": {"BR": 9600, "DBT": 8, "PTY": 0, "SBT": 1},
            "b2": {"PRF": 0},
            "b3": {"SID": [1], "SFC": [3, 6]},
            "p1": {"DT": 0, "DN": "TestDevice"}
        }
    }


def normalize_json(obj: Any) -> Any:
    """Normalize JSON for comparison (sort keys, handle floats)"""
    if isinstance(obj, dict):
        return {k: normalize_json(v) for k, v in sorted(obj.items())}
    elif isinstance(obj, list):
        return [normalize_json(item) for item in obj]
    elif isinstance(obj, float):
        return round(obj, 6)  # Round to 6 decimals
    return obj


def compare_json_deep(obj1: Any, obj2: Any, path: str = "root") -> tuple:
    """Deep comparison of JSON objects, returns (is_equal, differences)"""
    differences = []
    
    if type(obj1) != type(obj2):
        differences.append(f"{path}: Type mismatch - {type(obj1).__name__} vs {type(obj2).__name__}")
        return False, differences
    
    if isinstance(obj1, dict):
        all_keys = set(obj1.keys()) | set(obj2.keys())
        for key in sorted(all_keys):
            if key not in obj1:
                differences.append(f"{path}.{key}: Missing in original")
            elif key not in obj2:
                differences.append(f"{path}.{key}: Missing in reconstructed")
            else:
                is_equal, sub_diffs = compare_json_deep(obj1[key], obj2[key], f"{path}.{key}")
                if not is_equal:
                    differences.extend(sub_diffs)
    
    elif isinstance(obj1, list):
        if len(obj1) != len(obj2):
            differences.append(f"{path}: List length mismatch - {len(obj1)} vs {len(obj2)}")
            return False, differences
        
        for i, (item1, item2) in enumerate(zip(obj1, obj2)):
            is_equal, sub_diffs = compare_json_deep(item1, item2, f"{path}[{i}]")
            if not is_equal:
                differences.extend(sub_diffs)
    
    elif isinstance(obj1, float) and isinstance(obj2, float):
        if abs(obj1 - obj2) > 1e-6:
            differences.append(f"{path}: Float mismatch - {obj1} vs {obj2}")
    
    elif obj1 != obj2:
        differences.append(f"{path}: Value mismatch - {obj1} vs {obj2}")
    
    return len(differences) == 0, differences


def test_round_trip_small():
    """Test round-trip transformation with 5-parameter config"""
    print("\n" + "="*70)
    print("TEST: Round-Trip Transformation (5 parameters)")
    print("="*70)
    
    # Step 1: Create test data
    print("\n[Step 1] Creating test case (5 parameters)...")
    original_register_json = create_test_case_small()
    print(f"✅ Created {len(original_register_json['registers'])} parameters")
    print(f"   - 2 write params (W)")
    print(f"   - 2 feedback reads (RW verification)")
    print(f"   - 1 read-only cloud param (R)")
    
    # Step 2: Forward transform
    print("\n[Step 2] Forward transform: Register JSON -> Modbus + Paramap JSON...")
    try:
        forward_engine = ForwardTransformationEngine()
        modbus_json, paramap_json = forward_engine.transform(original_register_json)
        print("✅ Forward transform successful")
        print(f"   - Modbus blocks: B1-B6")
        print(f"   - B4 packets: {len(modbus_json['B4']['SID'])}")
        print(f"   - B5 parameters: {len(modbus_json['B5']['ID'])}")
        print(f"   - B6 write params: {len(modbus_json['B6']['WP'])}")
        print(f"   - B6 feedback params: {len(modbus_json['B6']['RP'])}")
        print(f"   - P2.MPI: {paramap_json['P2']['MPI']}")
        print(f"   - P3.MPI: {paramap_json['P3']['MPI']}")
    except Exception as e:
        print(f"❌ Forward transform failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    # Step 3: Reverse transform
    print("\n[Step 3] Reverse transform: Modbus + Paramap JSON -> Register JSON...")
    try:
        reverse_engine = ReverseTransformationEngine()
        reconstructed_register_json = reverse_engine.transform(modbus_json, paramap_json)
        print("✅ Reverse transform successful")
        print(f"   - Reconstructed {len(reconstructed_register_json['registers'])} parameters")
    except Exception as e:
        print(f"❌ Reverse transform failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    # Step 4: Compare original vs reconstructed
    print("\n[Step 4] Comparing original vs reconstructed...")
    
    # Normalize for comparison
    orig_normalized = normalize_json(original_register_json)
    recon_normalized = normalize_json(reconstructed_register_json)
    
    # Deep comparison
    is_equal, differences = compare_json_deep(orig_normalized, recon_normalized)
    
    if is_equal:
        print("✅ ✅ ✅ PERFECT MATCH! Round-trip successful!")
        print("   All 21 fields preserved byte-for-byte")
        return True
    else:
        print(f"❌ MISMATCH DETECTED! Found {len(differences)} differences:")
        for i, diff in enumerate(differences[:20], 1):  # Show first 20
            print(f"   {i}. {diff}")
        if len(differences) > 20:
            print(f"   ... and {len(differences) - 20} more differences")
        
        # Save detailed comparison
        with open("test_comparison_small.json", "w") as f:
            json.dump({
                "original": orig_normalized,
                "reconstructed": recon_normalized,
                "differences": differences
            }, f, indent=2)
        print("\n   💾 Detailed comparison saved to: test_comparison_small.json")
        
        return False


def test_field_preservation():
    """Test that all 21 fields are preserved"""
    print("\n" + "="*70)
    print("TEST: 21-Field Schema Preservation")
    print("="*70)
    
    original = create_test_case_small()
    forward_engine = ForwardTransformationEngine()
    reverse_engine = ReverseTransformationEngine()
    
    modbus_json, paramap_json = forward_engine.transform(original)
    reconstructed = reverse_engine.transform(modbus_json, paramap_json)
    
    # Check each field for first register
    orig_reg = original['registers'][0]
    recon_reg = reconstructed['registers'][0]
    
    required_fields = [
        'param_id', 'slave_id', 'fc', 'address', 'length', 'fmt', 'multiplier',
        'access', 'cloud', 'json_group', 'json_unit', 'json_key', 'array_membership',
        'b5_id', 'packet_num', 'packet_sa', 'packet_nrt',
        'parameter_type', 'write_param_id', 'feedback_param_id', 'p2_mpi_index', 'p3_mpi_index'
    ]
    
    print(f"\nChecking {len(required_fields)} fields in first register...")
    all_present = True
    for field in required_fields:
        if field not in recon_reg:
            print(f"   ❌ Missing field: {field}")
            all_present = False
        else:
            orig_val = orig_reg.get(field)
            recon_val = recon_reg.get(field)
            if orig_val == recon_val:
                print(f"   ✅ {field}: {recon_val}")
            else:
                print(f"   ⚠️  {field}: {orig_val} -> {recon_val}")
    
    if all_present:
        print("\n✅ All 21 fields present in reconstructed data")
        return True
    else:
        print("\n❌ Some fields missing")
        return False


def main():
    """Run all tests"""
    print("\n" + "="*70)
    print("BIDIRECTIONAL TRANSFORMATION TEST SUITE")
    print("Testing 21-field schema with round-trip validation")
    print("="*70)
    
    tests = [
        ("Field Preservation", test_field_preservation),
        ("Round-Trip Small Config", test_round_trip_small)
    ]
    
    results = []
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"\n❌ Test '{test_name}' crashed: {e}")
            import traceback
            traceback.print_exc()
            results.append((test_name, False))
    
    # Summary
    print("\n" + "="*70)
    print("TEST SUMMARY")
    print("="*70)
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} - {test_name}")
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 🎉 🎉 ALL TESTS PASSED! 🎉 🎉 🎉")
        print("Round-trip transformation is working perfectly!")
        return True
    else:
        print(f"\n⚠️  {total - passed} test(s) failed. Please review output above.")
        return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
