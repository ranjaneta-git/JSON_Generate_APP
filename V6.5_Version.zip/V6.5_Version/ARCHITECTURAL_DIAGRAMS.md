# 📐 ARCHITECTURAL DIAGRAMS - Bidirectional Transformation System

**Date:** February 5, 2026  
**Purpose:** Visual representation of the BMIoT Configuration Generator architecture  

---

## 🏗️ SYSTEM OVERVIEW

```
┌─────────────────────────────────────────────────────────────────────┐
│                  BMIoT Configuration Generator                      │
│                    (Bidirectional Compiler)                         │
└─────────────────────────────────────────────────────────────────────┘
                                   │
                    ┌──────────────┴──────────────┐
                    │                             │
           ┌────────▼────────┐          ┌────────▼────────┐
           │ Forward Engine  │          │ Reverse Engine  │
           │ (Reg → JSON)    │          │ (JSON → Reg)    │
           └────────┬────────┘          └────────┬────────┘
                    │                             │
                    │                             │
    ┌───────────────▼────────────┐   ┌───────────▼────────────────┐
    │  Register Configuration    │   │   Modbus + Paramap JSON    │
    │  (21 fields per param)     │◄──┤   (B1-B6, P1-P3, JKY...)   │
    └────────────────────────────┘   └────────────────────────────┘
```

---

## 📊 DATA FLOW: FORWARD TRANSFORMATION

```
Register Config (21 fields)
         │
         │ Extract & Group
         ▼
    ┌────────────┐
    │   Build    │
    │   B1-B6    │  ← Modbus Input_Output JSON
    └─────┬──────┘
          │
          │ Use B5.ID as key
          ▼
    ┌────────────┐
    │   Build    │
    │   P1-P3    │  ← Parameter Mapping JSON
    └─────┬──────┘
          │
          │ Map to equipment
          ▼
    ┌────────────┐
    │   Build    │
    │    JKY     │  ← Equipment Type Mapping
    └─────┬──────┘
          │
          ▼
   Two JSON Files
   (ready for ESP32)
```

---

## 📊 DATA FLOW: REVERSE TRANSFORMATION

```
Two JSON Files
(from ESP32 or import)
         │
         │ Parse JSON
         ▼
    ┌────────────┐
    │  Extract   │
    │   B1-B6    │  → Get B5.ID, PN, STA, LN, FMT, MLT
    └─────┬──────┘
          │
          │ Cross-reference B6
          ▼
    ┌────────────┐
    │  Identify  │
    │ Param Type │  → Write? Feedback? Read-only?
    └─────┬──────┘
          │
          │ Extract P2/P3
          ▼
    ┌────────────┐
    │  Extract   │
    │   MPI/LBI  │  → Get P2.MPI, P3.MPI indices
    └─────┬──────┘
          │
          │ Populate all fields
          ▼
Register Config (21 fields)
  (ready for editing)
```

---

## 🔄 ROUND-TRIP FLOW (THE GOAL)

```
                    ┌──────────────────────┐
                    │  Register Config A   │
                    │    (21 fields)       │
                    └──────────┬───────────┘
                               │
                               │ Forward Transform
                               ▼
                    ┌──────────────────────┐
                    │  JSON Set 1          │
                    │  (Modbus + Paramap)  │
                    └──────────┬───────────┘
                               │
                               │ Reverse Transform
                               ▼
                    ┌──────────────────────┐
                    │  Register Config B   │
                    │    (21 fields)       │
                    └──────────┬───────────┘
                               │
                               │ Forward Transform
                               ▼
                    ┌──────────────────────┐
                    │  JSON Set 2          │
                    │  (Modbus + Paramap)  │
                    └──────────────────────┘

✅ SUCCESS CONDITION:
   JSON Set 1 === JSON Set 2  (byte-level equality)
   Register Config A ≈ Register Config B  (ignoring non-JSON fields)
```

---

## 📦 REGISTER CONFIG SCHEMA (21 FIELDS)

```
┌─────────────────────────────────────────────────────────┐
│                    RegisterConfig                       │
├─────────────────────────────────────────────────────────┤
│ ORIGINAL FIELDS (1-17):                                 │
│  1. id                    (Internal ID)                 │
│  2. name                  (Parameter name)              │
│  3. slave_address         (Modbus slave 1-255)          │
│  4. register_address      (Modbus register 0-65535)     │
│  5. length                (1 or 2 registers)            │
│  6. data_format           (1-8: FP32, UINT16, etc.)     │
│  7. multiplier            (Scaling factor)              │
│  8. cloud_output          (True/False)                  │
│  9. array_membership      (Equipment group)             │
│ 10. function_code         (3, 4, 6, 16)                 │
│ 11. unit                  (Engineering unit)            │
│ 12. lower_limit           (Min value)                   │
│ 13. upper_limit           (Max value)                   │
│ 14. b5_id                 (B5.ID - PRIMARY KEY)         │
│ 15. packet_num            (B5.PN - packet index)        │
│ 16. packet_sa             (B4.SA - start address)       │
│ 17. packet_nrt            (B4.NRT - register count)     │
├─────────────────────────────────────────────────────────┤
│ NEW FIELDS (18-21):                                     │
│ 18. parameter_type        ('write'|'feedback'|'read')   │
│ 19. write_param_id        (B5.ID of write param)        │
│ 20. feedback_param_id     (B5.ID of feedback param)     │
│ 21a. p2_mpi_index         (Position in P2.MPI)          │
│ 21b. p3_mpi_index         (Position in P3.MPI)          │
└─────────────────────────────────────────────────────────┘

RELATIONSHIPS:
  - If parameter_type = 'write':
      feedback_param_id → points to feedback read parameter
  
  - If parameter_type = 'feedback':
      write_param_id → points to write parameter
  
  - If parameter_type = 'read_only':
      write_param_id = None
      feedback_param_id = None
  
  - Exactly ONE of p2_mpi_index OR p3_mpi_index must be set
```

---

## 📋 MODBUS JSON STRUCTURE (B1-B6)

```
Modbus_Config.json
├── B1 (Global Counts)
│   ├── NOS: 13           (Number of Slaves)
│   ├── NOP: 163          (Number of Parameters)
│   ├── NPT: 82           (Number of Packets)
│   └── NOR: 264          (Number of Registers)
│
├── B2 (Communication)
│   ├── BR: 38400         (Baud Rate)
│   └── DF: "8N1"         (Data Format)
│
├── B3 (Slave Indexing)
│   ├── SI: [4,5,6,7...]  (Slave IDs)
│   └── SP: [1,9,17,25...]  (Start Packets per slave)
│
├── B4 (Packet Definitions) [82 packets]
│   ├── SA: [1, 32, ...]  (Start Addresses)
│   ├── NRT: [31, 31, ...]  (Register counts per packet)
│   ├── FC: [3, 3, ...]   (Function Codes)
│   └── SID: [4, 4, ...]  (Slave IDs per packet)
│
├── B5 (Parameter Table) [163 parameters]
│   ├── ID: [1,2,3,...]   (Parameter IDs - PRIMARY KEY)
│   ├── PN: [1,1,1,2...]  (Packet Numbers)
│   ├── STA: [1,2,3,...]  (Start Addresses)
│   ├── LN: [1,1,1,...]   (Lengths)
│   ├── FMT: [3,3,3,...]  (Data Formats)
│   └── MLT: [1,1,1,...]  (Multipliers)
│
└── B6 (Write-Read Mapping) [36 write params]
    ├── WP: [8,9,10,...]  (Write Parameter IDs)
    └── RP: [11,12,13,...]  (Read Parameter IDs for verification)

KEY RELATIONSHIPS:
  - B5.PN references B4 packets (1-indexed)
  - B5.STA must be within packet range: B4.SA[PN-1] ≤ STA < B4.SA[PN-1] + B4.NRT[PN-1]
  - B6.WP and B6.RP reference B5.ID
  - B3.SP[i] = first packet number for slave B3.SI[i]
```

---

## 📋 PARAMAP JSON STRUCTURE (P1-P3)

```
ParamMap_Config.json
├── P1 (Size Definitions)
│   ├── NMD: 163          (Total MPI count = P2 + P3)
│   ├── NLB: 163          (Total LBI count)
│   └── NLBIN: 163        (Lua buffer input count)
│
├── P2 (Write Section) [72 MPI = 36 write + 36 feedback]
│   ├── MPI: [8,11,9,12,10,13,...]  (Modbus Parameter Indices)
│   │                               ↑  ↑
│   │                          write  feedback
│   │                               ↑  ↑
│   │                          write  feedback
│   │
│   ├── LBI: [1,2,3,4,5,6,...]      (Lua Buffer Indices - sequential)
│   └── RPCI: [101,102,103,...]     (RPC Indices - write params only)
│
├── P3 (Monitoring Section) [91 MPI = read-only params]
│   ├── MPI: [1,2,3,4,5,6,7,...]    (Read-only parameters for cloud)
│   ├── MDI: [1,2,3,4,5,6,7,...]    (M_data indices - sequential)
│   └── LBI: [73,74,75,76,...]      (Lua Buffer Indices - continues from P2)
│
├── JKY (Equipment Type Mapping)
│   ├── JEType: ["CHILLER", "AHU", ...]
│   └── JK: [[param_names], [param_names], ...]
│
├── JKC (Common Keys)
├── NTC (NTC Sensor Config)
└── MST (Profile Setup)

KEY RELATIONSHIPS:
  - P2.MPI contains write + feedback pairs (from B6)
  - P3.MPI contains read-only parameters (NOT in B6)
  - P1.NMD = len(P2.MPI) + len(P3.MPI) = 72 + 91 = 163
  - P2.LBI: 1..72 (sequential)
  - P3.LBI: 73..163 (continues from P2)
  - P2.RPCI has same length as B6.WP (36)
  - ALL parameters must be in EITHER P2.MPI OR P3.MPI
```

---

## 🔗 KEY RELATIONSHIPS

```
          ┌──────────┐
          │   B5.ID  │  ◄─── PRIMARY KEY (links Modbus + Paramap)
          └────┬─────┘
               │
   ┌───────────┼───────────┐
   │           │           │
   ▼           ▼           ▼
┌──────┐  ┌──────┐   ┌──────────┐
│ B5.PN│  │ B6   │   │ P2/P3    │
│  ↓   │  │ WP/RP│   │   MPI    │
│ B4   │  │      │   │          │
└──────┘  └──────┘   └──────────┘
  ↓           ↓            ↓
SA/NRT    write/read   P2 or P3?
  ↓           ↓            ↓
Packet   Param Type   Cloud Output
Metadata


EXAMPLE: Parameter with B5.ID = 8

1. B5[7] (0-indexed):
   - ID: 8
   - PN: 2  →  B4[1]: SA=32, NRT=31, FC=3, SID=4
   - STA: 40
   - LN: 1
   - FMT: 3 (UINT16)
   - MLT: 1

2. B6:
   - WP[0]: 8  →  This is a WRITE parameter
   - RP[0]: 11  →  Feedback read is parameter 11

3. P2:
   - MPI[0]: 8  →  First parameter in P2
   - LBI[0]: 1  →  Lua buffer index = 1
   - RPCI[0]: 101  →  RPC command index = 101

4. Register Config:
   - b5_id: 8
   - packet_num: 2
   - packet_sa: 32
   - packet_nrt: 31
   - parameter_type: 'write'
   - feedback_param_id: 11
   - p2_mpi_index: 0
   - p3_mpi_index: None
   - cloud_output: False  (in P2, not P3)
```

---

## 🚨 ROOT CAUSE #1: PACKET RECOMPUTATION

```
┌─────────────────────────────────────────────────────┐
│                ORIGINAL STATE                       │
├─────────────────────────────────────────────────────┤
│ Register Config:                                    │
│   Param 1: SA=1,   Len=31  →  Packet 1: SA=1,  NRT=31  │
│   Param 2: SA=32,  Len=31  →  Packet 2: SA=32, NRT=31  │
│   Param 3: SA=100, Len=2   →  Packet 3: SA=100,NRT=2   │
└─────────────────────────────────────────────────────┘
                        │
                        │ Forward Transform
                        ▼
┌─────────────────────────────────────────────────────┐
│                   B4 JSON                           │
├─────────────────────────────────────────────────────┤
│ SA:  [1, 32, 100]                                   │
│ NRT: [31, 31, 2]                                    │
│ 3 packets total                                     │
└─────────────────────────────────────────────────────┘
                        │
                        │ Reverse Transform
                        ▼
┌─────────────────────────────────────────────────────┐
│            RECONSTRUCTED STATE                      │
├─────────────────────────────────────────────────────┤
│ Register Config:                                    │
│   Param 1: packet_num=1, packet_sa=1,  packet_nrt=31  │
│   Param 2: packet_num=2, packet_sa=32, packet_nrt=31  │
│   Param 3: packet_num=3, packet_sa=100,packet_nrt=2   │
└─────────────────────────────────────────────────────┘
                        │
                        │ Forward Transform AGAIN
                        │ (RECOMPUTES packets!)
                        ▼
┌─────────────────────────────────────────────────────┐
│             B4 JSON (DIFFERENT!)                    │
├─────────────────────────────────────────────────────┤
│ Heuristic: Merge packets 1 & 2 (total 62 regs < 70)│
│                                                     │
│ SA:  [1, 100]        ← ONLY 2 PACKETS NOW!          │
│ NRT: [62, 2]         ← MERGED!                      │
│ 2 packets total                                     │
└─────────────────────────────────────────────────────┘

❌ RESULT: JSONs don't match!

✅ FIX: Don't recompute packets - use stored metadata
   - Use packet_num, packet_sa, packet_nrt directly
   - Never rebuild packet structure
```

---

## 🚨 ROOT CAUSE #2: P2/P3 BOUNDARY AMBIGUITY

```
┌─────────────────────────────────────────────────────┐
│                P2.MPI ARRAY                         │
├─────────────────────────────────────────────────────┤
│ MPI: [8, 11, 9, 12, 10, 13]                         │
│       ↑   ↑  ↑   ↑  ↑   ↑                          │
│       ?   ?  ?   ?  ?   ?                           │
│                                                     │
│ QUESTION: Which are write? Which are feedback?      │
└─────────────────────────────────────────────────────┘

❌ CURRENT LOGIC (WRONG):
   "If in P2.MPI, guess it's write or feedback"
   → Can't distinguish!

✅ CORRECT LOGIC:
   Cross-reference B6:
   
   B6.WP = [8, 9, 10]   ← Write parameters
   B6.RP = [11, 12, 13] ← Feedback read parameters
   
   P2.MPI = [8, 11, 9, 12, 10, 13]
             ↓   ↓  ↓   ↓  ↓   ↓
           write  ↓  write ↓  write ↓
               feedback  feedback  feedback
   
   Result:
   - Param 8:  parameter_type = 'write',    feedback_param_id = 11
   - Param 11: parameter_type = 'feedback', write_param_id = 8
   - Param 9:  parameter_type = 'write',    feedback_param_id = 12
   - Param 12: parameter_type = 'feedback', write_param_id = 9
   - Param 10: parameter_type = 'write',    feedback_param_id = 13
   - Param 13: parameter_type = 'feedback', write_param_id = 10
```

---

## 🚨 ROOT CAUSE #3: MPI ORDERING NON-DETERMINISM

```
┌─────────────────────────────────────────────────────┐
│          FIRST FORWARD TRANSFORM                    │
├─────────────────────────────────────────────────────┤
│ Write params (from dict iteration order):          │
│   [Param 8, Param 9, Param 10]                      │
│                                                     │
│ Build P2.MPI:                                       │
│   For each write: add write, then add feedback     │
│   Result: [8, 11, 9, 12, 10, 13]                    │
└─────────────────────────────────────────────────────┘
                        │
                        │ Reverse + Forward again
                        ▼
┌─────────────────────────────────────────────────────┐
│         SECOND FORWARD TRANSFORM                    │
├─────────────────────────────────────────────────────┤
│ Write params (DIFFERENT dict iteration order):     │
│   [Param 10, Param 8, Param 9]  ← ORDER CHANGED!    │
│                                                     │
│ Build P2.MPI:                                       │
│   Result: [10, 13, 8, 11, 9, 12]  ← DIFFERENT!      │
└─────────────────────────────────────────────────────┘

❌ RESULT: P2.MPI order unstable!

✅ FIX: Store MPI indices explicitly
   Register Config:
   - Param 8:  p2_mpi_index = 0
   - Param 11: p2_mpi_index = 1
   - Param 9:  p2_mpi_index = 2
   - Param 12: p2_mpi_index = 3
   - Param 10: p2_mpi_index = 4
   - Param 13: p2_mpi_index = 5
   
   Forward transform:
   - Sort by p2_mpi_index
   - Always produces [8, 11, 9, 12, 10, 13]
```

---

## ✅ CORRECTED ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────┐
│              BIDIRECTIONAL TRANSFORMATION                   │
│              (WITH STORED METADATA)                         │
└─────────────────────────────────────────────────────────────┘

Register Config (21 fields)
  ↓
  ├─ b5_id (PRIMARY KEY)
  ├─ packet_num (STORED - never recompute)
  ├─ packet_sa (STORED - never recompute)
  ├─ packet_nrt (STORED - never recompute)
  ├─ parameter_type (STORED - never guess)
  ├─ write_param_id (STORED - explicit link)
  ├─ feedback_param_id (STORED - explicit link)
  ├─ p2_mpi_index (STORED - preserve order)
  └─ p3_mpi_index (STORED - preserve order)
  
  Forward Transform:
    - Build B4: Use packet_num, packet_sa, packet_nrt (NO recomputation)
    - Build B5: Use b5_id as primary key
    - Build B6: Use parameter_type + feedback_param_id
    - Build P2: Sort by p2_mpi_index (deterministic order)
    - Build P3: Sort by p3_mpi_index (deterministic order)
  
  Reverse Transform:
    - Extract B5: Get b5_id, PN, STA, LN, FMT, MLT
    - Extract B4: Use PN to find SA, NRT, FC, SID
    - Cross-ref B6: Determine parameter_type
    - Extract P2: Set p2_mpi_index from MPI position
    - Extract P3: Set p3_mpi_index from MPI position
  
  Validation:
    - Forward: Check B1 counts, B5 IDs, B6 mappings, P2/P3 disjoint
    - Reverse: Check all 21 fields populated, types consistent
    - Round-trip: Assert JSON byte-equality

✅ RESULT: Perfect bidirectional invertibility!
```

---

## 📊 TRANSFORMATION DECISION TREE

```
                      ┌─────────────┐
                      │ Start       │
                      └──────┬──────┘
                             │
                             ▼
                   ┌─────────────────┐
                   │ Do you have     │
                   │ Register Config?│
                   └────┬──────┬─────┘
                        │      │
                   YES  │      │ NO
                        │      │
                        ▼      ▼
               ┌────────────┐  ┌────────────┐
               │  Forward   │  │  Reverse   │
               │ Transform  │  │ Transform  │
               └──────┬─────┘  └──────┬─────┘
                      │                │
                      │                │
                      ▼                ▼
             ┌────────────────┐  ┌────────────────┐
             │ Use STORED     │  │ EXTRACT from   │
             │ packet_num     │  │ B4 via PN      │
             │ packet_sa      │  │                │
             │ packet_nrt     │  │ Cross-ref B6   │
             │ p2_mpi_index   │  │ for param type │
             │ p3_mpi_index   │  │                │
             │ parameter_type │  │ Extract P2/P3  │
             │                │  │ for MPI index  │
             └────────┬───────┘  └────────┬───────┘
                      │                   │
                      │                   │
                      ▼                   ▼
                 ┌─────────────────────────┐
                 │   Validate Output       │
                 ├─────────────────────────┤
                 │ Forward: B1, B5, B6, P2 │
                 │ Reverse: All 21 fields  │
                 │ Round-trip: Byte-equal  │
                 └────────────┬────────────┘
                              │
                              ▼
                         ┌─────────┐
                         │  Done   │
                         └─────────┘

KEY PRINCIPLE:
  → Forward: LOOKUP stored metadata
  → Reverse: EXTRACT + store metadata
  → Never RECOMPUTE
  → Always VALIDATE
```

---

## 🎯 VALIDATION FLOW

```
┌──────────────────────────────────────────────────────────┐
│                 VALIDATION CHECKPOINTS                   │
└──────────────────────────────────────────────────────────┘

After Forward Transform (Register → JSON):
  ┌─────────────────────────────────────────┐
  │ ✅ B1 counts correct?                   │
  │    - NOS = unique slaves                │
  │    - NOP = total parameters             │
  │    - NPT = unique packets               │
  │    - NOR = sum of packet NRT            │
  ├─────────────────────────────────────────┤
  │ ✅ B5.ID valid?                         │
  │    - Unique                             │
  │    - Sequential (1, 2, 3, ...)          │
  │    - No gaps                            │
  ├─────────────────────────────────────────┤
  │ ✅ B6 mappings valid?                   │
  │    - WP all in B5.ID                    │
  │    - RP all in B5.ID                    │
  │    - WP and RP in P2.MPI                │
  ├─────────────────────────────────────────┤
  │ ✅ P2/P3 disjoint?                      │
  │    - No overlap                         │
  │    - P1.NMD = len(P2.MPI) + len(P3.MPI) │
  ├─────────────────────────────────────────┤
  │ ✅ Packet metadata consistent?          │
  │    - B5.PN valid (1 to NPT)             │
  │    - B5.STA within packet range         │
  └─────────────────────────────────────────┘

After Reverse Transform (JSON → Register):
  ┌─────────────────────────────────────────┐
  │ ✅ All B5.IDs extracted?                │
  │    - Count matches B1.NOP               │
  ├─────────────────────────────────────────┤
  │ ✅ All 21 fields populated?             │
  │    - No None values (except write/fb)   │
  ├─────────────────────────────────────────┤
  │ ✅ Parameter types consistent?          │
  │    - Write has feedback_param_id        │
  │    - Feedback has write_param_id        │
  │    - Read-only has neither              │
  ├─────────────────────────────────────────┤
  │ ✅ P2/P3 membership correct?            │
  │    - Exactly one MPI index set          │
  │    - Count matches P2.MPI + P3.MPI      │
  └─────────────────────────────────────────┘

After Round-Trip:
  ┌─────────────────────────────────────────┐
  │ ✅ JSON byte-equality?                  │
  │    - json.dumps(J1) == json.dumps(J2)   │
  ├─────────────────────────────────────────┤
  │ ✅ Register Config equivalence?         │
  │    - All B5-sourced fields match        │
  │    - Packet metadata match              │
  │    - Parameter types match              │
  │    - MPI indices match                  │
  └─────────────────────────────────────────┘

✅ ALL CHECKS PASS → Production Ready!
```

---

**Prepared by:** Senior Firmware-Aware System Architect  
**Date:** February 5, 2026  
**Status:** ✅ Complete Visual Reference
