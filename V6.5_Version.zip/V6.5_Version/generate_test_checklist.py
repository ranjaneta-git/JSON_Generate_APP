"""
Phase 6 Device Validation - Test Checklist Generator
Creates printable checklist for on-site device testing
"""

from datetime import datetime

def generate_checklist():
    """Generate comprehensive test checklist"""
    
    checklist = f"""
{'='*80}
PHASE 6 DEVICE VALIDATION CHECKLIST
{'='*80}

Date: {datetime.now().strftime('%Y-%m-%d %H:%M')}
Tester: ________________
Device ID: ________________
Location: ________________

{'='*80}
PRE-DEPLOYMENT (30 minutes)
{'='*80}

Hardware Setup:
[ ] ESP32 device connected and powered
[ ] USB serial cable connected
[ ] Modbus test slaves connected and powered
[ ] Network connection verified (WiFi/Ethernet)
[ ] Serial monitor configured (115200 baud)

Backup Current Configuration:
[ ] Connected to device web interface
[ ] Downloaded current Modbus_Config.json
[ ] Downloaded current ParamMap_Config.json
[ ] Saved device info (firmware version, MAC, etc.)
[ ] Created backup folder with timestamp
[ ] Verified backup files are readable

Configuration Preparation:
[ ] Validated JSON files copied to upload location
[ ] File checksums verified
[ ] M-Das OTA interface accessible
[ ] Device visible in M-Das device list

{'='*80}
CONFIGURATION UPLOAD (15 minutes)
{'='*80}

Upload Process:
[ ] Logged into M-Das OTA interface
[ ] Selected target device by MAC/ID
[ ] Uploaded Modbus_Config.json
[ ] Upload confirmed (checksum/size verified)
[ ] Uploaded ParamMap_Config.json
[ ] Upload confirmed (checksum/size verified)

Configuration Reload:
[ ] Triggered configuration reload command
[ ] Device responded to reload request
[ ] No error messages in serial log
[ ] Device reboot completed (if required)
[ ] New configuration loaded successfully

Verification:
[ ] Device shows 163 parameters in status
[ ] Device shows 82 packets configured
[ ] Device shows 13 slaves configured
[ ] No configuration parse errors

{'='*80}
MODBUS COMMUNICATION (45 minutes)
{'='*80}

Basic Connectivity:
[ ] Device initiates Modbus polling
[ ] All 13 slave IDs attempted
[ ] No unexpected exceptions/crashes
[ ] Serial log shows normal packet flow
Notes: ________________________________________________________________

Packet Transmission:
[ ] 82 packets transmitted per cycle
[ ] Packet start addresses correct (spot check 5)
[ ] Number of registers per packet correct
[ ] Function codes correct (3=read, 6=write)
Cycle time: _______ seconds

Parameter Reading:
[ ] Read-only parameters returning values
[ ] Parameter count shows 163 total
[ ] No parse errors in serial log
[ ] Data values appear reasonable
Problem parameters (if any): ___________________________________________

Write Operations:
[ ] Identified write parameters (access="W" or "RW")
[ ] Sent test write command to one parameter
[ ] Write command reached correct slave
[ ] Feedback parameter updated correctly
[ ] No errors during write operation
Tested param ID: _______

{'='*80}
CLOUD TRANSMISSION (30 minutes)
{'='*80}

Cloud Parameter Identification:
[ ] Device identifies 79 cloud parameters
[ ] JKY.JKA mapping loaded correctly
[ ] JSON key names appear in logs
[ ] Units assigned correctly
Sample parameters checked: ____________________________________________

Cloud Data Transmission:
[ ] Device connects to M-Das cloud server
[ ] Cloud data upload successful
[ ] M-Das dashboard shows device online
[ ] All 79 parameters visible in dashboard
[ ] Data updates at expected interval
Upload interval: _______ seconds

Data Accuracy:
[ ] Spot-checked 5 cloud params against Modbus raw data
[ ] Values match (accounting for multipliers)
[ ] Timestamps are current
[ ] No null or missing values
Checked params: _______________________________________________________

P2/P3 Array Validation:
[ ] P2.MPI has 59 entries (cloud modbus read)
[ ] P2.LBI has 72 entries (local params)
[ ] P2.RPCI has 13 entries (remote write)
[ ] P3.MPI has 97 entries (cloud digital)
[ ] P3.MDI populated correctly
[ ] P3.LBI is empty array []

{'='*80}
ERROR HANDLING & EDGE CASES (30 minutes)
{'='*80}

Slave Communication Failure:
[ ] Disconnected one Modbus slave
[ ] Device continues polling other slaves
[ ] Timeout logged but not fatal
[ ] Reconnected slave - device recovers
Notes: ________________________________________________________________

Invalid Data Handling:
[ ] Observed out-of-range value handling
[ ] No crashes from invalid data
[ ] Multiplier bounds respected
[ ] Format conversion errors handled
Notes: ________________________________________________________________

Configuration Reload During Operation:
[ ] Triggered config reload while running
[ ] Old config completed current cycle
[ ] New config loaded without data loss
[ ] Cloud connection maintained
[ ] No memory errors
Notes: ________________________________________________________________

{'='*80}
PERFORMANCE & STABILITY (Ongoing)
{'='*80}

Short-Term Performance (First Hour):
[ ] No device crashes or resets
[ ] Memory usage stable: _______%
[ ] CPU usage acceptable: _______%
[ ] All 163 params updating: [ ] Yes [ ] No
[ ] Cloud transmission continuous
[ ] Error rate < 1%
Notes: ________________________________________________________________

Long-Term Stability (24 Hours):
Start time: _______________ End time: _______________

[ ] Device ran continuously for 24 hours
[ ] No crashes or unexpected resets
[ ] Memory usage remained stable
[ ] Data consistency maintained
[ ] Cloud uploads continuous
[ ] Performance metrics within targets

Final metrics:
  Uptime: _______ hours
  Total resets: _______
  Error rate: _______%
  Avg cycle time: _______ seconds
  Avg memory: _______%
  Avg CPU: _______%

{'='*80}
DATA ACCURACY VERIFICATION (30 minutes)
{'='*80}

Multiplier Calculations:
[ ] Tested 3 parameters with known multipliers
[ ] Calculated values match expected
[ ] No overflow/underflow errors
Tested params: ________________________________________________________

Write-Feedback Pairs:
[ ] Identified 5 write-feedback pairs
[ ] Wrote test values to write parameters
[ ] Feedback parameters matched within 1 second
[ ] Values accurate (accounting for conversions)
Tested pairs: _________________________________________________________

Cross-Reference Validation:
[ ] Spot-checked 10 random parameters
[ ] Cloud JSON matches Modbus raw data
[ ] Timestamps within expected range
[ ] No data staleness issues
Parameters checked: ___________________________________________________

{'='*80}
FINAL VALIDATION (15 minutes)
{'='*80}

Success Criteria:
[ ] ✅ All 163 parameters poll successfully
[ ] ✅ All 82 packets transmit correctly
[ ] ✅ All 79 cloud parameters reach M-Das
[ ] ✅ Write operations execute correctly
[ ] ✅ Device stable for 24+ hours
[ ] ✅ No configuration-related crashes
[ ] ✅ Data accuracy spot-checks pass
[ ] ✅ Performance metrics acceptable

Overall Result: [ ] PASS [ ] FAIL [ ] NEEDS REVIEW

If FAIL or NEEDS REVIEW, describe issues:
________________________________________________________________________
________________________________________________________________________
________________________________________________________________________
________________________________________________________________________

{'='*80}
POST-VALIDATION (15 minutes)
{'='*80}

Documentation:
[ ] Test results saved to file
[ ] Serial logs archived
[ ] Performance metrics recorded
[ ] Issues documented (if any)
[ ] Photos of setup taken (optional)

Configuration Archive:
[ ] Validated config marked with date
[ ] Backup configuration retained
[ ] Test results linked to config version
[ ] Deployment notes created

Next Steps:
[ ] Deploy to additional devices (if applicable)
[ ] Update system documentation
[ ] Notify stakeholders of results
[ ] Schedule next validation check

{'='*80}
ROLLBACK (If Validation Failed)
{'='*80}

If validation failed, perform rollback:
[ ] Stopped current configuration
[ ] Uploaded backup Modbus_Config.json
[ ] Uploaded backup ParamMap_Config.json
[ ] Triggered configuration reload
[ ] Verified device returns to pre-test behavior
[ ] Collected failure logs for analysis
[ ] Documented failure mode

Rollback performed: [ ] Yes [ ] No [ ] N/A
Rollback successful: [ ] Yes [ ] No [ ] N/A

{'='*80}
SIGNATURES
{'='*80}

Tester: ______________________ Date: ____________ Time: ____________

Reviewer: ____________________ Date: ____________ Time: ____________

Notes/Comments:
________________________________________________________________________
________________________________________________________________________
________________________________________________________________________
________________________________________________________________________

{'='*80}
END OF CHECKLIST
{'='*80}
"""
    return checklist

if __name__ == "__main__":
    checklist = generate_checklist()
    
    # Save to file
    output_file = "Phase_6_Test_Checklist.txt"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(checklist)
    
    print(f"✅ Test checklist generated: {output_file}")
    print(f"📄 Print this file for on-site device testing")
    print(f"⏱️  Estimated total time: 4-6 hours + 24 hour stability test")
