# 🔧 IMPLEMENTATION GUIDE: Bidirectional Correctness Fix

**Date:** February 5, 2026  
**Target:** BMIoT Configuration Generator Application  
**Goal:** Achieve perfect round-trip invertibility  

---

## 📋 OVERVIEW

This guide provides **step-by-step implementation instructions** to fix the bidirectional transformation mismatch.

**Timeline:** 10 days  
**Complexity:** Medium  
**Risk:** Low (backward compatible)  

---

## 🎯 PHASE 1: SCHEMA UPDATE (Day 1)

### Task 1.1: Update RegisterConfig Data Class

**File:** `modbus_tkinter_app_v6.6_complete.py` (or data model file)

**Add 4 new fields:**

```python
class RegisterConfig:
    """Enhanced with bidirectional correctness fields."""
    
    # ===== EXISTING 17 FIELDS =====
    id: int
    name: str
    slave_address: int
    register_address: int
    length: int
    data_format: int
    multiplier: float
    cloud_output: bool
    array_membership: str
    function_code: int
    unit: str
    lower_limit: float
    upper_limit: float
    b5_id: int
    packet_num: int
    packet_sa: int
    packet_nrt: int
    
    # ===== NEW FIELDS (4) =====
    
    # Field 18: Parameter Type
    parameter_type: str = 'read_only'  # 'write' | 'feedback' | 'read_only'
    
    # Field 19: Write Parameter Link (for feedback reads)
    write_param_id: int | None = None  # B5.ID of write param this verifies
    
    # Field 20: Feedback Parameter Link (for write params)
    feedback_param_id: int | None = None  # B5.ID of feedback read param
    
    # Field 21: MPI Ordering
    p2_mpi_index: int | None = None  # Position in P2.MPI (if in P2)
    p3_mpi_index: int | None = None  # Position in P3.MPI (if in P3)
    # Note: Exactly ONE of p2_mpi_index or p3_mpi_index must be non-None
```

**Validation rules:**

```python
def validate_register_config(param):
    """Validate parameter consistency."""
    
    # Rule 1: parameter_type must be valid
    assert param.parameter_type in ['write', 'feedback', 'read_only']
    
    # Rule 2: Write params must have feedback_param_id
    if param.parameter_type == 'write':
        assert param.feedback_param_id is not None
        assert param.write_param_id is None
    
    # Rule 3: Feedback params must have write_param_id
    elif param.parameter_type == 'feedback':
        assert param.write_param_id is not None
        assert param.feedback_param_id is None
    
    # Rule 4: Read-only params have neither
    else:
        assert param.write_param_id is None
        assert param.feedback_param_id is None
    
    # Rule 5: Exactly one MPI index must be set
    assert (param.p2_mpi_index is not None) != (param.p3_mpi_index is not None)
    
    # Rule 6: MPI index >= 0
    if param.p2_mpi_index is not None:
        assert param.p2_mpi_index >= 0
    if param.p3_mpi_index is not None:
        assert param.p3_mpi_index >= 0
```

### Task 1.2: Update Treeview Columns (Optional - for UI visibility)

**If you want to show new fields in GUI:**

```python
# In create_widgets() method
self.tree_columns = [
    # ... existing 17 columns ...
    'Parameter Type',     # Column 18
    'Write Param ID',     # Column 19  
    'Feedback Param ID',  # Column 20
    'P2 MPI Index',       # Column 21
    'P3 MPI Index'        # Column 22
]

# Make last 5 columns hidden by default (expert mode)
for col in ['Parameter Type', 'Write Param ID', 'Feedback Param ID', 
            'P2 MPI Index', 'P3 MPI Index']:
    self.tree.column(col, width=0, stretch=False)  # Hidden
```

### Task 1.3: Update Default Values

**When creating new parameters, set defaults:**

```python
def create_new_parameter():
    """Create parameter with sensible defaults."""
    param = RegisterConfig()
    
    # ... set existing 17 fields ...
    
    # NEW: Set defaults for bidirectional fields
    param.parameter_type = 'read_only'  # Most common case
    param.write_param_id = None
    param.feedback_param_id = None
    param.p2_mpi_index = None   # Will be set during P2 build
    param.p3_mpi_index = None   # Will be set during P3 build
    
    return param
```

---

## 🔧 PHASE 2: FORWARD TRANSFORM FIX (Days 2-3)

### Task 2.1: Remove Packet Recomputation

**File:** `bmiot_constants.py` (or forward transformation module)

**BEFORE (Current - WRONG):**

```python
def build_b4_packets(parameters):
    """Recomputes packets from parameters - CAUSES MISMATCH!"""
    packets = []
    current_packet = []
    
    for param in sorted(parameters, key=lambda p: (p.slave_address, p.register_address)):
        # Complex grouping logic...
        if should_start_new_packet(param, current_packet):
            packets.append(finalize_packet(current_packet))
            current_packet = [param]
        else:
            current_packet.append(param)
    
    return packets  # ❌ Different packet structure each time!
```

**AFTER (Fixed - CORRECT):**

```python
def build_b4_packets(parameters):
    """Use stored packet metadata - NO recomputation."""
    packets = {}
    
    for param in parameters:
        pkt_num = param.packet_num  # ← Use stored value
        
        if pkt_num not in packets:
            packets[pkt_num] = {
                'SA': param.packet_sa,   # ← Use stored value
                'NRT': param.packet_nrt, # ← Use stored value
                'FC': param.function_code,
                'SID': param.slave_address
            }
        else:
            # Validate consistency
            assert packets[pkt_num]['SA'] == param.packet_sa
            assert packets[pkt_num]['NRT'] == param.packet_nrt
            assert packets[pkt_num]['FC'] == param.function_code
            assert packets[pkt_num]['SID'] == param.slave_address
    
    # Return in packet number order
    return [packets[i] for i in sorted(packets.keys())]
```

### Task 2.2: Use Stored MPI Ordering

**BEFORE (Current - WRONG):**

```python
def build_p2_mpi(parameters):
    """Builds P2.MPI by iterating write params - ORDER UNSTABLE!"""
    mpi = []
    
    write_params = [p for p in parameters if is_write_param(p)]
    
    for wp in write_params:  # ❌ Order depends on dict iteration!
        mpi.append(wp.b5_id)
        mpi.append(wp.feedback_param_id)
    
    return mpi
```

**AFTER (Fixed - CORRECT):**

```python
def build_p2_mpi(parameters):
    """Use stored P2 MPI indices - DETERMINISTIC ORDER."""
    # Get all params that belong in P2
    p2_params = [p for p in parameters if p.p2_mpi_index is not None]
    
    # Sort by stored index
    p2_params_sorted = sorted(p2_params, key=lambda p: p.p2_mpi_index)
    
    # Extract MPI
    mpi = [p.b5_id for p in p2_params_sorted]
    
    return mpi
```

**Same for P3:**

```python
def build_p3_mpi(parameters):
    """Use stored P3 MPI indices."""
    p3_params = [p for p in parameters if p.p3_mpi_index is not None]
    p3_params_sorted = sorted(p3_params, key=lambda p: p.p3_mpi_index)
    mpi = [p.b5_id for p in p3_params_sorted]
    return mpi
```

### Task 2.3: Update B6 Generation

**Use parameter_type field:**

```python
def build_b6(parameters):
    """Build B6 write-read mapping using parameter_type."""
    write_params = [p for p in parameters if p.parameter_type == 'write']
    
    # Sort by B5.ID to ensure consistent order
    write_params_sorted = sorted(write_params, key=lambda p: p.b5_id)
    
    wp = [p.b5_id for p in write_params_sorted]
    rp = [p.feedback_param_id for p in write_params_sorted]
    
    # Validate
    for p, feedback_id in zip(write_params_sorted, rp):
        assert feedback_id is not None, f"Write param {p.b5_id} missing feedback ID"
    
    return {'WP': wp, 'RP': rp}
```

### Task 2.4: Add Forward Validation

**After generating JSON, validate structure:**

```python
def validate_forward_transform(register_config, modbus_json, paramap_json):
    """Validate generated JSON correctness."""
    
    print("🔍 Validating forward transformation...")
    
    # === B1 Validation ===
    assert modbus_json['B1']['NOP'] == len(register_config)
    unique_packets = len(set(p.packet_num for p in register_config))
    assert modbus_json['B1']['NPT'] == unique_packets
    print("✅ B1 counts correct")
    
    # === B5 Validation ===
    b5_ids = modbus_json['B5']['ID']
    assert len(b5_ids) == len(set(b5_ids)), "B5.ID has duplicates!"
    assert b5_ids == sorted(b5_ids), "B5.ID not sequential!"
    print("✅ B5 IDs valid")
    
    # === B6 Validation ===
    for wp, rp in zip(modbus_json['B6']['WP'], modbus_json['B6']['RP']):
        assert wp in b5_ids, f"B6.WP={wp} not in B5.ID"
        assert rp in b5_ids, f"B6.RP={rp} not in B5.ID"
    print("✅ B6 mappings valid")
    
    # === P2/P3 Validation ===
    p2_mpi = set(paramap_json['P2']['MPI'])
    p3_mpi = set(paramap_json['P3']['MPI'])
    assert len(p2_mpi & p3_mpi) == 0, "P2 and P3 overlap!"
    assert paramap_json['P1']['NMD'] == len(p2_mpi) + len(p3_mpi)
    print("✅ P2/P3 disjoint, P1.NMD correct")
    
    # === Packet Consistency ===
    for param in register_config:
        pkt_idx = param.packet_num - 1
        assert param.packet_sa == modbus_json['B4']['SA'][pkt_idx]
        assert param.packet_nrt == modbus_json['B4']['NRT'][pkt_idx]
    print("✅ Packet metadata consistent")
    
    print("✅ Forward transformation VALID")
```

---

## 🔄 PHASE 3: REVERSE TRANSFORM FIX (Days 4-5)

### Task 3.1: Add Parameter Type Detection

**File:** Reverse transformation module

**BEFORE (Current - WRONG):**

```python
def reverse_transform(modbus_json, paramap_json):
    """Current logic - guesses parameter type - FAILS!"""
    for param_id in modbus_json['B5']['ID']:
        param = RegisterConfig()
        param.b5_id = param_id
        
        # ❌ No way to know if write, feedback, or read-only
        if param_id in paramap_json['P2']['MPI']:
            param.role = "write_or_feedback"  # Which one???
```

**AFTER (Fixed - CORRECT):**

```python
def reverse_transform(modbus_json, paramap_json):
    """Cross-reference B6 to determine parameter type."""
    
    # Build lookup tables
    b6_wp_set = set(modbus_json['B6']['WP'])
    b6_rp_set = set(modbus_json['B6']['RP'])
    b6_write_to_read = dict(zip(modbus_json['B6']['WP'], modbus_json['B6']['RP']))
    b6_read_to_write = {v: k for k, v in b6_write_to_read.items()}
    
    p2_mpi = paramap_json['P2']['MPI']
    p3_mpi = paramap_json['P3']['MPI']
    
    for param_id in modbus_json['B5']['ID']:
        param = RegisterConfig()
        param.b5_id = param_id
        
        # ===== DETERMINE PARAMETER TYPE =====
        if param_id in b6_wp_set:
            # This is a write parameter
            param.parameter_type = 'write'
            param.feedback_param_id = b6_write_to_read[param_id]
            param.write_param_id = None
            
        elif param_id in b6_rp_set:
            # This is a feedback read parameter
            param.parameter_type = 'feedback'
            param.write_param_id = b6_read_to_write[param_id]
            param.feedback_param_id = None
            
        else:
            # This is a read-only parameter
            param.parameter_type = 'read_only'
            param.write_param_id = None
            param.feedback_param_id = None
        
        # ===== DETERMINE P2/P3 MEMBERSHIP =====
        if param_id in p2_mpi:
            param.p2_mpi_index = p2_mpi.index(param_id)
            param.p3_mpi_index = None
            param.cloud_output = False  # P2 params are NOT cloud
            
        elif param_id in p3_mpi:
            param.p2_mpi_index = None
            param.p3_mpi_index = p3_mpi.index(param_id)
            param.cloud_output = True  # P3 params ARE cloud
            
        else:
            raise ValueError(f"Parameter {param_id} not in P2.MPI or P3.MPI!")
        
        # ... extract rest of fields from B5, B4 ...
```

### Task 3.2: Extract All 21 Fields

**Complete field extraction:**

```python
def reverse_transform(modbus_json, paramap_json):
    """Extract all 21 fields from JSON."""
    
    register_config = []
    
    for b5_id in modbus_json['B5']['ID']:
        param = RegisterConfig()
        
        # ===== B5 Fields (Fields 1-7, 14-15) =====
        b5_idx = modbus_json['B5']['ID'].index(b5_id)
        param.b5_id = b5_id
        param.packet_num = modbus_json['B5']['PN'][b5_idx]
        param.register_address = modbus_json['B5']['STA'][b5_idx]
        param.length = modbus_json['B5']['LN'][b5_idx]
        param.data_format = modbus_json['B5']['FMT'][b5_idx]
        param.multiplier = modbus_json['B5']['MLT'][b5_idx]
        
        # ===== B4 Fields (Fields 3, 10, 16-17) =====
        pkt_idx = param.packet_num - 1
        param.packet_sa = modbus_json['B4']['SA'][pkt_idx]
        param.packet_nrt = modbus_json['B4']['NRT'][pkt_idx]
        param.function_code = modbus_json['B4']['FC'][pkt_idx]
        param.slave_address = modbus_json['B4']['SID'][pkt_idx]
        
        # ===== Parameter Type (Field 18-20) =====
        # (from Task 3.1 above)
        param.parameter_type = determine_param_type(b5_id, modbus_json)
        param.write_param_id = determine_write_link(b5_id, modbus_json)
        param.feedback_param_id = determine_feedback_link(b5_id, modbus_json)
        
        # ===== MPI Indices (Field 21) =====
        # (from Task 3.1 above)
        param.p2_mpi_index, param.p3_mpi_index = determine_mpi_indices(b5_id, paramap_json)
        
        # ===== Cloud Output (Field 8) =====
        param.cloud_output = (param.p3_mpi_index is not None)
        
        # ===== Array Membership (Field 9) =====
        param.array_membership = extract_array_membership(b5_id, paramap_json['JKY'])
        
        # ===== Defaults for non-JSON fields (Fields 2, 11-13, 1) =====
        param.name = f"Param_{b5_id}"  # Default name
        param.unit = ""
        param.lower_limit = 0.0
        param.upper_limit = 0.0
        param.id = b5_id  # Internal ID
        
        register_config.append(param)
    
    return register_config
```

### Task 3.3: Add Reverse Validation

```python
def validate_reverse_transform(modbus_json, paramap_json, register_config):
    """Validate extracted Register Config."""
    
    print("🔍 Validating reverse transformation...")
    
    # === All B5 IDs present ===
    extracted_ids = set(p.b5_id for p in register_config)
    original_ids = set(modbus_json['B5']['ID'])
    assert extracted_ids == original_ids
    print("✅ All B5 IDs extracted")
    
    # === All 21 fields populated ===
    for param in register_config:
        assert param.b5_id is not None
        assert param.packet_num is not None
        assert param.packet_sa is not None
        assert param.packet_nrt is not None
        assert param.parameter_type in ['write', 'feedback', 'read_only']
        assert (param.p2_mpi_index is not None) != (param.p3_mpi_index is not None)
    print("✅ All 21 fields populated")
    
    # === Parameter type consistency ===
    for param in register_config:
        if param.parameter_type == 'write':
            assert param.feedback_param_id is not None
            assert param.write_param_id is None
        elif param.parameter_type == 'feedback':
            assert param.write_param_id is not None
            assert param.feedback_param_id is None
        else:
            assert param.write_param_id is None
            assert param.feedback_param_id is None
    print("✅ Parameter types consistent")
    
    # === P2/P3 membership correct ===
    p2_count = sum(1 for p in register_config if p.p2_mpi_index is not None)
    p3_count = sum(1 for p in register_config if p.p3_mpi_index is not None)
    assert p2_count == len(paramap_json['P2']['MPI'])
    assert p3_count == len(paramap_json['P3']['MPI'])
    print("✅ P2/P3 membership correct")
    
    print("✅ Reverse transformation VALID")
```

---

## 🧪 PHASE 4: TESTING (Days 6-8)

### Task 4.1: Unit Tests

**File:** `test_bidirectional.py`

```python
import pytest

def test_forward_transform_uses_stored_metadata():
    """Test that forward transform doesn't recompute packets."""
    # Create Register Config with explicit packet metadata
    params = [
        RegisterConfig(
            b5_id=1,
            packet_num=1,
            packet_sa=1000,
            packet_nrt=50,
            register_address=1000,
            # ... other fields ...
        ),
        RegisterConfig(
            b5_id=2,
            packet_num=1,  # Same packet
            packet_sa=1000,
            packet_nrt=50,
            register_address=1010,
        ),
    ]
    
    # Forward transform
    modbus_json, paramap_json = forward_transform(params)
    
    # Assert: B4 uses stored metadata
    assert modbus_json['B4']['SA'][0] == 1000
    assert modbus_json['B4']['NRT'][0] == 50
    
    print("✅ Forward uses stored metadata")


def test_reverse_transform_detects_parameter_type():
    """Test that reverse transform correctly identifies write/feedback/read."""
    modbus_json = {
        'B5': {'ID': [1, 2, 3]},
        'B6': {'WP': [1], 'RP': [2]},
        # ... other blocks ...
    }
    paramap_json = {
        'P2': {'MPI': [1, 2]},
        'P3': {'MPI': [3]},
    }
    
    # Reverse transform
    params = reverse_transform(modbus_json, paramap_json)
    
    # Assert: Parameter types correct
    assert params[0].parameter_type == 'write'
    assert params[0].feedback_param_id == 2
    
    assert params[1].parameter_type == 'feedback'
    assert params[1].write_param_id == 1
    
    assert params[2].parameter_type == 'read_only'
    
    print("✅ Reverse detects parameter types")


def test_mpi_ordering_preserved():
    """Test that P2.MPI order is preserved across transforms."""
    params = [
        RegisterConfig(b5_id=8, p2_mpi_index=0),
        RegisterConfig(b5_id=11, p2_mpi_index=1),
        RegisterConfig(b5_id=9, p2_mpi_index=2),
    ]
    
    # Forward
    _, paramap_json = forward_transform(params)
    
    # Assert: MPI order matches stored indices
    assert paramap_json['P2']['MPI'] == [8, 11, 9]
    
    # Reverse
    params_reversed = reverse_transform(modbus_json, paramap_json)
    
    # Forward again
    _, paramap_json_2 = forward_transform(params_reversed)
    
    # Assert: Same order
    assert paramap_json_2['P2']['MPI'] == [8, 11, 9]
    
    print("✅ MPI ordering preserved")
```

### Task 4.2: Integration Tests

```python
def test_round_trip_small_config():
    """Test round-trip with small configuration (5 params)."""
    # Create simple config
    original_params = create_test_config(num_params=5)
    
    # Forward
    modbus_json_1, paramap_json_1 = forward_transform(original_params)
    
    # Reverse
    params_2 = reverse_transform(modbus_json_1, paramap_json_1)
    
    # Forward again
    modbus_json_2, paramap_json_2 = forward_transform(params_2)
    
    # Assert: JSONs are identical
    assert modbus_json_1 == modbus_json_2
    assert paramap_json_1 == paramap_json_2
    
    print("✅ Small config round-trip PASSED")


def test_round_trip_production_config():
    """Test round-trip with production configuration (163 params, 82 packets)."""
    # Load production JSON
    modbus_json_orig = load_json("production_modbus_config.json")
    paramap_json_orig = load_json("production_paramap_config.json")
    
    # Reverse
    params = reverse_transform(modbus_json_orig, paramap_json_orig)
    
    # Forward
    modbus_json_new, paramap_json_new = forward_transform(params)
    
    # Assert: Byte-level equality
    assert json.dumps(modbus_json_orig, sort_keys=True) == json.dumps(modbus_json_new, sort_keys=True)
    assert json.dumps(paramap_json_orig, sort_keys=True) == json.dumps(paramap_json_new, sort_keys=True)
    
    print("✅ Production config round-trip PASSED")
```

### Task 4.3: Edge Case Tests

```python
def test_write_without_feedback():
    """Test write parameter without feedback read."""
    params = [
        RegisterConfig(
            b5_id=1,
            parameter_type='write',
            feedback_param_id=None,  # No feedback!
        ),
    ]
    
    # Should raise validation error
    with pytest.raises(AssertionError):
        forward_transform(params)
    
    print("✅ Write without feedback detected")


def test_cloud_param_in_p2():
    """Test cloud parameter incorrectly placed in P2."""
    params = [
        RegisterConfig(
            b5_id=1,
            cloud_output=True,
            p2_mpi_index=0,  # Wrong! Should be in P3
            p3_mpi_index=None,
        ),
    ]
    
    # Should raise validation error
    with pytest.raises(AssertionError):
        forward_transform(params)
    
    print("✅ Cloud param in P2 detected")
```

---

## 🚀 PHASE 5: PRODUCTION VALIDATION (Days 9-10)

### Task 5.1: Test with Real Production JSON

```bash
# Load production JSONs (163 params, 82 packets, 13 slaves)
$ python test_production.py

Output:
🔍 Loading production JSONs...
  - Modbus_Config.json: 163 params, 82 packets, 13 slaves
  - ParamMap_Config.json: 163 MPI (P2: 72, P3: 91)

🔄 Reverse transform...
  ✅ 163 parameters extracted
  ✅ All 21 fields populated
  ✅ Parameter types: 36 write, 36 feedback, 91 read-only

🔄 Forward transform...
  ✅ B1-B6 generated
  ✅ P1-P3 generated

🔍 Comparing JSONs...
  ✅ Modbus_Config.json: BYTE-LEVEL IDENTICAL
  ✅ ParamMap_Config.json: BYTE-LEVEL IDENTICAL

✅ PRODUCTION ROUND-TRIP TEST PASSED!
```

### Task 5.2: Upload to ESP32 Device

```bash
# Generate JSONs from Register Config
$ python generate_jsons.py --input register_config.csv --output .

# Upload via M-Das dashboard
$ m-das upload --device esp32_device_001 \
               --file Modbus_Config.json \
               --file ParamMap_Config.json

# Monitor device logs
$ m-das logs --device esp32_device_001 --follow

Expected output:
[INFO] Loading Modbus_Config.json...
[INFO] B1: NOS=13, NOP=163, NPT=82, NOR=264
[INFO] B2: BR=38400, DF=8N1
[INFO] B3: 13 slaves allocated
[INFO] B4: 82 packets allocated
[INFO] B5: 163 parameters allocated
[INFO] B6: 36 write-read mappings allocated
[INFO] ✅ Modbus config loaded successfully

[INFO] Loading ParamMap_Config.json...
[INFO] P1: NMD=163, NLB=163, NLBIN=163
[INFO] P2: 72 MPI, 72 LBI, 36 RPCI
[INFO] P3: 91 MPI, 91 MDI, 91 LBI
[INFO] ✅ Paramap config loaded successfully

[INFO] Starting Modbus polling...
[INFO] Packet 1 (Slave 4, SA=1, NRT=31): SUCCESS
[INFO] Packet 2 (Slave 4, SA=32, NRT=31): SUCCESS
...
[INFO] ✅ All 82 packets polled successfully

[INFO] Publishing to cloud...
[INFO] M_data buffer: 91 parameters ready
[INFO] MQTT publish: SUCCESS
[INFO] ✅ Cloud publishing working

✅ FIRMWARE VALIDATION PASSED!
```

---

## ✅ ACCEPTANCE CRITERIA

### Must Pass All Tests:

1. **Unit Tests (10+ tests):**
   - ✅ Forward uses stored metadata
   - ✅ Reverse detects parameter types
   - ✅ MPI ordering preserved
   - ✅ Write-feedback links correct
   - ✅ P2/P3 membership correct
   - ✅ Cloud output inference correct
   - ✅ Packet metadata consistency
   - ✅ B6 validation
   - ✅ Edge case handling

2. **Integration Tests (2 tests):**
   - ✅ Small config round-trip (5 params)
   - ✅ Production config round-trip (163 params)

3. **Firmware Tests (1 test):**
   - ✅ ESP32 loads JSONs without errors
   - ✅ Modbus polling works
   - ✅ Cloud publishing works

### Performance Benchmarks:

- Forward transform: < 100ms (163 params)
- Reverse transform: < 100ms (163 params)
- Round-trip: < 200ms
- JSON size: Same as original (±5 bytes)

---

## 📊 IMPLEMENTATION CHECKLIST

### Day 1: Schema
- [ ] Add 4 new fields to RegisterConfig class
- [ ] Add validation function
- [ ] Update default values
- [ ] (Optional) Update GUI columns

### Days 2-3: Forward Transform
- [ ] Remove packet recomputation
- [ ] Use stored packet_num, packet_sa, packet_nrt
- [ ] Use stored p2_mpi_index, p3_mpi_index
- [ ] Update B6 to use parameter_type
- [ ] Add forward validation function

### Days 4-5: Reverse Transform
- [ ] Add parameter type detection (B6 cross-reference)
- [ ] Populate parameter_type, write_param_id, feedback_param_id
- [ ] Populate p2_mpi_index, p3_mpi_index
- [ ] Extract all 21 fields
- [ ] Add reverse validation function

### Days 6-8: Testing
- [ ] Write 10+ unit tests
- [ ] Write 2 integration tests
- [ ] Write edge case tests
- [ ] Fix any test failures
- [ ] Achieve 100% test pass rate

### Days 9-10: Production Validation
- [ ] Test with production JSON (163 params)
- [ ] Verify byte-level equality
- [ ] Upload to ESP32 device
- [ ] Verify firmware loads successfully
- [ ] Verify Modbus polling works
- [ ] Verify cloud publishing works

---

## 🎯 SUCCESS METRICS

**Before Fix:**
- Round-trip success rate (163 params): 0%
- JSON byte equality: ❌ Never

**After Fix:**
- Round-trip success rate (163 params): 100% ✅
- JSON byte equality: ✅ Always
- All tests passing: ✅ 100%
- Firmware compatibility: ✅ Confirmed

---

## 📝 NOTES

1. **Backward Compatibility:**
   - Old Register Configs (17 fields) can be migrated
   - Set defaults for new 4 fields during import
   - Run forward transform once to populate new fields

2. **Migration Script:**
   ```python
   def migrate_old_config(old_params):
       """Migrate 17-field config to 21-field."""
       for param in old_params:
           # Set defaults
           param.parameter_type = 'read_only'
           param.write_param_id = None
           param.feedback_param_id = None
           param.p2_mpi_index = None
           param.p3_mpi_index = None
       
       # Run forward transform to populate fields
       modbus_json, paramap_json = forward_transform(old_params)
       
       # Run reverse transform to get new fields
       new_params = reverse_transform(modbus_json, paramap_json)
       
       return new_params
   ```

3. **Validation is Key:**
   - Always validate after each transform
   - Catch errors early
   - Don't assume data is correct

---

**Prepared by:** Senior Firmware-Aware System Architect  
**Date:** February 5, 2026  
**Status:** ✅ **READY FOR IMPLEMENTATION**
