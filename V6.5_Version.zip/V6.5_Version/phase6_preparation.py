"""
Quick Device Status Checker
Run this script to verify device configuration after upload
Connects via serial or network to check basic status
"""

import json
import sys
from pathlib import Path

def check_configuration_files():
    """Verify configuration files are ready for upload"""
    print("="*70)
    print("CONFIGURATION FILE VALIDATION")
    print("="*70)
    
    data_path = Path("../Thermelgy-Gateway-BMIoT/data")
    
    files_to_check = [
        ("Modbus_Config.json", "Modbus Configuration"),
        ("ParamMap_Config.json", "Parameter Mapping")
    ]
    
    all_valid = True
    
    for filename, description in files_to_check:
        filepath = data_path / filename
        print(f"\nChecking: {description}")
        print(f"  File: {filepath}")
        
        if not filepath.exists():
            print(f"  ❌ File not found!")
            all_valid = False
            continue
        
        try:
            with open(filepath, 'r') as f:
                config = json.load(f)
            
            file_size = filepath.stat().st_size
            print(f"  ✅ Valid JSON")
            print(f"  📦 Size: {file_size:,} bytes")
            
            # Check Modbus config
            if filename == "Modbus_Config.json":
                b1 = config.get("B1", {})
                b5 = config.get("B5", {})
                
                nop = b1.get("NOP", 0)
                npt = b1.get("NPT", 0)
                nos = b1.get("NOS", 0)
                
                b5_params = len(b5.get("ID", []))
                
                print(f"  📊 Parameters: {nop} (B5 has {b5_params})")
                print(f"  📦 Packets: {npt}")
                print(f"  🔌 Slaves: {nos}")
                
                if b5_params != nop:
                    print(f"  ⚠️  Warning: B1.NOP ({nop}) != B5.ID count ({b5_params})")
                
                # Check field names
                if "STA" in b5:
                    print(f"  ✅ Production format (STA/MLT)")
                elif "AD" in b5:
                    print(f"  ℹ️  Legacy format (AD/MP)")
            
            # Check ParamMap config
            if filename == "ParamMap_Config.json":
                p1 = config.get("P1", {})
                p2 = config.get("P2", {})
                p3 = config.get("P3", {})
                jky = config.get("JKY", {})
                
                nlb = p1.get("NLB", 0)
                nmd = p1.get("NMD", 0)
                
                p2_mpi = len(p2.get("MPI", []))
                p2_lbi = len(p2.get("LBI", []))
                p3_mpi = len(p3.get("MPI", []))
                
                print(f"  📊 Local params: {nlb}")
                print(f"  📊 Modbus digital: {nmd}")
                print(f"  📊 P2.MPI: {p2_mpi} (cloud read)")
                print(f"  📊 P2.LBI: {p2_lbi} (local)")
                print(f"  📊 P3.MPI: {p3_mpi} (cloud digital)")
                
                # Check JKY format
                if "JKA" in jky:
                    jka_count = len(jky["JKA"])
                    print(f"  ✅ Production format (JKA)")
                    print(f"  ☁️  Cloud params: {jka_count}")
                elif "JK" in jky:
                    jk_count = len(jky["JK"])
                    print(f"  ℹ️  Legacy format (JK)")
                    print(f"  ☁️  Cloud params: {jk_count}")
                
        except json.JSONDecodeError as e:
            print(f"  ❌ Invalid JSON: {e}")
            all_valid = False
        except Exception as e:
            print(f"  ❌ Error: {e}")
            all_valid = False
    
    print("\n" + "="*70)
    if all_valid:
        print("✅ All configuration files are valid and ready for upload")
        return 0
    else:
        print("❌ Some configuration files have issues")
        return 1

def print_upload_instructions():
    """Print step-by-step upload instructions"""
    print("\n" + "="*70)
    print("UPLOAD INSTRUCTIONS")
    print("="*70)
    print("""
1. Access M-Das OTA Interface:
   - Open web browser
   - Navigate to M-Das OTA portal
   - Login with credentials

2. Select Target Device:
   - Find device by MAC address or device ID
   - Verify device is online
   - Check current firmware version

3. Upload Modbus_Config.json:
   - Click "Upload Configuration" button
   - Select Modbus_Config.json from:
     Thermelgy-Gateway-BMIoT/data/Modbus_Config.json
   - Wait for upload confirmation
   - Verify file checksum/size

4. Upload ParamMap_Config.json:
   - Click "Upload Configuration" button
   - Select ParamMap_Config.json from:
     Thermelgy-Gateway-BMIoT/data/ParamMap_Config.json
   - Wait for upload confirmation
   - Verify file checksum/size

5. Trigger Configuration Reload:
   - Send reload command via M-Das
   - Or reboot device if required
   - Monitor device logs during reload

6. Verify Upload Success:
   - Check device status shows 163 parameters
   - Check device status shows 82 packets
   - Check device status shows 13 slaves
   - Monitor for any error messages
""")

def print_quick_tests():
    """Print quick validation tests"""
    print("\n" + "="*70)
    print("QUICK VALIDATION TESTS")
    print("="*70)
    print("""
After configuration upload, perform these quick checks:

1. Device Status (2 minutes):
   □ Device shows online status
   □ Configuration loaded without errors
   □ Parameter count: 163
   □ Packet count: 82
   □ Slave count: 13

2. Modbus Communication (5 minutes):
   □ Modbus polling initiated
   □ At least one slave responds
   □ No repeated errors in logs
   □ Data values updating

3. Cloud Transmission (5 minutes):
   □ Device visible in M-Das dashboard
   □ Cloud data uploading
   □ At least some of 79 parameters visible
   □ No connection errors

If all quick tests pass, proceed with full Phase 6 validation checklist.

If any test fails:
   → Check Phase_6_Validation_Guide.md troubleshooting section
   → Review device serial logs
   → Consider rollback to previous configuration
""")

def main():
    """Main execution"""
    print("\n" + "="*70)
    print("PHASE 6 DEVICE VALIDATION - PREPARATION")
    print("="*70)
    print("This tool helps prepare for on-site device testing")
    print()
    
    # Check configuration files
    result = check_configuration_files()
    
    # Print instructions
    print_upload_instructions()
    print_quick_tests()
    
    # Print file locations
    print("\n" + "="*70)
    print("REFERENCE DOCUMENTS")
    print("="*70)
    print("""
📋 Phase_6_Validation_Guide.md
   - Comprehensive test procedures
   - Troubleshooting guide
   - Success criteria

📋 Phase_6_Test_Checklist.txt
   - Printable checklist for on-site testing
   - Step-by-step validation tasks
   - Sign-off sheet

📋 Phase_5_Completion_Report.md
   - Results from production-scale testing
   - 100% round-trip validation proof
   - Technical details
""")
    
    print("\n" + "="*70)
    print("NEXT STEPS")
    print("="*70)
    print("""
1. Review Phase_6_Validation_Guide.md
2. Print Phase_6_Test_Checklist.txt
3. Backup current device configuration
4. Upload validated configuration files
5. Execute validation tests from checklist
6. Document results

Estimated time: 4-6 hours + 24 hour stability test
""")
    
    return result

if __name__ == "__main__":
    sys.exit(main())
