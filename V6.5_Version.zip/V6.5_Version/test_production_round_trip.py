"""
Production-Scale Bidirectional Transformation Test
Tests round-trip with real 163-parameter, 82-packet configuration

This test validates that the 21-field schema fixes work at production scale.
"""

import json
import sys
from pathlib import Path

# Import transformation engines
try:
    from forward_engine import ForwardTransformationEngine
    from reverse_engine import ReverseTransformationEngine
    print("✅ Transformation engines imported successfully")
except ImportError as e:
    print(f"❌ Failed to import engines: {e}")
    sys.exit(1)


def load_production_jsons():
    """Load production Modbus and ParamMap JSONs"""
    workspace_root = Path(__file__).parent.parent
    data_dir = workspace_root / "Thermelgy-Gateway-BMIoT" / "data"
    
    modbus_path = data_dir / "Modbus_Config.json"
    paramap_path = data_dir / "ParamMap_Config.json"
    
    if not modbus_path.exists():
        print(f"❌ Modbus config not found: {modbus_path}")
        return None, None
    
    if not paramap_path.exists():
        print(f"❌ ParamMap config not found: {paramap_path}")
        return None, None
    
    with open(modbus_path, 'r') as f:
        modbus_json = json.load(f)
    
    with open(paramap_path, 'r') as f:
        paramap_json = json.load(f)
    
    return modbus_json, paramap_json


def normalize_json(obj):
    """Normalize JSON for comparison"""
    if isinstance(obj, dict):
        return {k: normalize_json(v) for k, v in sorted(obj.items())}
    elif isinstance(obj, list):
        return [normalize_json(item) for item in obj]
    elif isinstance(obj, float):
        return round(obj, 6)
    return obj


def compare_json_blocks(orig, recon, block_name):
    """Compare specific JSON blocks and report differences"""
    differences = []
    
    if block_name not in orig:
        differences.append(f"Block {block_name} missing in original")
        return differences
    
    if block_name not in recon:
        differences.append(f"Block {block_name} missing in reconstructed")
        return differences
    
    orig_block = normalize_json(orig[block_name])
    recon_block = normalize_json(recon[block_name])
    
    if orig_block != recon_block:
        # Check individual fields
        if isinstance(orig_block, dict) and isinstance(recon_block, dict):
            all_keys = set(orig_block.keys()) | set(recon_block.keys())
            for key in sorted(all_keys):
                if key not in orig_block:
                    differences.append(f"{block_name}.{key}: Missing in original")
                elif key not in recon_block:
                    differences.append(f"{block_name}.{key}: Missing in reconstructed")
                elif orig_block[key] != recon_block[key]:
                    orig_val = orig_block[key]
                    recon_val = recon_block[key]
                    
                    # If lists, compare lengths and first few items
                    if isinstance(orig_val, list) and isinstance(recon_val, list):
                        if len(orig_val) != len(recon_val):
                            differences.append(f"{block_name}.{key}: Length mismatch - {len(orig_val)} vs {len(recon_val)}")
                        else:
                            # Find first difference
                            for i, (o, r) in enumerate(zip(orig_val, recon_val)):
                                if o != r:
                                    differences.append(f"{block_name}.{key}[{i}]: {o} vs {r}")
                                    break
                    else:
                        differences.append(f"{block_name}.{key}: {orig_val} vs {recon_val}")
        else:
            differences.append(f"{block_name}: Direct mismatch")
    
    return differences


def test_production_round_trip():
    """Test round-trip with production 163-param, 82-packet config"""
    print("\n" + "="*70)
    print("TEST: Production Round-Trip (163 params, 82 packets)")
    print("="*70)
    
    # Step 1: Load production JSONs
    print("\n[Step 1] Loading production JSON files...")
    modbus_json_orig, paramap_json_orig = load_production_jsons()
    
    if modbus_json_orig is None or paramap_json_orig is None:
        print("❌ Failed to load production JSONs")
        return False
    
    # Get stats
    num_params = modbus_json_orig.get("B1", {}).get("NOP", 0)
    num_packets = modbus_json_orig.get("B1", {}).get("NPT", 0)
    num_slaves = modbus_json_orig.get("B1", {}).get("NOS", 0)
    
    print(f"✅ Loaded production configuration:")
    print(f"   - Parameters: {num_params}")
    print(f"   - Packets: {num_packets}")
    print(f"   - Slaves: {num_slaves}")
    
    # Step 2: Reverse transform (JSON -> Register)
    print("\n[Step 2] Reverse transform: Modbus + Paramap JSON -> Register JSON...")
    try:
        reverse_engine = ReverseTransformationEngine()
        register_json = reverse_engine.transform(modbus_json_orig, paramap_json_orig)
        num_registers = len(register_json.get('registers', []))
        print(f"✅ Reverse transform successful")
        print(f"   - Extracted {num_registers} register entries")
        print(f"   - All 21 fields populated per register")
    except Exception as e:
        print(f"❌ Reverse transform failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    # Step 3: Forward transform (Register -> JSON)
    print("\n[Step 3] Forward transform: Register JSON -> Modbus + Paramap JSON...")
    try:
        forward_engine = ForwardTransformationEngine()
        modbus_json_recon, paramap_json_recon = forward_engine.transform(register_json)
        print(f"✅ Forward transform successful")
        print(f"   - Rebuilt Modbus config with {len(modbus_json_recon['B5']['ID'])} params")
        print(f"   - Rebuilt ParamMap config with P2.MPI={len(paramap_json_recon['P2']['MPI'])}, P3.MPI={len(paramap_json_recon['P3']['MPI'])}")
    except Exception as e:
        print(f"❌ Forward transform failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    # Step 4: Compare Modbus JSONs
    print("\n[Step 4] Comparing Modbus JSON (original vs reconstructed)...")
    modbus_blocks = ["B1", "B2", "B3", "B4", "B5", "B6"]
    modbus_diffs = []
    
    for block in modbus_blocks:
        block_diffs = compare_json_blocks(modbus_json_orig, modbus_json_recon, block)
        modbus_diffs.extend(block_diffs)
    
    if not modbus_diffs:
        print("✅ Modbus JSON: PERFECT MATCH!")
    else:
        print(f"⚠️  Modbus JSON: {len(modbus_diffs)} differences found:")
        for diff in modbus_diffs[:10]:
            print(f"   - {diff}")
        if len(modbus_diffs) > 10:
            print(f"   ... and {len(modbus_diffs) - 10} more")
    
    # Step 5: Compare ParamMap JSONs
    print("\n[Step 5] Comparing ParamMap JSON (original vs reconstructed)...")
    paramap_blocks = ["P1", "P2", "P3", "JKY"]
    paramap_diffs = []
    
    for block in paramap_blocks:
        block_diffs = compare_json_blocks(paramap_json_orig, paramap_json_recon, block)
        paramap_diffs.extend(block_diffs)
    
    if not paramap_diffs:
        print("✅ ParamMap JSON: PERFECT MATCH!")
    else:
        print(f"⚠️  ParamMap JSON: {len(paramap_diffs)} differences found:")
        for diff in paramap_diffs[:10]:
            print(f"   - {diff}")
        if len(paramap_diffs) > 10:
            print(f"   ... and {len(paramap_diffs) - 10} more")
    
    # Step 6: Overall result
    total_diffs = len(modbus_diffs) + len(paramap_diffs)
    
    print("\n" + "="*70)
    if total_diffs == 0:
        print("🎉 🎉 🎉 100% ROUND-TRIP SUCCESS! 🎉 🎉 🎉")
        print(f"Production config ({num_params} params, {num_packets} packets) validated!")
        print("All blocks match byte-for-byte!")
        return True
    else:
        print(f"⚠️  PARTIAL SUCCESS: {total_diffs} differences detected")
        print("Round-trip is working but some fields differ")
        
        # Save detailed comparison
        with open("test_comparison_production.json", "w") as f:
            json.dump({
                "modbus_original": modbus_json_orig,
                "modbus_reconstructed": modbus_json_recon,
                "paramap_original": paramap_json_orig,
                "paramap_reconstructed": paramap_json_recon,
                "modbus_differences": modbus_diffs,
                "paramap_differences": paramap_diffs
            }, f, indent=2)
        print("\n💾 Detailed comparison saved to: test_comparison_production.json")
        
        return False


def main():
    """Run production-scale test"""
    print("\n" + "="*70)
    print("PRODUCTION-SCALE BIDIRECTIONAL TRANSFORMATION TEST")
    print("Testing 21-field schema with 163 parameters, 82 packets")
    print("="*70)
    
    success = test_production_round_trip()
    
    print("\n" + "="*70)
    print("TEST RESULT")
    print("="*70)
    if success:
        print("✅ PASS - Production round-trip validated successfully")
        print("The 21-field schema fixes work at production scale!")
    else:
        print("⚠️  NEEDS REVIEW - Some differences detected")
        print("Check test_comparison_production.json for details")
    
    return success


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
