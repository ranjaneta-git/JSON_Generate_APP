"""Check if JKA entries correspond to first N entries of P2.MPI or if there's a different mapping"""
import json
from pathlib import Path

production_path = Path(r"c:\Users\DELL\Documents\GitHub\Thermelgy-Gway-BMIoT\Thermelgy-Gateway-BMIoT\data")
with open(production_path / "Modbus_Config.json", "r") as f:
    modbus_json = json.load(f)
with open(production_path / "ParamMap_Config.json", "r") as f:
    paramap_json = json.load(f)

b5 = modbus_json["B5"]
jka = paramap_json["JKY"]["JKA"]
p2 = paramap_json["P2"]
p3 = paramap_json["P3"]
p2_lbi = p2.get("LBI", [])

print(f"P2.LBI length: {len(p2_lbi)}")
print(f"P2.MPI length: {len(p2['MPI'])}")
print(f"JKA length: {len(jka)}")

# Theory: JKA might correspond to P2.LBI, not P2.MPI
if len(p2_lbi) > 0:
    print(f"\nP2.LBI might map to JKA entries (local bus interface?)")
    print(f"P2.LBI first 10: {p2_lbi[:10]}")
    
    # Check if LBI length matches JKA
    print(f"P2.LBI matches JKA length? {len(p2_lbi) == len(jka)}")
    
    # Try mapping via LBI
    if len(p2_lbi) == len(jka):
        print(f"\nMapping JKA via P2.LBI:")
        for i in range(min(5, len(jka))):
            lbi_val = p2_lbi[i]
            jka_param = jka[i][0]
            b5_id = b5['ID'][lbi_val - 1] if lbi_val <= len(b5['ID']) else "N/A"
            print(f"  JKA[{i}] = {jka_param}, P2.LBI[{i}] = {lbi_val}, B5.ID[{lbi_val-1}] = {b5_id}")
