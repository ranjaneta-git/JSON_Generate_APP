"""Check JKA ordering - first 59 vs remaining"""
import json
from pathlib import Path

production_path = Path(r"c:\Users\DELL\Documents\GitHub\Thermelgy-Gway-BMIoT\Thermelgy-Gateway-BMIoT\data")
with open(production_path / "Modbus_Config.json", "r") as f:
    modbus_json = json.load(f)
with open(production_path / "ParamMap_Config.json", "r") as f:
    paramap_json = json.load(f)

b5 = modbus_json["B5"]
jka = paramap_json["JKY"]["JKA"]
p2_mpi = paramap_json["P2"]["MPI"]

print(f"First 59 JKA entries (should map to P2.MPI):")
for i in range(min(5, 59)):
    jka_param = jka[i][0]
    p2_b5_id = p2_mpi[i]
    print(f"  JKA[{i}] = {jka_param}, P2.MPI[{i}] = {p2_b5_id}")

print(f"\n... (showing first 5 of 59)")

print(f"\nRemaining JKA entries (59-78, total 20):")
for i in range(59, min(65, len(jka))):
    jka_param = jka[i][0]
    print(f"  JKA[{i}] = {jka_param}")

print(f"\n... (showing first 6 of remaining {len(jka)-59})")
